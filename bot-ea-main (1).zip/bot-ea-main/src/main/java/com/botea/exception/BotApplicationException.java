package com.botea.exception;

/**
 * @author Praveen
 */
public class BotApplicationException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private String errorCode;

	public BotApplicationException(String message) {
		super(message);
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
}
