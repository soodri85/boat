package com.botea.exception;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.support.WebExchangeBindException;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@ControllerAdvice
public class GlobalExceptionHandler {

	private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	private final ObjectMapper objectMapper;

	public GlobalExceptionHandler(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}

	@ExceptionHandler(WebExchangeBindException.class)
	public Mono<Void> handleValidationException(ServerWebExchange exchange, WebExchangeBindException ex) {
		logger.error("Validation failed: {}", ex.getMessage());

		exchange.getResponse().setStatusCode(HttpStatus.BAD_REQUEST);

		FieldError fieldError = ex.getFieldError();

		if (fieldError != null) {
			String field = fieldError.getField();
			String message = fieldError.getDefaultMessage();
			ErrorResponse errorResponse = new ErrorResponse(
					HttpStatus.BAD_REQUEST.value(),
					message,
					"VALIDATION_ERROR"
			);

			return exchange.getResponse().writeWith(Mono.just(
					exchange.getResponse().bufferFactory().wrap(serializeErrorResponse(errorResponse).getBytes())
			));
		}

		return Mono.empty();
	}

	@ExceptionHandler(Exception.class)
	public Mono<Void> handleGenericException(ServerWebExchange exchange, Exception e) {
		logger.error("Internal server error", e);
		exchange.getResponse().setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);

		ErrorResponse errorResponse = new ErrorResponse(
				HttpStatus.INTERNAL_SERVER_ERROR.value(),
				"An unexpected error occurred. Please try again later.",
				"INTERNAL_SERVER_ERROR"
		);

		return exchange.getResponse().writeWith(Mono.just(
				exchange.getResponse().bufferFactory().wrap(serializeErrorResponse(errorResponse).getBytes())
		));
	}

	@ExceptionHandler(BotApplicationException.class)
	public Mono<Void> handleCustomException(ServerWebExchange exchange, BotApplicationException e) {
		logger.error("Application error: {}", e.getMessage(), e);
		exchange.getResponse().setStatusCode(HttpStatus.BAD_REQUEST);

		ErrorResponse errorResponse = new ErrorResponse(
				HttpStatus.BAD_REQUEST.value(),
				e.getMessage(),
				e.getErrorCode()
		);

		return exchange.getResponse().writeWith(Mono.just(
				exchange.getResponse().bufferFactory().wrap(serializeErrorResponse(errorResponse).getBytes())
		));
	}

	@ExceptionHandler(ResponseStatusException.class)
	public Mono<Void> handleResponseStatusException(ServerWebExchange exchange, ResponseStatusException ex) {
		HttpStatusCode status = ex.getStatusCode();
		String message = ex.getReason();

		String errorCode = "RESPONSE_STATUS_ERROR";

		logger.error("ResponseStatusException: {} {}", status, message);

		exchange.getResponse().setStatusCode(status);

		ErrorResponse errorResponse = new ErrorResponse(
				status.value(),
				message,
				errorCode
		);

		return exchange.getResponse().writeWith(Mono.just(
				exchange.getResponse().bufferFactory().wrap(serializeErrorResponse(errorResponse).getBytes())
		));
	}

	private String serializeErrorResponse(ErrorResponse errorResponse) {
		try {
			return objectMapper.writeValueAsString(errorResponse);
		} catch (Exception ex) {
			logger.error("Error serializing error response", ex);
			return "{\"status\":500, \"message\":\"Internal Server Error\", \"errorCode\":\"INTERNAL_SERVER_ERROR\"}";
		}
	}
}
