package com.botea.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table("license_payment")
public class LicensePayment {
    @Id
    @Column("license_payment_id")
    private Long licensePaymentId;

    @Column("license_id")
    private Long licenseId;

    @Column("purchased_on")
    private Timestamp purchasedOn;

    @Column("purchased_by")
    private Long purchasedById;

    @Column("payment_method")
    private String paymentMethod;

    @Column("payment_details")
    private String paymentDetails;

    @Column("payment_amount")
    private BigDecimal paymentAmount;

    @Column("payment_currency_code")
    private String paymentCurrencyCode;

    @Column("comments")
    private String comments;

    @Column("created")
    private Timestamp created;

    @Column("created_by")
    private Long createdBy;

    @Column("updated")
    private Timestamp updated;

    @Column("updated_by")
    private Long updatedBy;
}
