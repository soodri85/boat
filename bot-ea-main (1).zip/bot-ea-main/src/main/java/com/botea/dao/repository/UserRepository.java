package com.botea.dao.repository;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

import com.botea.dao.entity.BotUser;

import reactor.core.publisher.Mono;

@Repository
public interface UserRepository extends ReactiveCrudRepository<BotUser, Long>, CustomUserRepository {
    @Query("SELECT bot_user.bot_user_id, bot_user.username, bot_user.password, bot_user.role, bot_user.phone, " +
            "bot_user.first_name, bot_user.middle_name, bot_user.last_name, bot_user.legal_name, bot_user.dob, " +
            "bot_user.address_line1, bot_user.address_line2, bot_user.city, bot_user.zip, bot_user.state, " +
            "bot_user.country, bot_user.is_verified, bot_user.is_two_factor_enabled, bot_user.two_factor_type, " +
            "bot_user.created, bot_user.created_by, bot_user.updated, bot_user.updated_by " +
            "FROM bot_user WHERE bot_user.username = :username")
    Mono<BotUser> findByUsername(@Param("username") String username);

    @Query("SELECT u.* FROM bot_user u " +
            "JOIN token t ON u.bot_user_id = t.bot_user_id " +
            "WHERE t.token = :token AND t.is_active = true AND t.is_logged_out = false")
    Mono<BotUser> findUserByToken(String token);

    @Query("UPDATE bot_user SET is_verified = true WHERE bot_user_id = :botUserId")
    Mono<Void> markAsVerified(@Param("botUserId") Long botUserId);

    @Query("SELECT bot_user_id from user_profile where user_profile_id = :userProfileId")
    Mono<BotUser> findBotUserByUserId(@Param("userProfileId") Long userProfileId);
}
