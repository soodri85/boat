package com.botea.dao.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "country_profile")
public class CountryProfile {

    @Id
    @Column(name = "country_profile_id")
    private Long countryProfileId;

    @Column(name = "name")
    private String name;

    @Column(name = "country_name", nullable = false)
    private String countryName;
    
    @Column(name = "country_code", nullable = false)
    private String countryCode;

    @Column(name = "language")
    private String language;

    @Column(name = "language_code")
    private String languageCode;

    @Column(name = "currency")
    private String currency;

    @Column(name = "currency_code")
    private String currencyCode;

    @Column(name = "license_credit_document")
    private BigDecimal licenseCreditDocument;

    @Column(name = "license_credit_scan")
    private BigDecimal licenseCreditScan;

    @Column(name = "default_scans_included")
    private Long defaultScansIncluded;

    @Column(name = "created")
    private Timestamp created;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "updated")
    private Timestamp updated;

    @Column(name = "updated_by")
    private Long updatedBy;
}
