package com.botea.dao.entity;

import jakarta.persistence.*;
import lombok.*;

import java.sql.Timestamp;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@ToString
@Table(name = "transaction_data")
public class TransactionData {

    @Id
    @Column(name = "transaction_data_id")
    private Long transactionDataId;

    @Column(name = "user_profile_id")
    private Long userProfileId;

    @Column(name = "business_address_id")
    private Long businessAddressId;

    @Column(name = "extracted_data")
    private String extractedData;

    @Column(name = "edited_data")
    private String editedData;

    @Column(name = "generated_document_data")
    private String generatedDocumentData;

    @Column(name = "extraction_id")
    private String extractionId;

    @Column(name = "batch_id")
    private String batchId;

    @Column(name = "is_document_generated")
    private Boolean isDocumentGenerated;

    @Column(name = "uploaded_document_path")
    private String uploadedDocumentPath;

    @Column(name = "generated_document_path")
    private String generatedDocumentPath;

    @Column(name = "comments")
    private String comments;

    @Column(name = "version")
    private String version;

    @Column(name = "year")
    private Integer year;

    @Column(name = "document_id")
    private Long document_id;

    @Column(name = "created", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp created;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "updated", columnDefinition = "TIMESTAMP DEFAULT NULL")
    private Timestamp updated;

    @Column(name = "updated_by", columnDefinition = "INT DEFAULT NULL")
    private Long updatedBy;
}
