package com.botea.dao.repository;

import com.botea.dao.entity.APIConfig;
import reactor.core.publisher.Flux;

public interface CustomAPIConfigRepository {
    Flux<APIConfig> findAllAPIConfigLookUp();
}
