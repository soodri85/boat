package com.botea.dao.entity;

import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table("promo_code")
public class PromoCode {
    @Id
    @Column("promo_code_id")
    private Long promoCodeId;

    @Column("promo_code_value")
    private String promoCodeValue;

    @Column("promo_type")
    private String promoType;

    @Column("discount")
    private Double discount;

    @Column("is_used")
    private Boolean isUsed;

    @Column("expiry")
    private Integer expiry;

    @Column("created")
    private LocalDateTime created;

    @Column("created_by")
    private Long createdBy;

    @Column("updated")
    private LocalDateTime updated;

    @Column("updated_by")
    private Long updatedBy;

    @Column("usage_limit")
    private Integer usageLimit;

    @Column("times_used")
    private Integer timesUsed;

    @Column("comment")
    private String comment;
} 