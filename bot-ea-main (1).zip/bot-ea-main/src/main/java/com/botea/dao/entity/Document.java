package com.botea.dao.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "document")
public class Document {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long documentId;

    private String documentName;

    @ManyToOne
    @JoinColumn(name = "country_profile_id")
    private CountryProfile countryProfile;

    private String version;

    @Column
    private Timestamp created;
    private Long createdBy;

    @Column
    private Timestamp updated;
    private Long updatedBy;
}
