package com.botea.dao.repository;

import com.botea.dao.entity.BotUser;
import com.botea.helper.HouseKeepingHelper;
import io.r2dbc.spi.Row;
import io.r2dbc.spi.RowMetadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.r2dbc.core.DatabaseClient;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class UserRepositoryImpl implements   CustomUserRepository{
    @Autowired
    DatabaseClient databaseClient;

    private final String UPDATE_SQL = "UPDATE bot_user set phone = :phone, first_name = :firstName," +
            "middle_name = :middleName, last_name = :lastName, legal_name = :legalName, dob = :dob," +
            "address_line1 = :address1, address_line2= :address2, state = :state, city = :city, zip = :zip, " +
            "is_two_factor_enabled = :is_two_factor_enabled, updated_by = :updatedBy, updated = :updated where bot_user_id IN (" +
            "SELECT bot_user_id from user_profile where user_profile_id = :userProfileId)";
    @Override
    public Mono<BotUser> updateUserDetails(Long userProfileId, BotUser botUser) {
        // Encode the password before saving
        return databaseClient.sql(UPDATE_SQL)
                .bind("userProfileId", userProfileId)
                .bind("firstName", botUser.getFirstName())
                .bind("lastName",botUser.getLastName())
                .bind("middleName",botUser.getMiddleName())
                .bind("legalName", botUser.getLegalName())
                .bind("address1",botUser.getAddressLine1())
                .bind("address2",botUser.getAddressLine2())
                .bind("state",botUser.getState())
                .bind("city",botUser.getCity())
                .bind("zip",botUser.getZip())
                .bind("dob",botUser.getDob())
                .bind("phone",botUser.getPhone())
                .bind("is_two_factor_enabled",botUser.getIsTwoFactorEnabled())
                .bind("updatedBy", HouseKeepingHelper.getUpdatedBy())
                .bind("updated", HouseKeepingHelper.getUpdatedOn())
                .fetch()
                .rowsUpdated()
                .flatMap(updatedRows -> {
                    String selectSql = "SELECT * from bot_user where bot_user_id " +
                            "IN (SELECT bot_user_id from user_profile " +
                            "where user_profile_id = :userProfileId)";
                    return databaseClient.sql(selectSql)
                            .bind("userProfileId", userProfileId)
                            .map(this::mapRowToBotUser)
                            .one();
                });

    }

    private BotUser mapRowToBotUser(Row row, RowMetadata metadata){
        BotUser botUser = new BotUser();
        botUser.setBotUserId(row.get("bot_user_id", Long.class));
        botUser.setUsername(row.get("username", String.class));
        botUser.setRole(row.get("role", String.class));
        botUser.setPhone(row.get("phone", String.class));
        botUser.setFirstName(row.get("first_name", String.class));
        botUser.setMiddleName(row.get("middle_name", String.class));
        botUser.setLastName(row.get("last_name", String.class));
        botUser.setLegalName(row.get("legal_name", String.class));
        botUser.setDob(row.get("dob", LocalDate.class));
        botUser.setAddressLine1(row.get("address_line1", String.class));
        botUser.setAddressLine2(row.get("address_line2", String.class));
        botUser.setCity(row.get("city", String.class));
        botUser.setZip(row.get("zip", String.class));
        botUser.setState(row.get("state", String.class));
        botUser.setCountry(row.get("country",String.class));
        botUser.setCreated(row.get("created", LocalDateTime.class));
        botUser.setCreatedBy(row.get("created_by",Long.class));
        botUser.setUpdated(row.get("updated",LocalDateTime.class));
        botUser.setUpdatedBy(row.get("updated_by",Long.class));
        botUser.setIsTwoFactorEnabled(row.get("is_two_factor_enabled",Boolean.class));
        botUser.setIsVerified(row.get("is_verified",Boolean.class));
        botUser.setTwoFactorType(row.get("two_factor_type",String.class));
        return botUser;
    }
}
