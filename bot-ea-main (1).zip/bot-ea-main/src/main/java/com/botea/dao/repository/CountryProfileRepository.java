package com.botea.dao.repository;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.botea.dao.entity.CountryProfile;
import com.botea.helper.dto.CountryLookUpDTO;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface CountryProfileRepository extends R2dbcRepository<CountryProfile, Long> {

	Mono<CountryProfile> findByCountryName(String countryName);

	Mono<CountryProfile> findByCountryCode(String countryCode);

	Flux<CountryProfile> findAll();

	@Query("SELECT country_name, country_code, currency_code, license_credit_document, license_credit_scan, default_scans_included, country_profile_id FROM country_profile")
	Flux<CountryLookUpDTO> fetchCountryLookUp();
}
