package com.botea.dao.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

import com.botea.dao.entity.PromoCodeLicense;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface PromoCodeLicenseRepository extends ReactiveCrudRepository<PromoCodeLicense, Long> {
    Flux<PromoCodeLicense> findByPromoCodeId(Long promoCodeId);
    Mono<PromoCodeLicense> findByLicenseId(Long licenseId);
} 