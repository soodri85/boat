package com.botea.dao.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.*;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "token") // Ensure the table name is in snake_case
public class Token {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long tokenId;

    @Column(name = "token")  // Explicit mapping for snake_case column name
    private String token;

    @Column(name = "is_logged_out")  // Explicit mapping for snake_case column name
    private Boolean isLoggedOut;

    @Column(name = "bot_user_id")  // Explicit mapping for snake_case column name
    private Long botUserId;

    @Column(name = "login_time")  // Explicit mapping for snake_case column name
    private LocalDateTime loginTime;

    @Column(name = "logout_time")  // Explicit mapping for snake_case column name
    private LocalDateTime logoutTime;

    @Column(name = "is_refresh")  // Explicit mapping for snake_case column name
    private Boolean isRefresh = false;

    @Column(name = "is_active")  // Explicit mapping for snake_case column name
    private Boolean isActive = false;

    @Column(name = "user_agent")
    private String userAgent;

    @Column(name = "ip_address")
    private String ipAddress;
    @Column(name = "created")  // Explicit mapping for snake_case column name
    private LocalDateTime created;

    @Column(name = "updated")  // Explicit mapping for snake_case column name
    private LocalDateTime updated = null;

}
