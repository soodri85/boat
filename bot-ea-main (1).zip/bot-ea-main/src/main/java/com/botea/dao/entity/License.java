package com.botea.dao.entity;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table("license")
public class License {
	@Id
	@Column("license_id")
	private Long licenseId;

	@Column("license_key")
	private String licenseKey;

	@Column("bot_user_id")
	private Long botUserId;

	@Column("country_profile_id")
	private Long countryProfileId;

	@Column("is_registered")
	private Boolean isRegistered;

	@Column("is_expired")
	private Boolean isExpired;

	@Column("validity")
	private Date validity;

	@Column("license_type")
	private String licenseType;

	@Column("total_credit")
	private BigDecimal totalCredit;

	@Column("remaining_credit")
	private BigDecimal remainingCredit;

	@Column("comments")
	private String comments;

	@Column("created")
	private Timestamp created;

	@Column("created_by")
	private Long createdBy;

	@Column("updated")
	private Timestamp updated;

	@Column("updated_by")
	private Long updatedBy;

	// Remove JPA relationship as R2DBC doesn't support entity relationships
	// You'll need to handle relationships manually through queries
	private transient PromoCode promoCode;
}