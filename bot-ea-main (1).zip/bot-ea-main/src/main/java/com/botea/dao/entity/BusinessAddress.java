package com.botea.dao.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "business_address")
public class BusinessAddress {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonProperty("business_address_id")
    @Column(name = "business_address_id")
    private Integer businessAddressId;

    @JsonProperty("user_profile_id")
    @Column(name = "user_profile_id")
    private Long userProfileId;

    @JsonProperty("contact_type")
    @Column(name = "contact_type")
    private String contactType;

    @JsonProperty("employee_id")
    @Column(name = "employee_id")
    private String employeeId;

    @JsonProperty("national_identifier")
    @Column(name = "national_identifier")
    private String nationalIdentifier;

    @JsonProperty("business_owner")
    @Column(name = "business_owner")
    private String businessOwner;

    @JsonProperty("business_name")
    @Column(name = "business_name")
    private String businessName;

    @JsonProperty("business_number")
    @Column(name = "business_number")
    private String businessNumber;

    @JsonProperty("business_nature")
    @Column(name = "business_nature")
    private String businessNature;

    @JsonProperty("business_category")
    @Column(name = "business_category")
    private String businessCategory;

    @JsonProperty("naics_code")
    @Column(name = "naics_code")
    private String naicsCode;

    @JsonProperty("address_line1")
    @Column(name = "address_line1")
    private String addressLine1;

    @JsonProperty("address_line2")
    @Column(name = "address_line2")
    private String addressLine2;

    @JsonProperty("city")
    @Column(name = "city")
    private String city;

    @JsonProperty("zip")
    @Column(name = "zip")
    private String zip;

    @JsonProperty("state")
    @Column(name = "state")
    private String state;

    @JsonProperty("country")
    @Column(name = "country")
    private String country;

    @JsonProperty("business_phone")
    @Column(name = "business_phone")
    private String businessPhone;

    @JsonProperty("business_email")
    @Column(name = "business_email")
    private String businessEmail;

    @JsonProperty("ownership_status")
    @Column(name = "ownership_status")
    private String ownershipStatus;

    @JsonProperty("other_ownership_details")
    @Column(name = "other_ownership_details")
    private String otherOwnershipDetails;

    @JsonProperty("created")
    @Column(name = "created")
    private Timestamp created;

    @JsonProperty("created_by")
    @Column(name = "created_by")
    private Long createdBy;

    @JsonProperty("updated")
    @Column(name = "updated")
    private Timestamp updated;

    @JsonProperty("updated_by")
    @Column(name = "updated_by")
    private Long updatedBy;
}
