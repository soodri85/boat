package com.botea.dao.repository;

import com.botea.dao.entity.APIConfig;
import com.botea.dao.entity.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

import java.sql.Timestamp;


@Repository
public class APIConfigRepositoryImpl implements CustomAPIConfigRepository{
    @Autowired
    DatabaseClient databaseClient;

    @Override
    public Flux<APIConfig> findAllAPIConfigLookUp() {
        String query = "SELECT " +
                "ac.api_config_id, " +
                "ac.data_extraction_id, " +
                "ac.data_extraction_name, " +
                "ac.data_extraction_comments, " +
                "ac.data_extraction_version, " +
                "ac.anvil_pdf_template_id, " +
                "ac.anvil_pdf_template_name, " +
                "ac.anvil_pdf_template_comments, " +
                "ac.anvil_pdf_template_version, " +
                "ac.created, " +
                "ac.created_by, " +
                "ac.updated, " +
                "ac.updated_by, " +
                "d.document_id, " +
                "d.document_name, " +
                "d.version " +
                "FROM api_config ac " +
                "JOIN document d ON ac.document_id = d.document_id";


        return databaseClient.sql(query)
                .map((row, metadata) -> {
                    Document document = new Document();
                    document.setDocumentId(row.get("document_id", Long.class));
                    document.setDocumentName(row.get("document_name", String.class));
                    document.setVersion(row.get("version", String.class));

                    APIConfig apiConfig = new APIConfig(
                            row.get("api_config_id", Long.class),
                            document,
                            row.get("data_extraction_id", String.class),
                            row.get("data_extraction_name", String.class),
                            row.get("data_extraction_comments", String.class),
                            row.get("data_extraction_version", String.class),
                            row.get("anvil_pdf_template_id", String.class),
                            row.get("anvil_pdf_template_name", String.class),
                            row.get("anvil_pdf_template_comments", String.class),
                            row.get("anvil_pdf_template_version", String.class),
                            null,
                            row.get("created_by", Long.class),
                            null,
                            row.get("updated_by", Long.class)
                    );
                    return apiConfig;
                })
                .all();
    }
}
