package com.botea.dao.repository;

import com.botea.dao.entity.BusinessAddress;
import org.springframework.data.r2dbc.repository.Query;
import reactor.core.publisher.Mono;

import java.sql.Timestamp;

public interface CustomBusinessAddressRepository {
    Mono<BusinessAddress> updateBusinessAddress(
            Integer id, Long userProfileId, String addressLine1, String addressLine2, String city, String state, String zip,
            String country, String businessCategory, String businessName,
            String businessEmail, String businessNature,
            String businessNumber, String businessPhone,
            String businessOwner, String otherOwnershipDetails,
            String ownershipStatus, String contactType,
            String naicsCode,
            String nationalIdentifier,
            String employeeId,
            Timestamp updated,
            Long updatedBy);

    Mono<BusinessAddress> findByBusinessAddressID(Integer Id);

}
