package com.botea.dao.repository;

import com.botea.controller.dto.UserProfileCountryDTO;
import com.botea.dao.entity.BusinessAddress;
import com.botea.dao.entity.UserProfile;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface UserProfileRepository extends R2dbcRepository<UserProfile, Long>, CustomUserProfileRepository {

    Flux<UserProfile> findByBotUserId(Long botUserId);

    @Query("SELECT DISTINCT b FROM BusinessAddress b WHERE b.userProfileId = :userProfileId")
    Flux<BusinessAddress> findByUserProfileId(@Param("userProfileId") Long userProfileId);

    @Query("SELECT up.user_profile_id, up.bot_user_id, up.country_profile_id, up.is_default FROM user_profile up" +
            " WHERE up.user_profile_id = :userProfileId")
    Mono<UserProfile> findUserProfileById(@Param("userProfileId") Long userProfileId);

    @Query("SELECT up.user_profile_id,up.bot_user_id, up.country_profile_id, up.is_default FROM user_profile up where up.bot_user_id= :botUserId " +
            "AND up.country_profile_id = :countryProfileId ")
    Mono<UserProfile> findUserProfileByBotAndCountryId(@Param("BotId") Long botUserId, @Param("countryProfileId") Long countryProfileId);

}
