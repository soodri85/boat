package com.botea.dao.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Table(name = "bot_user")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BotUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bot_user_id")
    @JsonProperty("bot_user_id")
    private Long botUserId;

    @NotBlank(message = "Username is required")
    @Size(max = 255, message = "Username must not exceed 255 characters")
    @Email(message = "Invalid username format. Username should be email.")
    @Column(name = "username")
    @JsonProperty("username")
    private String username;

    @NotBlank(message = "Password is required")
    @Size(max = 255, message = "Password must not exceed 255 characters")
    @Column(name = "password")
    @JsonProperty("password")
    private String password;

    @Column(name = "role")
    @JsonProperty("role")
    private String role;

    @Column(name = "phone")
    @JsonProperty("phone")
    private String phone;

    @NotBlank(message = "First name is required")
    @Size(max = 255, message = "First name must not exceed 255 characters")
    @Column(name = "first_name")
    @JsonProperty("first_name")
    private String firstName;

    @Column(name = "middle_name")
    @JsonProperty("middle_name")
    private String middleName;

    @NotBlank(message = "Last name is required")
    @Size(max = 255, message = "Last name must not exceed 255 characters")
    @Column(name = "last_name")
    @JsonProperty("last_name")
    private String lastName;

    @Column(name = "legal_name")
    @JsonProperty("legal_name")
    private String legalName;

    @Column(name = "dob")
    @JsonProperty("dob")
    private LocalDate dob;

    @Column(name = "address_line1")
    @JsonProperty("address_line1")
    private String addressLine1;

    @Column(name = "address_line2")
    @JsonProperty("address_line2")
    private String addressLine2;

    @Column(name = "city")
    @JsonProperty("city")
    private String city;

    @Column(name = "zip")
    @JsonProperty("zip")
    private String zip;

    @Column(name = "state")
    @JsonProperty("state")
    private String state;

    @Column(name = "country")
    @JsonProperty("country")
    private String country;

    @Column(name = "is_verified")
    @JsonProperty("is_verified")
    private Boolean isVerified;

    @Column(name = "is_two_factor_enabled")
    @JsonProperty("is_two_factor_enabled")
    private Boolean isTwoFactorEnabled;

    @Column(name = "two_factor_type")
    @JsonProperty("two_factor_type")
    private String twoFactorType;

    @Column(name = "created")
    @JsonProperty("created")
    private LocalDateTime created;

    @Column(name = "created_by")
    @JsonProperty("created_by")
    private Long createdBy;

    @Column(name = "updated")
    @JsonProperty("updated")
    private LocalDateTime updated = null;

    @Column(name = "updated_by")
    @JsonProperty("updated_by")
    private Long updatedBy;


}
