package com.botea.dao.entity;

import java.sql.Timestamp;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "naics")
public class NAICS {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private Long naicsId;
	private String naicsCode;
	private String naicsDescription;

	@ManyToOne
	@JoinColumn(name = "country_profile_id")
	private CountryProfile countryProfile;

	@Column
	private Timestamp created;
	private Long createdBy;

	@Column
	private Timestamp updated;
	private Long updatedBy;

}
