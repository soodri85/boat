package com.botea.dao.repository;

import com.botea.dao.entity.Otp;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface OtpRepository extends R2dbcRepository<Otp, Long> {

    @Query("SELECT * FROM otp WHERE bot_user_id = :botUserId AND otp_type = :otpType AND is_expired = false AND otp = :otp")
    Mono<Otp> findByUserIdAndOtpTypeAndExpiredFalse(@Param("botUserId") Long botUserId, @Param("otpType") String otpType, @Param("otp") Integer otp);

    @Query("UPDATE otp SET is_expired = true WHERE bot_user_id = :botUserId")
    Mono<Void> markOtpAsExpired(@Param("botUserId") Long botUserId);
}
