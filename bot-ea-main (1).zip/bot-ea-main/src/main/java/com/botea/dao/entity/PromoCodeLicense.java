package com.botea.dao.entity;

import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table("promo_code_license")
public class PromoCodeLicense {
    @Id
    @Column("promo_code_license_id")
    private Long promoCodeLicenseId;

    @Column("promo_code_id")
    private Long promoCodeId;

    @Column("license_id")
    private Long licenseId;

    @Column("used_on")
    private LocalDateTime usedOn;

    @Column("created")
    private LocalDateTime created;

    @Column("created_by")
    private Long createdBy;
} 