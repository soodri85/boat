package com.botea.dao.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "otp")
@Setter
public class Otp {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "otp_id")
    private Long otpId;

    @Column(name = "bot_user_id")
    private Long botUserId;

    @Column(name = "is_expired")
    private Boolean isExpired;

    @Column(name = "otp_type")
    private String otpType;

    private Integer otp;

    private LocalDateTime created;

    @Column(name = "created_by")
    private Long createdBy;

    private LocalDateTime updated;

    @Column(name = "updated_by")
    private Long updatedBy;
}
