package com.botea.dao.repository;

import com.botea.dao.entity.UserProfile;
import com.botea.controller.dto.UserProfileCountryDTO;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface CustomUserProfileRepository {
    Mono<UserProfile> updateUserProfile(Long userProfileId, boolean isDefault);
    Flux<UserProfileCountryDTO> findUserProfilesWithCountryAndLicenseInfo(Long botUserId);
}
