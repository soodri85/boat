package com.botea.dao.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "api_config")
public class APIConfig {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long apiConfigId;

    @OneToOne
    @JoinColumn(name = "document_id")
    private Document document;

    private String dataExtractionId;
    private String dataExtractionName;
    private String dataExtractionComments;
    private String dataExtractionVersion;

    private String anvilPdfTemplateId;
    private String anvilPdfTemplateName;
    private String anvilPdfTemplateComments;
    private String anvilPdfTemplateVersion;

    @Column
    private Timestamp created;
    private Long createdBy;

    @Column
    private Timestamp updated;
    private Long updatedBy;
}
