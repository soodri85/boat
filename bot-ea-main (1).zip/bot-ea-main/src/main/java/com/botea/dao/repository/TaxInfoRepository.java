package com.botea.dao.repository;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.botea.dao.entity.TaxInfo;
import com.botea.helper.dto.TaxInfoLookUpDTO;

import reactor.core.publisher.Flux;

@Repository
public interface TaxInfoRepository extends R2dbcRepository<TaxInfo, Long> {
	@Query("SELECT ti.province_code, ti.province_name, ti.gst_percentage, cp.country_name FROM tax_info ti LEFT JOIN country_profile cp ON cp.country_profile_id = ti.country_profile_id")
	Flux<TaxInfoLookUpDTO> fetchTaxInfoLookUp();
}
