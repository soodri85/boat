package com.botea.dao.repository;

import com.botea.dao.entity.BusinessAddress;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

import java.sql.Timestamp;

@Repository
public class BusinessAddressRepositoryImpl implements CustomBusinessAddressRepository{

    @Autowired
    DatabaseClient databaseClient;


    @Override
    public Mono<BusinessAddress> updateBusinessAddress(Integer id, Long userProfileId, String addressLine1, String addressLine2, String city, String state, String zip, String country, String businessCategory, String businessName, String businessEmail, String businessNature, String businessNumber, String businessPhone, String businessOwner, String otherOwnershipDetails, String ownershipStatus, String contactType, String naicsCode, String nationalIdentifier, String employeeId, Timestamp updated, Long updatedBy) {
        return databaseClient.sql("""
            UPDATE business_address
            SET 
                contact_type = :contactType, 
                employee_id = :employeeId,
                national_identifier = :nationalIdentifier,
                business_owner = :businessOwner,
                business_name = :businessName,
                business_number = :businessNumber,
                business_nature = :businessNature,
                business_category = :businessCategory,
                naics_code = :naicsCode,
                address_line1 = :addressLine1,
                address_line2 = :addressLine2,
                city = :city,
                zip = :zip,
                state = :state,
                country = :country,
                business_phone = :businessPhone,
                business_email = :businessEmail,
                ownership_status = :ownershipStatus,
                other_ownership_details = :otherOwnershipDetails, 
                updated = :updated,
                updated_by = :updatedBy
            WHERE business_address_id = :id
            """)
                .bind("contactType", contactType)
                .bind("employeeId", employeeId)
                .bind("nationalIdentifier", nationalIdentifier)
                .bind("businessOwner", businessOwner)
                .bind("businessName", businessName)
                .bind("businessNumber", businessNumber)
                .bind("businessNature", businessNature)
                .bind("businessCategory", businessCategory)
                .bind("naicsCode", naicsCode)
                .bind("addressLine1", addressLine1)
                .bind("addressLine2", addressLine2)
                .bind("city", city)
                .bind("zip", zip)
                .bind("state", state)
                .bind("country", country)
                .bind("businessPhone", businessPhone)
                .bind("businessEmail", businessEmail)
                .bind("ownershipStatus", ownershipStatus)
                .bind("otherOwnershipDetails", otherOwnershipDetails)
                .bind("updated", updated)
                .bind("updatedBy", updatedBy)
                .bind("id", id)
                .fetch()
                .rowsUpdated()
                .flatMap(rows -> {
                    if (rows > 0) {
                        return findByBusinessAddressID(id); // Fetch the updated record
                    } else {
                        return Mono.empty();
                    }
                });
    }


    @Override
    public Mono<BusinessAddress> findByBusinessAddressID(Integer id) {
        return databaseClient.sql("SELECT * FROM business_address WHERE business_address_id = :id")
                .bind("id", id)
                .map((row, metadata) -> {
                    BusinessAddress businessAddress = new BusinessAddress();
                    businessAddress.setBusinessAddressId(row.get("business_address_id", Integer.class));
                    businessAddress.setUserProfileId(row.get("user_profile_id", Long.class));
                    businessAddress.setAddressLine1(row.get("address_line1", String.class));
                    businessAddress.setAddressLine2(row.get("address_line2", String.class));
                    businessAddress.setCity(row.get("city", String.class));
                    businessAddress.setState(row.get("state", String.class));
                    businessAddress.setZip(row.get("zip", String.class));
                    businessAddress.setCountry(row.get("country", String.class));
                    businessAddress.setBusinessCategory(row.get("business_category", String.class));
                    businessAddress.setBusinessName(row.get("business_name", String.class));
                    businessAddress.setBusinessEmail(row.get("business_email", String.class));
                    businessAddress.setBusinessNature(row.get("business_nature", String.class));
                    businessAddress.setBusinessNumber(row.get("business_number", String.class));
                    businessAddress.setBusinessPhone(row.get("business_phone", String.class));
                    businessAddress.setBusinessOwner(row.get("business_owner", String.class));
                    businessAddress.setOtherOwnershipDetails(row.get("other_ownership_details", String.class));
                    businessAddress.setOwnershipStatus(row.get("ownership_status", String.class));
                    businessAddress.setContactType(row.get("contact_type", String.class));
                    businessAddress.setNaicsCode(row.get("naics_code", String.class));
                    businessAddress.setNationalIdentifier(row.get("national_identifier", String.class));
                    businessAddress.setEmployeeId(row.get("employee_id", String.class));
                    return businessAddress;
                })
                .one();
    }


}
