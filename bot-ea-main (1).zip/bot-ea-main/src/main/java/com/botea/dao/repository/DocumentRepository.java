package com.botea.dao.repository;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.botea.dao.entity.Document;

@Repository
public interface DocumentRepository extends R2dbcRepository<Document, Long> {

}
