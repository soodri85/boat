package com.botea.dao.repository;

import com.botea.dao.entity.Token;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;

@Repository
public interface TokenRepository extends ReactiveCrudRepository<Token, Long> {

    // Find a specific token by its token string
    Mono<Token> findByToken(String token);

    // Find a list of tokens by botUserId
    Flux<Token> findByBotUserId(Long userId);

    @Query("UPDATE token SET is_active = :isActive, updated = :updatedTime WHERE token_id = :tokenId")
    Mono<Integer> updateTokenActiveStatus(Long tokenId, boolean isActive, LocalDateTime updatedTime);

    @Query("UPDATE token SET is_active = false, is_logged_out = true, updated = :updatedTime, logout_time = :logoutTime WHERE token = :token")
    Mono<Integer> markTokenAsLoggedOut(@Param("token") String token,
                                       @Param("logoutTime") LocalDateTime logoutTime,
                                       @Param("updatedTime") LocalDateTime updatedTime);

}
