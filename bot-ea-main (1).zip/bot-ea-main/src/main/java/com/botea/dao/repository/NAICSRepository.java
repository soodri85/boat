package com.botea.dao.repository;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.botea.dao.entity.NAICS;
import com.botea.helper.dto.NAICSLookUpDTO;

import reactor.core.publisher.Flux;

@Repository
public interface NAICSRepository extends R2dbcRepository<NAICS, Long> {
	@Query("SELECT n.naics_code, n.naics_description, cp.country_code FROM naics n LEFT JOIN country_profile cp ON cp.country_profile_id = n.country_profile_id WHERE cp.country_code=:countryCode")
	Flux<NAICSLookUpDTO> fetchNAICSLookUp(String countryCode);
}
