package com.botea.dao.repository;

import com.botea.controller.dto.UserProfileCountryDTO;
import com.botea.dao.entity.Document;
import com.botea.dao.entity.UserProfile;
import com.botea.helper.HouseKeepingHelper;
import io.r2dbc.spi.Row;
import io.r2dbc.spi.RowMetadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;

import java.util.stream.Collectors;

@Repository
public class UserProfileRepositoryImpl implements CustomUserProfileRepository{

    @Autowired
    DatabaseClient databaseClient;

    private final String UPDATE_SQL = "UPDATE user_profile SET is_default = :isDefault, updated_by = :updatedBy, updated = :updated " +
            "WHERE user_profile_id = :userProfileId";

    @Override
    public Mono<UserProfile> updateUserProfile(Long userProfileId, boolean isDefault) {
        return databaseClient.sql(UPDATE_SQL)
                .bind("isDefault", isDefault)
                .bind("userProfileId", userProfileId)
                .bind("updatedBy", HouseKeepingHelper.getUpdatedBy())
                .bind("updated", HouseKeepingHelper.getUpdatedOn())
                .fetch()
                .rowsUpdated()
                .flatMap(updatedRows -> {
                    String selectSql = "SELECT * from user_profile where " +
                            "user_profile_id = :userProfileId";
                    return databaseClient.sql(selectSql)
                            .bind("userProfileId", userProfileId)
                            .map((row, metadata) -> mapRowToUserProfile(row, metadata))
                            .one();
                });
    }

    private UserProfile mapRowToUserProfile(Row row, RowMetadata metadata) {
        UserProfile userProfile = new UserProfile();
        userProfile.setUserProfileId(row.get("user_profile_id",Long.class));
        userProfile.setBotUserId(row.get("bot_user_id",Long.class));
        userProfile.setCountryProfileId(row.get("country_profile_id",Long.class));
        userProfile.setIsDefault(row.get("is_default",Boolean.class));
        userProfile.setCreated(row.get("created", LocalDateTime.class));
        userProfile.setCreatedBy(row.get("created_by",Long.class));
        userProfile.setUpdated(row.get("updated",LocalDateTime.class));
        userProfile.setUpdatedBy(row.get("updated_by",Long.class));
        return userProfile;
    }

    @Override
    public Flux<UserProfileCountryDTO> findUserProfilesWithCountryAndLicenseInfo(Long botUserId) {
       String SelectSQL = "SELECT up.user_profile_id, up.bot_user_id, up.country_profile_id, up.is_default, bo.is_verified, " +
               "cp.country_name, cp.country_code, cp.language, cp.language_code, cp.currency, " +
               "d.document_id, d.document_name, d.version, " +
               "COALESCE(l.is_registered, false) as is_registered, " +
               "COALESCE(l.is_expired, false) as is_expired, " +
               "COALESCE(l.total_credit, 0) as total_credit, " +
               "COALESCE(l.remaining_credit, 0) as remaining_credit " +
               "FROM user_profile up " +
               "JOIN bot_user bo ON up.bot_user_id = bo.bot_user_id " +
               "JOIN country_profile cp ON up.country_profile_id = cp.country_profile_id " +
               "LEFT JOIN document d ON cp.country_profile_id = d.country_profile_id " +
               "LEFT JOIN license l ON up.bot_user_id = l.bot_user_id " +
               "AND up.country_profile_id = l.country_profile_id " +
               "AND l.is_registered = TRUE " +
               "AND l.is_expired = FALSE " +
               "WHERE up.bot_user_id = :botUserId";

        return databaseClient.sql(SelectSQL)
                .bind("botUserId", botUserId)
                .map((row, metadata) -> {

                    UserProfileCountryDTO dto = new UserProfileCountryDTO(
                            row.get("user_profile_id", Long.class),
                            row.get("bot_user_id", Long.class),
                            row.get("country_profile_id", Long.class),
                            row.get("is_default", Boolean.class),
                            row.get("is_verified", Boolean.class),
                            row.get("country_name", String.class),
                            row.get("country_code", String.class),
                            row.get("language", String.class),
                            row.get("language_code", String.class),
                            row.get("currency", String.class),
                            row.get("is_registered", Boolean.class),
                            row.get("is_expired", Boolean.class),
                            row.get("total_credit", BigDecimal.class),
                            row.get("remaining_credit", BigDecimal.class),
                            new ArrayList<>()
                    );
                    Document document = new Document();
                    document.setDocumentId(row.get("document_id", Long.class));
                    document.setDocumentName(row.get("document_name", String.class));
                    document.setVersion(row.get("version", String.class));
                    dto.getDocuments().add(document);
                    return dto;
                }).all()
                .groupBy(UserProfileCountryDTO::getUserProfileId)
                .flatMap(groupedFlux -> groupedFlux.collectList()
                        .map(list -> {
                            UserProfileCountryDTO dto = list.get(0);
                            dto.setDocuments(list.stream()
                                    .flatMap(d -> d.getDocuments().stream())
                                    .collect(Collectors.toList()));
                            return dto;
                        }));


    }
}
