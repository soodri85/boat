package com.botea.dao.repository;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.botea.dao.entity.APIConfig;

@Repository
public interface APIConfigRepository extends R2dbcRepository<APIConfig, Long>, CustomAPIConfigRepository {

}
