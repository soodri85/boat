package com.botea.dao.repository;

import com.botea.dao.entity.LicenseType;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface LicenseTypeRepository extends ReactiveCrudRepository<LicenseType, String> {
    Mono<Boolean> existsByCode(String code);
} 