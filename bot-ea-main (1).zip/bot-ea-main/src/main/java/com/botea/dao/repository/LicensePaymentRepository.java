package com.botea.dao.repository;

import com.botea.dao.entity.LicensePayment;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface LicensePaymentRepository extends R2dbcRepository<LicensePayment, Long> {
    @Query("DELETE FROM license_payment WHERE license_id = :licenseId")
    Mono<Void> deleteByLicenseId(Long licenseId);

    @Query("SELECT * FROM license_payment WHERE payment_details::jsonb @> :paymentDetails::jsonb")
    Mono<LicensePayment> findByPaymentDetails(String paymentDetails);

    @Query("UPDATE license_payment SET license_id = :licenseId, payment_details = :completedPaymentDetails, " +
           "updated = CURRENT_TIMESTAMP, updated_by = :updatedBy " +
           "WHERE payment_details::jsonb @> :pendingPaymentDetails::jsonb " +
           "AND license_id IS NULL " +
           "RETURNING *")
    Mono<LicensePayment> atomicUpdateLicenseId(Long licenseId, String completedPaymentDetails, String pendingPaymentDetails, Long updatedBy);
}
