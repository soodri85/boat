package com.botea.dao.repository;

import com.botea.controller.dto.LicenseManagementResponseDTO;
import com.botea.dao.entity.License;
import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;

@Repository
public interface LicenseRepository extends R2dbcRepository<License, Long> {
    @Query("SELECT license_id, license_key, bot_user_id, country_profile_id, is_registered, is_expired, " +
           "validity, license_type, total_credit, remaining_credit, comments, created, created_by, " +
           "updated, updated_by FROM license WHERE license_key = :licenseKey")
    Mono<License> findByLicenseKey(@Param("licenseKey") String licenseKey);

    @Query(value = """
           SELECT 
               cp.country_code as country_code,
               bu.username as email,
               l.license_key as license_key,
               l.total_credit as total_credit,
               l.remaining_credit as remaining_credit,
               l.license_type as license_type,
               l.is_registered as is_registered,
               l.is_expired as is_expired,
               l.created as date_purchased
           FROM license l
           LEFT JOIN bot_user bu ON bu.bot_user_id = l.bot_user_id
           LEFT JOIN country_profile cp ON cp.country_profile_id = l.country_profile_id
           WHERE l.bot_user_id = :botUserId
           AND l.country_profile_id = :countryProfileId
           ORDER BY l.created DESC
           """)
    Flux<LicenseManagementResponseDTO> findLicenseDetailsByBotUserId(
            @Param("botUserId") Long botUserId,
            @Param("countryProfileId") Long countryProfileId);

    @Query("SELECT * FROM license WHERE bot_user_id = :botUserId AND country_profile_id = :countryProfileId " +
            "AND is_expired = FALSE AND is_registered = TRUE LIMIT 1")
    Mono<License> findActiveLicenseForUserAndCountry(@Param("botUserId") Long botUserId,
                                                     @Param("countryProfileId") Long countryProfileId);

    @Modifying
    @Query("UPDATE license SET remaining_credit = remaining_credit - :creditToDeduct, " +
           "updated = CURRENT_TIMESTAMP, updated_by = :updatedBy " +
           "WHERE license_key = :licenseKey AND remaining_credit = :currentCredit " +
           "AND remaining_credit >= :creditToDeduct")
    Mono<Integer> atomicUpdateRemainingCredit(
            @Param("licenseKey") String licenseKey, 
            @Param("creditToDeduct") BigDecimal creditToDeduct, 
            @Param("currentCredit") BigDecimal currentCredit, 
            @Param("updatedBy") Long updatedBy);

    @Modifying
    @Query("UPDATE license SET is_expired = true, total_credit = 0, remaining_credit = 0, " +
           "updated = CURRENT_TIMESTAMP, updated_by = :updatedBy " +
           "WHERE bot_user_id = :botUserId AND country_profile_id = :countryProfileId AND is_expired = false")
    Mono<Integer> expireActiveLicenses(
            @Param("botUserId") Long botUserId, 
            @Param("countryProfileId") Long countryProfileId,
            @Param("updatedBy") Long updatedBy);

    @Modifying
    @Query("UPDATE license SET bot_user_id = :botUserId, is_registered = true, " +
           "updated = CURRENT_TIMESTAMP, updated_by = :updatedBy " +
           "WHERE license_key = :licenseKey")
    Mono<Integer> updateLicense(@Param("botUserId") Long botUserId, @Param("licenseKey") String licenseKey, @Param("updatedBy") Long updatedBy);

    @Modifying
    @Query("UPDATE license SET total_credit = :totalCredit, remaining_credit = :remainingCredit, " +
            "updated_by = :updatedBy, updated = CURRENT_TIMESTAMP " +
            "WHERE license_key = :licenseKey")
    Mono<Integer> updateLicenseCredits(
            @Param("licenseKey") String licenseKey,
            @Param("totalCredit") BigDecimal totalCredit,
            @Param("remainingCredit") BigDecimal remainingCredit,
            @Param("updatedBy") Long updatedBy);

    @Modifying
    @Query("UPDATE license SET bot_user_id = :botUserId, is_registered = true, " +
           "total_credit = total_credit + :carriedCredits, " +
           "remaining_credit = remaining_credit + :carriedCredits, " +
           "updated = CURRENT_TIMESTAMP, updated_by = :updatedBy " +
           "WHERE license_key = :licenseKey")
    Mono<Integer> updateLicenseWithCarriedCredits(
            @Param("botUserId") Long botUserId,
            @Param("licenseKey") String licenseKey,
            @Param("carriedCredits") BigDecimal carriedCredits,
            @Param("updatedBy") Long updatedBy);

    @Query("""
           SELECT l.* FROM license l
           JOIN bot_user bu ON bu.bot_user_id = l.bot_user_id
           JOIN country_profile cp ON cp.country_profile_id = l.country_profile_id
           WHERE cp.country_code = :countryCode 
           AND bu.username = :email
           AND l.is_expired = FALSE 
           AND l.is_registered = TRUE 
           LIMIT 1
           """)
    Mono<License> findActiveLicenseByCountryCodeAndEmail(
            @Param("countryCode") String countryCode,
            @Param("email") String email);
}
