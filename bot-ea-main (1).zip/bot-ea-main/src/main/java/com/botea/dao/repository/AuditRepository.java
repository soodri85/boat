package com.botea.dao.repository;

import com.botea.dao.entity.Audit;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditRepository extends R2dbcRepository<Audit, Long> {
}
