package com.botea.dao.repository;

import com.botea.dao.entity.BotUser;
import reactor.core.publisher.Mono;

public interface CustomUserRepository {
    Mono<BotUser> updateUserDetails(Long userProfileId, BotUser botUser);
}
