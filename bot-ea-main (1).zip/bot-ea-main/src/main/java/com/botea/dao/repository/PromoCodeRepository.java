package com.botea.dao.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

import com.botea.dao.entity.PromoCode;

import reactor.core.publisher.Mono;

@Repository
public interface PromoCodeRepository extends ReactiveCrudRepository<PromoCode, Long> {
    Mono<PromoCode> findByPromoCodeValue(String promoCodeValue);
} 