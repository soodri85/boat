package com.botea.dao.repository;

import com.botea.controller.dto.TransactionUserDTO;
import com.botea.dao.entity.TransactionData;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.sql.Timestamp;

@Repository
public interface TransactionDataRepository extends R2dbcRepository<TransactionData, Long> {

    @Query("SELECT * FROM transaction_data WHERE transaction_data_id = :transactionDataId")
    Mono<TransactionData> findByTransactionDataId(Long transactionDataId);

    @Query("SELECT * FROM transaction_data WHERE batch_id = :batchId")
    Mono<TransactionData> findByBatchId(String batchId);

    @Query("""
            UPDATE transaction_data 
            SET 
                generated_document_path = :generatedDocumentPath, 
                generated_document_data = :generatedDocumentData, 
                comments = :comments, 
                is_document_generated = :isDocumentGenerated, 
                updated = :updated 
            WHERE batch_id = :batchId
            RETURNING *
            """)
    Mono<TransactionData> updateTransactionData(
            String generatedDocumentPath,
            String generatedDocumentData,
            String comments,
            Boolean isDocumentGenerated,
            Timestamp updated,
            String batchId
    );

    @Query("""
            UPDATE transaction_data 
            SET 
                edited_data = :edited_data, 
                updated = :updated, 
                updated_by = :updatedBy 
            WHERE transaction_data_id = :transaction_data_id
            RETURNING *
            """)
    Mono<TransactionData> updateEditDataData(
            Timestamp updated,
            Long updatedBy,
            Long transaction_data_id,
            String edited_data

    );

    @Query("""
            UPDATE transaction_data 
            SET 
                generated_document_path = :generated_document_path, 
                is_document_generated = :isDocumentGenerated, 
                edited_data = :editedData,
                updated = :updated, 
                updated_by = :updatedBy
            WHERE transaction_data_id = :transaction_data_id
            RETURNING *
            """)
    Mono<TransactionData> updatePdfPath(
            Timestamp updated,
            Long updatedBy,
            Long transaction_data_id,
            String generated_document_path,
            boolean isDocumentGenerated,
            String editedData

    );

    @Query("SELECT * FROM transaction_data WHERE business_address_id = :businessAddressId AND country = :country")
    Mono<TransactionData> findByBusinessAddressAndCountry(Long businessAddressId, String country);

    @Query("""            
            SELECT
                  td.created AS transaction_date,
                  ba.business_name AS business_name,
                  doc.document_name AS tax_form,
                  cp.country_name AS country,
                  td.uploaded_document_path AS uploaded_document_key,
                  td.generated_document_path AS downloaded_document_key,
            	  td.is_document_generated AS is_document_generated,
            	  td.transaction_data_id AS transaction_data_id
            FROM
                  transaction_data td
            JOIN
                document doc ON td.document_id = doc.document_id
            JOIN
                country_profile cp ON doc.country_profile_id = cp.country_profile_id
            LEFT JOIN
                business_address ba  ON td.business_address_id = ba.business_address_id
            WHERE
                  td.user_profile_id = :user_profile_id
            ORDER BY td.created DESC
            """)
    Flux<TransactionUserDTO> findTransactionDetails(Long user_profile_id);
}
