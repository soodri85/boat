package com.botea.controller.dto;

import com.botea.dao.entity.Document;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
public class UserProfileCountryDTO {

    private Long userProfileId;
    private Long botUserId;
    private Long countryProfileId;
    private Boolean isDefault;
    private Boolean isVerified;
    private String countryName;
    private String countryCode;
    private String language;
    private String languageCode;
    private String currency;
    private Boolean isRegistered;
    private Boolean isExpired;
    private BigDecimal totalCredit;
    private BigDecimal remainingCredit;
    private List<Document> documents  = new ArrayList<>(); ;

}
