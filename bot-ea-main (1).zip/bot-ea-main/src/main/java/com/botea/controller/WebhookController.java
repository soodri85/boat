package com.botea.controller;

import com.botea.config.PaymentPublicKeyConfig;
import com.botea.service.PaymentService;
import com.stripe.exception.SignatureVerificationException;
import com.stripe.model.Event;
import com.stripe.net.Webhook;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;


@RestController
@Slf4j
public class WebhookController {

    @Autowired
    private PaymentPublicKeyConfig stripePublicKeyConfig; // Your endpoint secret from Stripe Dashboard

    @Autowired
    PaymentService paymentService;

    @PostMapping("/api/webhook")
    public Mono<ResponseEntity<Map<String, Object>>> handleStripeWebhook(@RequestBody String payload, @RequestHeader("Stripe-Signature") String sigHeader) {
        Event event;

        try {
            log.info("Event received from Stripe");
            event = Webhook.constructEvent(payload, sigHeader, stripePublicKeyConfig.getSignature());
        } catch (SignatureVerificationException e) {
            log.error("Invalid webhook signature: {}", e.getMessage());
            // Still return 200 OK but with error message
            return Mono.just(ResponseEntity.ok().body(Map.of(
                "success", false,
                "message", "Invalid signature",
                "error", e.getMessage()
            )));
        }

        // Process the event but always return 200 OK
        return paymentService.handleEvents(event)
            .map(response -> {
                // Extract the message and any other data from the original response
                Map<String, Object> body = new HashMap<>();
                body.put("success", response.getStatusCode().is2xxSuccessful());
                if (response.getBody() != null) {
                    body.putAll(response.getBody());
                }
                // Always return 200 OK but preserve the message
                return ResponseEntity.ok().body(body);
            })
            .onErrorResume(e -> {
                log.error("Error processing webhook: {}", e.getMessage());
                return Mono.just(ResponseEntity.ok().body(Map.of(
                    "success", false,
                    "message", "Error processing webhook",
                    "error", e.getMessage()
                )));
            });
    }
}
