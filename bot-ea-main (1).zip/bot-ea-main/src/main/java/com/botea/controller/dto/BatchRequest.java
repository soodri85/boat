package com.botea.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BatchRequest {
    private String extractionId;
    private String batchId;
}
