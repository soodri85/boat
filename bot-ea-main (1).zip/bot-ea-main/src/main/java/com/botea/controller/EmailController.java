package com.botea.controller;

import com.botea.controller.dto.VerifyOtpRequest;
import com.botea.exception.BotApplicationException;
import com.botea.service.EmailOTPService;
import com.botea.service.EmailService;
import com.botea.utils.EmailType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class EmailController {

    @Autowired
    private EmailService emailService;

    @Autowired
    private EmailOTPService emailOTPService;

    @GetMapping("/verify-email")
    public ResponseEntity<String> sendEmail(@RequestParam String to) {
        emailService.verifyEmail(to);
        //from UI we'll get the to email. once verified only the user will be inserted to database.
        return ResponseEntity.ok("Email sent successfully to " + to);
    }

    @PostMapping(value = "/send-email-otp", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity< Map<String,String>>> sendOTP(@RequestBody Map<String,Object> request) {
        String email  = request.get("email").toString();
        if (email == null || email.isEmpty()) {
            return Mono.error(new BotApplicationException("Email is required"));
        }
        return emailOTPService.sendOTPAndVerifyUser(email, EmailType.TWO_FACTOR.getDisplayName(),"Account Verification for Bot-EA" ,EmailType.TWO_FACTOR)
                .flatMap(response -> {
                    if ("Success".equals(response)) {
                        Map<String,String> map = new HashMap<>();
                        map.put("otp_type", EmailType.TWO_FACTOR.getOtpType());
                        map.put("otp_type_display", EmailType.TWO_FACTOR.getDisplayName());
                        map.put("message", "OTP sent on the email");
                        return Mono.just(ResponseEntity.ok(map));
                    } else {
                        Map<String, String> map = new HashMap<>();
                        map.put("message", "Unable to send OTP to email.");
                        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                .body(map));
                    }
                })
                .onErrorResume(e -> {
                    Map<String, String> map = new HashMap<>();
                    map.put("message", "An error occurred while sending otp");
                   return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(map));

                });
    }

    @PostMapping("/verify-email-otp")
    public Mono<ResponseEntity<? extends Map<String, ? extends Object>>> verifyOtp(@RequestBody VerifyOtpRequest request, ServerHttpRequest servletRequest) {
        if (request == null || !StringUtils.hasText(request.getEmail())) {
            return Mono.error(new BotApplicationException("Invalid input"));
        }

        return emailOTPService.verifyOtp(request)
                .flatMap(response -> {
                    if ("Success".equals(response)) {
                         return emailOTPService.buildUserResponse(request.getEmail(), servletRequest);
                    } else {
                        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                .body(Map.of("message", "Unable to verify")));
                    }
                })
                .onErrorResume(e -> Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("message", "An error occurred during verification", "error", e.getMessage()))));
    }

}