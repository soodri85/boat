package com.botea.controller;

import com.botea.controller.dto.PasswordResetRequest;
import com.botea.service.ForgotPasswordService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;


import java.util.Map;

@RestController
@RequestMapping("/api")
public class ForgotPasswordController {

    private final ForgotPasswordService forgotPasswordService;

    public ForgotPasswordController(ForgotPasswordService forgotPasswordService) {
        this.forgotPasswordService = forgotPasswordService;
    }

    @PostMapping("/forgot-password")
    public Mono<ResponseEntity<Map<String,String>>> forgotPassword(@RequestParam String email) {
        return forgotPasswordService.processForgotPassword(email);
    }

    @PutMapping("/reset-password")
    public Mono<ResponseEntity<String>> resetPassword(@RequestBody PasswordResetRequest passwordResetRequest) {
        return forgotPasswordService.resetPassword(passwordResetRequest);
    }

    @PutMapping("/update-password")
    public Mono<ResponseEntity<String>> updatePassword(@RequestBody Map<String, String> request) {
        String token = request.get("userName");
        String newPassword = request.get("newPassword");
        String confirmPassword = request.get("confirmPassword");
        return forgotPasswordService.updateNewPassword(token, newPassword,confirmPassword);
    }



}
