package com.botea.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.codec.multipart.FilePart;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FileUploadRequest {
    private String template_name;
    private Integer year;
    private FilePart[] files;
    private Long user_profile_id;
    private Long business_address_id;
    private String batch_id;
}