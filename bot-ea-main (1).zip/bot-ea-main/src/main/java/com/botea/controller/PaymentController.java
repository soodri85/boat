package com.botea.controller;

import com.botea.config.PaymentPublicKeyConfig;
import com.botea.controller.dto.PaymentRequest;
import com.botea.controller.dto.PaymentStatusDTO;
import com.botea.service.LicenseManagementService;
import com.botea.service.PaymentService;
import com.botea.service.PromoCodeService;
import com.stripe.Stripe;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;


@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    @Autowired
    private PaymentPublicKeyConfig stripePublicKeyConfig;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private LicenseManagementService licenseManagementService;


    @PostConstruct
    public void init() {
        Stripe.apiKey = stripePublicKeyConfig.getSecretKey();
    }

    @GetMapping(value = "/public-key", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getPublicKey() {
        String publicKey = stripePublicKeyConfig.getPublicKey();
        Map<String, Object> map = new HashMap<>();
        map.put("key", publicKey);
        return ResponseEntity.ok(map);
    }

    @PostMapping(value = "/charge", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<String>> charge(@RequestBody PaymentRequest paymentRequest) {
        return paymentService.charge(paymentRequest)
                .map(paymentIntent -> ResponseEntity.ok().body(paymentIntent.toJson()))
                .onErrorResume(IllegalArgumentException.class, e -> Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body("{\"message\": \"The payment details provided are invalid. Please check your payment information and try again.\"}")))
                .onErrorResume(Exception.class, e -> Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("{\"message\": \"We couldn't process your payment at this time. Please try again later or contact support if the issue persists.\"}")));
    }

    @PostMapping(value = "/update", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
     public Mono<ResponseEntity<Map<String, Object>>> updateLicenseInformation(@RequestBody  PaymentStatusDTO paymentStatusDTO){
         return paymentService.updateLicenseInformation(paymentStatusDTO);
    }

    private Map<String, Object> createResponse(Object data) {
        Map<String, Object> response = new HashMap<>();
        response.put("data", data);
        return response;
    }

    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("message", message);
        return response;
    }

    @SuppressWarnings("unchecked")
    private String extractLicenseKey(ResponseEntity<Map<String, Object>> response) {
        if (response != null && response.getBody() != null) {
            Map<String, Object> responseBody = response.getBody();
            if (responseBody != null && responseBody.containsKey("data")) {
                Map<String, Object> data = (Map<String, Object>) responseBody.get("data");
                if (data != null && data.containsKey("licenseKey")) {
                    return (String) data.get("licenseKey");
                }
            }
        }
        return null;
    }
}
