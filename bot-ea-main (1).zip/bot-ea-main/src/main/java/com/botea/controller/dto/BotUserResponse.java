package com.botea.controller.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BotUserResponse {
    @JsonProperty("userProfileId")
    private Long userProfileId;
    @JsonProperty("bot_user_id")
    private Long botUserId;
    @JsonProperty("username")
    private String username;
    @JsonProperty("role")
    private String role;
    @JsonProperty("phone")
    private String phone;
    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("middle_name")
    private String middleName;
    @JsonProperty("last_name")
    private String lastName;
    @JsonProperty("legal_name")
    private String legalName;
    @JsonProperty("dob")
    private LocalDate dob;
    @JsonProperty("address_line1")
    private String addressLine1;
    @JsonProperty("address_line2")
    private String addressLine2;
    @JsonProperty("city")
    private String city;
    @JsonProperty("zip")
    private String zip;
    @JsonProperty("state")
    private String state;
    @JsonProperty("country")
    private String country;
    @JsonProperty("is_verified")
    private Boolean isVerified;
    @JsonProperty("is_two_factor_enabled")
    private Boolean isTwoFactorEnabled;
    @JsonProperty("two_factor_type")
    private String twoFactorType;
    @JsonProperty("created")
    private LocalDateTime created;
    @JsonProperty("createdBy")
    private Long createdBy;
    @JsonProperty("updated")
    private LocalDateTime updated = null;
    @JsonProperty("updatedBy")
    private Long updatedBy;
}
