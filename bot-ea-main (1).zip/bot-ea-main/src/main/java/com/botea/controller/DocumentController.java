package com.botea.controller;

import com.botea.dao.entity.CountryProfile;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import reactor.core.publisher.Mono;

import java.util.List;

@RestController
@RequestMapping("/api/document")
public class DocumentController {
    @PostMapping(path = "/fileUpload", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    public Mono<ResponseEntity<String>> fileUpload(@RequestPart List<MultipartFile> files) {
        return null;
    }
}