// Controller
package com.botea.controller;

import com.botea.controller.dto.BotUserResponse;
import com.botea.dao.entity.BotUser;
import com.botea.service.BotUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/users")
public class BotUserController {

    private final BotUserService botUserService;

    @Autowired
    public BotUserController(BotUserService botUserService) {
        this.botUserService = botUserService;
    }

    @GetMapping("/{id}")
    public Mono<ResponseEntity<BotUserResponse>> getUserById(@PathVariable Long id) {

        return botUserService.getUserById(id)
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @PutMapping("/{userProfileId}")
    public Mono<ResponseEntity<BotUserResponse>> updateUser(@PathVariable Long userProfileId, @RequestBody BotUser botUser){
        return botUserService.updateUser(userProfileId,botUser);
    }



}
