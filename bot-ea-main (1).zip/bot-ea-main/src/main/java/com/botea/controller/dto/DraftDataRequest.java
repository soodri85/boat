package com.botea.controller.dto;

public class DraftDataRequest {

    private String country;
    private Long businessId;
    private String taxform;

    // Getters and Setters

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }

    public String getTaxform() {
        return taxform;
    }

    public void setTaxform(String taxform) {
        this.taxform = taxform;
    }

    // Nested POJO for the taxform
    public static class TaxForm {
        private Object expensesData; // Adjust type based on actual structure
        private Object expensesCategories; // Adjust type based on actual structure
        private Object scheduleCForm; // Adjust type based on actual structure

        // Getters and Setters
        public Object getExpensesData() {
            return expensesData;
        }

        public void setExpensesData(Object expensesData) {
            this.expensesData = expensesData;
        }

        public Object getExpensesCategories() {
            return expensesCategories;
        }

        public void setExpensesCategories(Object expensesCategories) {
            this.expensesCategories = expensesCategories;
        }

        public Object getScheduleCForm() {
            return scheduleCForm;
        }

        public void setScheduleCForm(Object scheduleCForm) {
            this.scheduleCForm = scheduleCForm;
        }
    }
}
