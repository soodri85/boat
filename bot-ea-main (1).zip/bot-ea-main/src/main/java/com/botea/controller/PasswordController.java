package com.botea.controller;

import com.botea.controller.dto.UserAuthenticationDTO;
import com.botea.controller.dto.VerifyOtpRequest;
import com.botea.exception.BotApplicationException;
import com.botea.helper.SecurityHelper;
import com.botea.service.AuthInfo;
import com.botea.service.EmailService;
import com.botea.service.EmailOTPService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/otp")
public class PasswordController {

    @Autowired
    private EmailOTPService emailOTPService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private AuthInfo authInfo;

    @PostMapping("/send-otp")
    public Mono<ResponseEntity<String>> forgotPassword(@RequestBody String email) {
        if (email == null || email.isEmpty()) {
            return Mono.error(new BotApplicationException("Email is required"));
        }

        UserAuthenticationDTO user = SecurityHelper.getLoggedInUser();

        return emailOTPService.sendRegisterVerifyEmail(email)
                .flatMap(response -> {
                    if ("Success".equals(response)) {
                        return Mono.just(ResponseEntity.ok("Verification email successfully sent"));
                    } else {
                        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                .body("Unable to send verification email"));
                    }
                })
                .onErrorResume(e -> Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("An error occurred during email verification")));
    }

    @PostMapping("/verify")
    public Mono<ResponseEntity<String>> verifyOtp(@RequestBody VerifyOtpRequest request) {

        if (request == null || !StringUtils.hasText(request.getEmail())) {
            return Mono.error(new BotApplicationException("Invalid input"));
        }

        return emailOTPService.verifyOtp(request)
                .flatMap(response -> {
                    if ("Success".equals(response)) {
                        return Mono.just(ResponseEntity.ok("Email verified successfully!"));
                    } else {
                        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                .body("Unable to verify email"));
                    }
                })
                .onErrorResume(e -> Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body("An error occurred during email verification " + e.getMessage())));
    }

}
