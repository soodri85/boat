package com.botea.controller.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class LicenseManagementDTO {
    // Required fields for license generation
    private String countryCode;
    private String email;  // Can be comma-separated for multiple emails
    private BigDecimal totalCredit;
    private String licenseType;
    private Integer count;  // Optional, defaults to 1 for bulk generation

    // Optional fields
    private Boolean isRegistered;
    private String licenseKey;
    private Integer totalPagesScanned;
    private String comment;

    // Optional payment-related fields
    private String promoCode;
    private BigDecimal licenseCost;
    private BigDecimal totalPrice;
    private BigDecimal discount;
    private BigDecimal paidAmount;
    private boolean isDocumentTransaction;

    // Helper method to get email list
    public String[] getEmailList() {
        if (email == null || email.trim().isEmpty()) {
            return new String[0];
        }
        return email.split(",");
    }
}
