package com.botea.controller;

import com.botea.dao.entity.BusinessAddress;
import com.botea.service.BusinessAddressService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/business-address")
public class BusinessAddressController {

    private final BusinessAddressService service;

    public BusinessAddressController(BusinessAddressService service) {
        this.service = service;
    }

    @PostMapping
    public Mono<ResponseEntity<BusinessAddress>> createBusinessAddress(@RequestBody BusinessAddress businessAddress) {
        return service.saveBusinessAddress(businessAddress)
                .map(savedAddress -> ResponseEntity.status(HttpStatus.CREATED).body(savedAddress));
    }

    @GetMapping("/{id}")
    public Mono<ResponseEntity<BusinessAddress>> getBusinessAddressById(@PathVariable Long id) {
        return service.getBusinessAddressById(id)
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public Mono<ResponseEntity<Void>> deleteBusinessAddress(@PathVariable Long id) {
        return service.deleteBusinessAddress(id)
                .then(Mono.just(ResponseEntity.noContent().build()));
    }


    @PutMapping("/{businessAddressId}")
    public Mono<ResponseEntity<BusinessAddress>> updateBusinessAddress(@PathVariable Integer businessAddressId,
                                                         @RequestBody BusinessAddress businessAddress) {
        return service.updateBusinessAddress(businessAddressId, businessAddress);
    }
}
