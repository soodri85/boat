package com.botea.controller;

import com.botea.controller.dto.UserAuthenticationDTO;
import com.botea.controller.dto.UserProfileCountryDTO;
import com.botea.dao.entity.BusinessAddress;
import com.botea.dao.entity.UserProfile;
import com.botea.helper.SecurityHelper;
import com.botea.service.BusinessAddressService;
import com.botea.service.UserProfileService;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/user-profiles")
public class UserProfileController {

    private final UserProfileService userProfileService;
    private final BusinessAddressService businessAddressService;

    @Autowired
    public UserProfileController(UserProfileService userProfileService, BusinessAddressService businessAddressService) {
        this.userProfileService = userProfileService;
        this.businessAddressService = businessAddressService;
    }

    // Create or update a UserProfile
    @PostMapping
    public Mono<ResponseEntity<UserProfile>> createOrUpdateUserProfile(@RequestBody UserProfile userProfile) {
        return userProfileService.createOrUpdateUserProfile(userProfile)
                .map(savedProfile -> ResponseEntity.status(HttpStatus.CREATED).body(savedProfile));
    }

    // Retrieve a UserProfile by ID
    @GetMapping("/{id}")
    public Mono<ResponseEntity<UserProfile>> getUserProfileById(@PathVariable Long id) {
        return userProfileService.getUserProfileById(id)
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @PostMapping("/{id}/country")
    public Mono<ResponseEntity<List<UserProfileCountryDTO>>> addCountryProfileToUser(@PathVariable Long id, @RequestBody Map<String, Object> map){
        Long countryProfileId = Long.parseLong(map.get("countryProfileId").toString());
        return userProfileService.addCountryProfileToUser(id,countryProfileId)
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public Mono<ResponseEntity<List<UserProfileCountryDTO>>> updateUserProfile(@PathVariable Long id, @RequestBody Map<String, Object> map){
        Boolean isDefault = (Boolean) map.get("isDefault");
        return userProfileService.updateUserProfile(id,isDefault)
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    // Retrieve all UserProfiles
    @GetMapping
    public Flux<UserProfile> getAllUserProfiles() {
        return userProfileService.getAllUserProfiles();
    }

    // Delete a UserProfile by ID
    @DeleteMapping("/{id}")
    public Mono<ResponseEntity<Void>> deleteUserProfileById(@PathVariable Long id) {
        return userProfileService.deleteUserProfileById(id)
                .then(Mono.just(ResponseEntity.noContent().build()));
    }

    @GetMapping("/{id}/business-address")
    public Flux<BusinessAddress> getAllBusinessAddresses(@PathVariable Long id) {
        UserAuthenticationDTO user = SecurityHelper.getLoggedInUser();
        return businessAddressService.getAllBusinessAddresses(user.botUserId(), id);
    }

}
