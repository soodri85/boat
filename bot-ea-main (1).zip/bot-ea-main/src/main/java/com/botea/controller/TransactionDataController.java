package com.botea.controller;

import com.botea.controller.dto.TransactionUserDTO;
import com.botea.controller.dto.UpdateDraftRequest;
import com.botea.dao.entity.TransactionData;
import com.botea.service.TransactionDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/transaction")
public class TransactionDataController {

    @Autowired
    private TransactionDataService transactionDataService;

    @GetMapping("/{transactionDataId}/view-draft")
    public Mono<ResponseEntity<String>> getEditedData(@PathVariable Long transactionDataId) {
        return transactionDataService.getEditedData(transactionDataId)
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.noContent().build());
    }

    @PutMapping("/save-draft/{transactionDataId}/{year}/{documentId}")
    public Mono<ResponseEntity<String>> updateEditedData(
            @PathVariable Long transactionDataId,
            @PathVariable Integer year,
            @PathVariable String documentId,
            @RequestBody String newEditedData) {

        // Call the service method with the path variables
        return transactionDataService.updateEditedData(new UpdateDraftRequest(transactionDataId, year, documentId, newEditedData)
                )
                .map(updatedData -> ResponseEntity.ok(updatedData.getEditedData()))
                .onErrorResume(e -> Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("Error: " + e.getMessage())));
    }

    @GetMapping("/{user_profile_id}/user")
    public Flux<TransactionUserDTO> getTransactionDataByBotUserId(@PathVariable Long user_profile_id) {
        return transactionDataService.fetchTransactionDataByBotUserId(user_profile_id);
    }

}