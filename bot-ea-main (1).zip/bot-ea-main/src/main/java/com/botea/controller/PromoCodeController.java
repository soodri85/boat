package com.botea.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.botea.dao.entity.PromoCode;
import com.botea.service.PromoCodeService;

import reactor.core.publisher.Mono;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/promoCode")
public class PromoCodeController {

    @Autowired
    private PromoCodeService promoCodeService;

    private Map<String, Object> createResponse(Object data) {
        Map<String, Object> response = new HashMap<>();
        response.put("data", data);
        return response;
    }

    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("message", message);
        return response;
    }

    @PostMapping("/generate")
    public Mono<ResponseEntity<Map<String, Object>>> generatePromoCode(@RequestBody GeneratePromoCodeRequest request) {
        // Validate request
        if (request.getDiscount() == null || request.getDiscount() <= 0) {
            return Mono.just(ResponseEntity.badRequest()
                    .body(createErrorResponse("Please enter a valid discount percentage greater than 0")));
        }
        if (request.getExpiry() != null && request.getExpiry() <= 0) {
            return Mono.just(ResponseEntity.badRequest()
                    .body(createErrorResponse("Please enter a valid expiry period in days")));
        }

        // Set defaults for optional parameters
        int count = request.getCount() != null ? request.getCount() : 1;
        int usageLimit = request.getUsageLimit() != null ? request.getUsageLimit() : 1;

        // Validate bulk generation parameters if provided
        if (count <= 0) {
            return Mono.just(ResponseEntity.badRequest()
                    .body(createErrorResponse("Please enter a valid number of promo codes to generate")));
        }
        if (usageLimit <= 0) {
            return Mono.just(ResponseEntity.badRequest()
                    .body(createErrorResponse("Please enter a valid usage limit for the promo code")));
        }

        // Use bulk generation for both single and multiple codes
        return promoCodeService.generateBulkPromoCodes(
                request.getDiscount(), 
                request.getEmail(), 
                request.getExpiry(),
                count,
                usageLimit,
                request.getComment())
            .collectList()
            .map(promoCodes -> {
                // If it's a single code request, return just that code
                Object responseData = count == 1 ? promoCodes.get(0) : promoCodes;
                return ResponseEntity.ok().body(createResponse(responseData));
            })
            .onErrorResume(e -> {
                if (e.getMessage().contains("Unauthorized")) {
                    return Mono.just(ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                            .body(createErrorResponse("You don't have permission to generate promo codes. Please contact an administrator.")));
                }
                return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(createErrorResponse("We couldn't generate the promo code(s) at this time. Please try again later.")));
            });
    }

    @GetMapping("/validate")
    public Mono<ResponseEntity<Map<String, Object>>> validatePromoCode(@RequestParam String promoCode) {
        return promoCodeService.validatePromoCode(promoCode)
            .map(code -> ResponseEntity.ok().body(createResponse(code)))
            .onErrorResume(e -> {
                String message = e.getMessage();
                if (message.contains("expired")) {
                    return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                            .body(createErrorResponse("This promo code has expired. Please try a different code.")));
                } else if (message.contains("usage limit")) {
                    return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                            .body(createErrorResponse("This promo code has reached its maximum usage limit. Please try a different code.")));
                } else {
                    return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                            .body(createErrorResponse("This promo code is invalid. Please check and try again.")));
                }
            });
    }

    @PostMapping("/use")
    public Mono<ResponseEntity<Map<String, Object>>> markPromoCodeAsUsed(
            @RequestParam String promoCode,
            @RequestParam String licenseKey) {
        return promoCodeService.markPromoCodeAsUsed(promoCode, licenseKey)
            .map(code -> ResponseEntity.ok().body(createResponse(code)))
            .onErrorResume(e -> {
                String message = e.getMessage();
                if (message.contains("expired")) {
                    return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                            .body(createErrorResponse("This promo code has expired and cannot be used.")));
                } else if (message.contains("usage limit")) {
                    return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                            .body(createErrorResponse("This promo code has already been used the maximum number of times allowed.")));
                } else {
                    return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                            .body(createErrorResponse("Unable to apply the promo code. Please ensure both the promo code and license key are valid.")));
                }
            });
    }

    @GetMapping("/all")
    public Mono<ResponseEntity<Map<String, Object>>> getAllPromoCodes() {
        return promoCodeService.getAllPromoCodes()
            .collectList()
            .map(codes -> ResponseEntity.ok().body(createResponse(codes)))
            .onErrorResume(e -> Mono.just(ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(createErrorResponse("You don't have permission to view promo codes. Please contact an administrator."))));
    }

    @GetMapping("/active")
    public Mono<ResponseEntity<Map<String, Object>>> getActivePromoCodes() {
        return promoCodeService.getAllPromoCodes()
            .filter(code -> code.getTimesUsed() < code.getUsageLimit())
            .collectList()
            .map(codes -> ResponseEntity.ok().body(createResponse(codes)))
            .onErrorResume(e -> Mono.just(ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(createErrorResponse("You don't have permission to view active promo codes. Please contact an administrator."))));
    }

    @GetMapping("/used")
    public Mono<ResponseEntity<Map<String, Object>>> getUsedPromoCodes() {
        return promoCodeService.getAllPromoCodes()
            .filter(code -> code.getTimesUsed() >= code.getUsageLimit())
            .collectList()
            .map(codes -> ResponseEntity.ok().body(createResponse(codes)))
            .onErrorResume(e -> Mono.just(ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(createErrorResponse("You don't have permission to view used promo codes. Please contact an administrator."))));
    }

    @PostMapping("/resend-email")
    public Mono<ResponseEntity<Map<String, Object>>> resendPromoCodeEmail(
            @RequestParam String promoCodeValue,
            @RequestParam String email) {
        return promoCodeService.resendPromoCodeEmail(promoCodeValue, email)
                .map(success -> ResponseEntity.ok().body(createResponse("Promo code has been sent to your email")))
                .onErrorResume(e -> {
                    String message = e.getMessage();
                    if (message.contains("Unauthorized")) {
                        return Mono.just(ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                                .body(createErrorResponse("You don't have permission to resend promo code emails. Please contact an administrator.")));
                    } else if (message.contains("usage limit")) {
                        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                .body(createErrorResponse("This promo code has already been used and cannot be resent.")));
                    } else if (message.contains("not found")) {
                        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                .body(createErrorResponse("The specified promo code could not be found.")));
                    } else {
                        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                .body(createErrorResponse("Unable to send the promo code email. Please try again later.")));
                    }
                });
    }

    // Request class for generating promo code
    public static class GeneratePromoCodeRequest {
        private Double discount;
        private String email;  // Can be comma-separated for multiple emails
        private Integer expiry;
        private Integer count;  // Optional, defaults to 1
        private Integer usageLimit;  // Optional, defaults to 1
        private String comment;  // Optional comment for the promo code

        // Helper method to get email list
        public String[] getEmailList() {
            if (email == null || email.trim().isEmpty()) {
                return new String[0];
            }
            return email.split(",");
        }

        // Getters and setters
        public Double getDiscount() {
            return discount;
        }

        public void setDiscount(Double discount) {
            this.discount = discount;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public Integer getExpiry() {
            return expiry;
        }

        public void setExpiry(Integer expiry) {
            this.expiry = expiry;
        }

        public Integer getCount() {
            return count;
        }

        public void setCount(Integer count) {
            this.count = count;
        }

        public Integer getUsageLimit() {
            return usageLimit;
        }

        public void setUsageLimit(Integer usageLimit) {
            this.usageLimit = usageLimit;
        }

        public String getComment() {
            return comment;
        }

        public void setComment(String comment) {
            this.comment = comment;
        }
    }
} 