package com.botea.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.botea.dao.entity.CountryProfile;
import com.botea.helper.dto.CountryLookUpDTO;
import com.botea.service.CountryProfileService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/country-profiles")
public class CountryProfileController {

	private final CountryProfileService countryProfileService;

	@Autowired
	public CountryProfileController(CountryProfileService countryProfileService) {
		this.countryProfileService = countryProfileService;
	}

	// Create or update a country profile
	@PostMapping
	public Mono<ResponseEntity<CountryProfile>> createOrUpdateCountryProfile(
			@RequestBody CountryProfile countryProfile) {
		return countryProfileService.createOrUpdateCountryProfile(countryProfile)
				.map(savedProfile -> ResponseEntity.status(HttpStatus.CREATED).body(savedProfile));
	}

	// Get a country profile by ID
	@GetMapping("/{id}")
	public Mono<ResponseEntity<CountryProfile>> getCountryProfileById(@PathVariable Long id) {
		return countryProfileService.getCountryProfileById(id).map(profile -> ResponseEntity.ok(profile))
				.defaultIfEmpty(ResponseEntity.notFound().build());
	}

	// Delete a country profile by ID
	@DeleteMapping("/{id}")
	public Mono<ResponseEntity<Void>> deleteCountryProfileById(@PathVariable Long id) {
		return countryProfileService.deleteCountryProfileById(id).then(Mono.just(ResponseEntity.noContent().build()));
	}

}
