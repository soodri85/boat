package com.botea.controller.dto;

import lombok.Data;

import java.util.List;

@Data
public class BatchResponse {
    private String extractionId;
    private String batchId;
    private String transactionStartDate;
    private String transactionEndDate;
    private Double totalDebit;
    private Double totalCredit;
    private String status;
    private Integer totalPagesScanned;
    private List<File> files;
    private List<Category> categories;
    private Long transactionId;
    private Boolean finished;
    private String template_name;
    private Integer year;

    @Data
    public static class File {
        private String fileId;
        private String fileName;
        private String status;
        private String transactionStartDate;
        private String transactionEndDate;
        private Double totalDebit;
        private Double totalCredit;
        private Integer totalNumberOfTransactions;
        private Integer pagesScanned;
        private String url;
    }

    @Data
    public static class Category {
        private String categoryName;
        private Integer numberOfTransactions;
        private Double totalDebit;
        private Double totalCredit;
        private List<Transaction> transactions;

        @Data
        public static class Transaction {
            private String date;
            private String details;
            private Double debit;
            private Double credit;
            private String fileId;
        }
    }
}
