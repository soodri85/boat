package com.botea.controller;

import com.botea.controller.dto.DashboardStatistics;
import com.botea.service.DashboardService;
import com.botea.helper.SecurityHelper;
import com.botea.controller.dto.UserAuthenticationDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.time.Year;

@RestController
@RequestMapping("/api/v1/admin/dashboard")
@RequiredArgsConstructor
public class AdminDashboardController {

    private final DashboardService dashboardService;

    private Mono<Void> validateAdminAccess() {
        UserAuthenticationDTO user = SecurityHelper.getLoggedInUser();
        if (!"ADM".equals(user.role())) {
            return Mono.error(new RuntimeException("Unauthorized: Admin access required"));
        }
        return Mono.empty();
    }

    @GetMapping("/statistics")
    public Mono<DashboardStatistics.BasicStats> getBasicStats() {
        return validateAdminAccess()
            .then(dashboardService.getBasicStats());
    }

    @GetMapping("/revenue-stats")
    public Mono<DashboardStatistics.RevenueStats> getRevenueStats() {
        return validateAdminAccess()
            .then(dashboardService.getRevenueStats());
    }

    @GetMapping("/active-user-stats")
    public Mono<DashboardStatistics.ActiveUserStats> getActiveUserStats() {
        return validateAdminAccess()
            .then(dashboardService.getActiveUserStats());
    }

    @GetMapping("/transaction-stats")
    public Mono<DashboardStatistics.TransactionStats> getTransactionStats(
            @RequestParam(required = false) Integer year) {
        int targetYear = year != null ? year : Year.now().getValue();
        return validateAdminAccess()
            .then(dashboardService.getTransactionStats(targetYear));
    }

    @GetMapping("/user-registration-stats")
    public Mono<DashboardStatistics.UserStats> getUserRegistrationStats(
            @RequestParam(required = false) Integer year) {
        int targetYear = year != null ? year : Year.now().getValue();
        return validateAdminAccess()
            .then(dashboardService.getUserRegistrationStats(targetYear));
    }

    @GetMapping("/subscription-stats")
    public Mono<DashboardStatistics.SubscriptionStats> getSubscriptionStats(
            @RequestParam(required = false) Integer year) {
        int targetYear = year != null ? year : Year.now().getValue();
        return validateAdminAccess()
            .then(dashboardService.getSubscriptionStats(targetYear));
    }
} 