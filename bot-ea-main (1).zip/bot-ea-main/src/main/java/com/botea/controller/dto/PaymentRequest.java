package com.botea.controller.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentRequest {
    @NotBlank(message = "emailID is required")
    private String emailID;
    @NotBlank(message = "currency is required")
    private String currency;
    @NotBlank(message = "amount is required")
    private Long amount;
    private String promoCode;
    private String countryCode;
    private String licenseType;
    private Long licenseCount;
    private Long userProfileId;
    private Boolean isRenewal;
    private Long totalCredits;
}
