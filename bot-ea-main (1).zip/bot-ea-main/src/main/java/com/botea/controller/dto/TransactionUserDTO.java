package com.botea.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransactionUserDTO {

    private LocalDateTime transactionDate;
    private String businessName;
    private String taxForm;
    private String country;
    private String uploaded_document_key;
    private String downloaded_document_key;
    private Boolean is_document_generated;
    private Integer transaction_data_id;
}
