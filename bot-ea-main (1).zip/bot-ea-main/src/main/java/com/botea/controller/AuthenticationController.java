package com.botea.controller;

import com.botea.controller.dto.LoginRequest;
import com.botea.controller.dto.UserProfileCountryDTO;
import com.botea.dao.entity.BotUser;
import com.botea.dao.entity.Token;
import com.botea.helper.SecurityHelper;
import com.botea.service.*;
import com.botea.utils.EmailType;
import com.botea.utils.JwtTokenUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.ReactiveAuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@Slf4j
public class AuthenticationController {

    private static final Logger logger = LoggerFactory.getLogger(AuthenticationController.class);
    ObjectMapper objectMapper = new ObjectMapper();


    private final ReactiveAuthenticationManager authenticationManager;
    private final JwtTokenUtil jwtTokenUtil;
    private final CustomReactiveUserDetailsService userDetailsService;
    private final TokenService tokenService;
    private final UniqueIdGenerator uniqueIdGenerator;
    private UserProfileService userProfileService;
    private final EmailOTPService emailOTPService;

    @Autowired
    public AuthenticationController(ReactiveAuthenticationManager authenticationManager,
                                    JwtTokenUtil jwtTokenUtil,
                                    CustomReactiveUserDetailsService userDetailsService,
                                    TokenService tokenService,
                                    UniqueIdGenerator uniqueIdGenerator, UserProfileService userProfileService,
                                    EmailOTPService emailOTPService, EmailOTPService emailOTPService1) {
        this.authenticationManager = authenticationManager;
        this.jwtTokenUtil = jwtTokenUtil;
        this.userDetailsService = userDetailsService;
        this.tokenService = tokenService;
        this.uniqueIdGenerator = uniqueIdGenerator;
        this.userProfileService = userProfileService;
        this.emailOTPService = emailOTPService1;
    }

    @PostMapping("/login")
    public Mono<ResponseEntity<Map<String, Object>>> login(
            @Valid @RequestBody LoginRequest loginRequest,
            ServerHttpRequest servletRequest
    ) {
        log.info("Login attempt for user: {}", loginRequest.getUsername());

        return authenticationManager
                .authenticate(new UsernamePasswordAuthenticationToken(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()
                ))
                .flatMap(authentication -> userDetailsService.findUserByUsername(authentication.getName()))
                .flatMap(userDetails -> {
                    // Generate tokens
                    String accessToken = jwtTokenUtil.generateToken(userDetails.getUsername());
                    String refreshToken = jwtTokenUtil.generateRefreshToken(userDetails.getUsername());

                    // Create new token entity
                    Token token = createToken(userDetails, accessToken, servletRequest);

                    // Process token and build response
                    return processTokenAndBuildResponse(
                            token,
                            userDetails,
                            accessToken,
                            refreshToken
                    );
                })
                .onErrorResume(this::handleLoginError);
    }

    private Token createToken(BotUser userDetails, String accessToken, ServerHttpRequest servletRequest) {
        SecurityHelper.UserAgentDTO userDeviceInfo = SecurityHelper.getUserDeviceInfo(servletRequest);

        Token token = new Token();
        token.setToken(accessToken);
        token.setIsLoggedOut(false);
        token.setIsActive(true);
        token.setBotUserId(userDetails.getBotUserId());
        token.setUpdated(null);
        token.setLoginTime(LocalDateTime.now(ZoneId.systemDefault()));
        token.setUserAgent(userDeviceInfo.getUserAgent());
        token.setIpAddress(userDeviceInfo.getIpAddress());

        return token;
    }

    private Mono<ResponseEntity<Map<String, Object>>> processTokenAndBuildResponse(
            Token token,
            BotUser userDetails,
            String accessToken,
            String refreshToken
    ) {
        return tokenService.deactivatePreviousTokens(userDetails.getBotUserId())
                .then(tokenService.save(token))
                .flatMap(savedToken -> buildUserProfileResponse(
                        userDetails,
                        accessToken,
                        refreshToken
                ));
    }

    private Mono<ResponseEntity<Map<String, Object>>> buildUserProfileResponse(
            BotUser userDetails,
            String accessToken,
            String refreshToken
    ) {
        return userProfileService.getUserProfilesWithCountryAndLicenseInfo(userDetails.getBotUserId())  // Use the new method with the join
                .collectList() // Collect the Flux into a List
                .flatMap(userProfiles -> {
                    List<Map<String, Object>> profilesList = mapUserProfiles(userProfiles);
                    Map<String, Object> response = new HashMap<>();
                    prepareResponseBase(response, userDetails, profilesList);

                    if (userDetails.getIsTwoFactorEnabled() &&  userDetails.getIsVerified()) {
                        return sendTwoFactorOtp(response, userDetails);
                    }
                    else if (!userDetails.getIsVerified()) {
                        return sendRegistrationOtp(userDetails);
                    } else {
                        response.put("token", accessToken);
                        response.put("refresh_token", refreshToken);
                        return Mono.just(ResponseEntity.ok(response));
                    }
                });
    }

    private Mono<ResponseEntity<Map<String, Object>>> sendRegistrationOtp(BotUser userDetails) {
        Map<String, Object> response = new HashMap<>();

        return emailOTPService.sendRegisterVerifyEmail(userDetails.getUsername())
                .flatMap(result -> {
                    if ("Success".equals(result)) {
                        response.put("is_verified", false);
                        response.put("otp_type", EmailType.REGISTRATION.getOtpType());
                        response.put("otp_type_display", EmailType.REGISTRATION.getDisplayName());
                        response.put("message", "OTP sent on the email");
                        return Mono.just(ResponseEntity.ok(response));
                    } else {
                        response.put("is_verified", false);
                        response.put("message", "Unable to send OTP to email.");
                        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response));
                    }
                })
                .onErrorResume(e -> {
                    response.put("is_verified", false);
                    response.put("message", "An error occurred while sending OTP");
                    return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response));
                });
    }

    private Mono<ResponseEntity<Map<String, Object>>> sendTwoFactorOtp(Map<String, Object> response, BotUser userDetails) {
        response.put("token", null);
        response.put("refresh_token", null);
        return emailOTPService.sendOTPAndVerifyUser(userDetails.getUsername(), EmailType.TWO_FACTOR.getDisplayName(), "Account Verification for Bot-EA", EmailType.TWO_FACTOR)
                .flatMap(result -> {
                    if ("Success".equals(result)) {
                        response.put("otp_type", EmailType.TWO_FACTOR.getOtpType());
                        response.put("otp_type_display", EmailType.TWO_FACTOR.getDisplayName());
                        response.put("message", "OTP sent on the email");
                        return Mono.just(ResponseEntity.ok(response));
                    } else {
                        response.put("message", "Unable to send OTP to email.");
                        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response));
                    }
                })
                .onErrorResume(e -> {
                    response.put("message", "An error occurred while sending OTP");
                    return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response));
                });

    }

    private void prepareResponseBase(Map<String, Object> response, BotUser userDetails, List<Map<String, Object>> profilesList) {
        response.put("country", userDetails.getCountry());
        response.put("username", userDetails.getUsername());
        response.put("legalName", userDetails.getLegalName());
        response.put("role", userDetails.getRole());
        response.put("is_two_factor_enabled", userDetails.getIsTwoFactorEnabled());
        response.put("userProfiles", profilesList);
    }

    private List<Map<String, Object>> mapUserProfiles(List<UserProfileCountryDTO> userProfiles) {
        return  userProfiles.stream()
                .map(profile -> {
                    Map<String, Object> profileMap = new HashMap<>();
                    profileMap.put("userProfileId", profile != null ? profile.getUserProfileId() : "N/A");
                    profileMap.put("countryProfileId", profile.getCountryProfileId() != null ? profile.getCountryProfileId() : "N/A");
                    profileMap.put("isDefault", profile.getIsDefault() != null ? profile.getIsDefault() : false);
                    profileMap.put("isVerified", profile.getIsVerified() != null ? profile.getIsVerified() : false);
                    profileMap.put("countryName", profile.getCountryName() != null ? profile.getCountryName() : "N/A");
                    profileMap.put("countryCode", profile.getCountryCode() != null ? profile.getCountryCode() : "N/A");
                    profileMap.put("language", profile.getLanguage() != null ? profile.getLanguage() : "N/A");
                    profileMap.put("languageCode", profile.getLanguageCode() != null ? profile.getLanguageCode() : "N/A");
                    profileMap.put("currency", profile.getCurrency() != null ? profile.getCurrency() : "N/A");
                    profileMap.put("isRegistered", profile.getIsRegistered() != null ? profile.getIsRegistered() : false);
                    profileMap.put("isExpired", profile.getIsExpired() != null ? profile.getIsExpired() : false);
                    profileMap.put("totalCredit", profile.getTotalCredit() != null ? profile.getTotalCredit() : 0);
                    profileMap.put("remainingCredit", profile.getRemainingCredit() != null ? profile.getRemainingCredit() : 0);
                    List<Map<String, Object>> documentsList = profile.getDocuments().stream()
                            .map(document -> {
                                Map<String, Object> documentMap = new HashMap<>();
                                documentMap.put("documentId", document.getDocumentId() != null ? document.getDocumentId() : "N/A");
                                documentMap.put("documentName", document.getDocumentName() != null ? document.getDocumentName() : "N/A");
                                return documentMap;
                            })
                            .collect(Collectors.toList());
                    profileMap.put("documents", documentsList != null ? documentsList : "N/A");

                    return profileMap;
                })
                .collect(Collectors.toList());
    }

    private Mono<ResponseEntity<Map<String, Object>>> handleLoginError(Throwable e) {
        if (e instanceof BadCredentialsException) {
            log.warn("Login failed due to bad credentials");
            return Mono.just(ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "Invalid credentials")));
        }

        log.error("Login failed", e);
        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "An unexpected error occurred")));
    }

    @PostMapping("/refresh-token")
    public Mono<ResponseEntity<Map<String, String>>> refreshToken(@RequestBody String refreshToken, ServerHttpRequest servletRequest) {
        if (refreshToken == null || refreshToken.isEmpty()) {
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", "Refresh token is required")));
        }

        try {
            // Extract username from the refresh token
            String username = jwtTokenUtil.extractUsernameFromRefreshToken(refreshToken);
            if (username == null) {
                return Mono.just(ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Invalid refresh token")));
            }

            // Validate the refresh token (including expiration check)
            if (!jwtTokenUtil.isTokenValid(username, refreshToken)) {
                return Mono.just(ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Expired or invalid refresh token")));
            }

            Mono<BotUser> userByUsername = userDetailsService.findUserByUsername(username);
            return userByUsername
                    .flatMap(userDetails -> {
                        // Generate a new access token
                        String newAccessToken = jwtTokenUtil.generateToken(userDetails.getUsername());
                        String newRefreshToken = jwtTokenUtil.generateRefreshToken(userDetails.getUsername());

                        Token token = getToken(userDetails, newAccessToken, servletRequest);
                        return tokenService.refreshToken(token, userDetails.getBotUserId(), newAccessToken, newRefreshToken);
                    })
                    .onErrorResume(e -> {
                        logger.error("Error refreshing token", e);
                        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("error", "Internal Server Error")));
                    });
        } catch (Exception e) {
            logger.error("Invalid refresh token", e);
            return Mono.just(ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Invalid refresh token")));
        }
    }

    private static Token getToken(BotUser userDetails, String newAccessToken, ServerHttpRequest servletRequest) {
        // Persist the new token
        SecurityHelper.UserAgentDTO userDeviceInfo = SecurityHelper.getUserDeviceInfo(servletRequest);
        Token token = new Token();
        token.setToken(newAccessToken);
        token.setIsLoggedOut(false);
        token.setIsActive(true);
        token.setBotUserId(userDetails.getBotUserId());
        token.setUpdated(LocalDateTime.now(ZoneId.systemDefault()));// wherever it is deployed, it'll take that time.//TODO
        token.setIsRefresh(true);

        token.setUserAgent(userDeviceInfo.getUserAgent());
        token.setIpAddress(userDeviceInfo.getIpAddress());
        return token;
    }

    @PostMapping("/logout")
    public Mono<ResponseEntity<Void>> logout(ServerWebExchange exchange) {
        // Extract the Authorization header
        String bearerToken = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);

        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            // Remove "Bearer " prefix to extract the actual token
            String token = bearerToken.substring(7);

            // Check if the token is valid in the database
            return tokenService.isTokenValidInDatabase(token)
                    .flatMap(isValid -> {
                        if (isValid) {
                            // If the token is valid, mark it as logged out
                            return tokenService.markTokenAsLoggedOut(token)
                                    .then(Mono.just(ResponseEntity.ok().<Void>build())); // Explicitly type ResponseEntity<Void>
                        } else {
                            // Token is not valid; return Unauthorized
                            return Mono.just(ResponseEntity.status(HttpStatus.UNAUTHORIZED).<Void>build());
                        }
                    })
                    .onErrorResume(e -> {
                        // Handle unexpected errors
                        log.error("Error while logging out token: ", e);
                        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).<Void>build());
                    });
        } else {
            // If the token is missing or doesn't start with "Bearer ", return Bad Request
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).<Void>build());
        }
    }


}
