package com.botea.controller;

import com.botea.controller.dto.UserAuthenticationDTO;
import com.botea.helper.SecurityHelper;
import com.botea.service.PdfService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.Map;

@RestController
@RequestMapping("/api/pdf")
public class PdfController {

    @Autowired
    private PdfService pdfService;

    @PostMapping(value = "/generate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_PDF_VALUE)
    public Mono<ResponseEntity<byte[]>> generatePdf(@RequestBody Map<String, Object> inputData) {

        UserAuthenticationDTO user = SecurityHelper.getLoggedInUser();

        return pdfService.generatePdf(user, inputData)
                .map(pdfData -> {
                    HttpHeaders headers = new HttpHeaders();
                    headers.setContentType(MediaType.APPLICATION_PDF);
                    headers.setContentDisposition(ContentDisposition.builder("inline").filename("generated.pdf").build());
                    return new ResponseEntity<>(pdfData, headers, HttpStatus.OK);
                })
                .onErrorResume(e -> {
                    // Log the error for debugging
                    System.err.println("Error generating PDF: " + e.getMessage());
                    return Mono.just(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }
}
