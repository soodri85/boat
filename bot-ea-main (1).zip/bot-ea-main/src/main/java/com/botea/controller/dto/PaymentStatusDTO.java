package com.botea.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentStatusDTO {
    private String paymentId;
    private String status;
    private String countryCode;
    private String email;
    private BigDecimal totalCredit;
    private String licenseType;
    private String promoCode;
    private String idempotencyKey;
    private Boolean isRenewal;
    private BigDecimal totalPrice;
    private BigDecimal discount;
    private BigDecimal paidAmount;
}
