package com.botea.controller.dto;

public record UserAuthenticationDTO(String username, String role, Long botUserId) {

}
