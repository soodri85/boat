package com.botea.controller.dto;

import lombok.Getter;

@Getter
public class VerifyOtpRequest {
    private Integer otp;
    private String otp_type;
    private String email;
}
