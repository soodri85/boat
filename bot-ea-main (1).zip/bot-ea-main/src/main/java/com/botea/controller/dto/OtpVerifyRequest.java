package com.botea.controller.dto;

import lombok.Getter;

@Getter
public class OtpVerifyRequest {
    private Integer otp;
    private String otpType;
}
