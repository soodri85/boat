package com.botea.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;

import com.botea.controller.dto.LicenseManagementDTO;
import com.botea.service.LicenseManagementService;

import reactor.core.publisher.Mono;
import java.util.Map;
import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("/api/licenseManagement")
public class LicenseManagementController {

	@Autowired
	private LicenseManagementService licenseManagementService;

	private Map<String, Object> createResponse(Object data) {
		Map<String, Object> response = new HashMap<>();
		response.put("data", data);
		return response;
	}

	private Map<String, Object> createErrorResponse(String message) {
		Map<String, Object> response = new HashMap<>();
		response.put("message", message);
		return response;
	}

	@PostMapping("/generateLicense")
	public Mono<ResponseEntity<Map<String, Object>>> generateLicense(@RequestBody LicenseManagementDTO licenseManagementDTO) {
		return licenseManagementService.generateLicense(licenseManagementDTO)
			.map(response -> ResponseEntity.ok().body(response.getBody()))
			.defaultIfEmpty(ResponseEntity.ok().body(createResponse("License generated successfully")))
			.onErrorResume(e -> {
				String message = e.getMessage();
				if (message.contains("Invalid country code")) {
					return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body(createErrorResponse("The country code provided is not supported. Please select a valid country.")));
				} else if (message.contains("Invalid license type")) {
					return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body(createErrorResponse("Please select a valid license type from the available options.")));
				} else if (message.contains("Country not found")) {
					return Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND)
						.body(createErrorResponse("The selected country is not available in our system. Please contact support.")));
				} else {
					return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
						.body(createErrorResponse("We couldn't generate your license at this time. Please try again later.")));
				}
			});
	}

	@PostMapping("/registerLicense")
	public Mono<ResponseEntity<Map<String, Object>>> registerLicense(@RequestBody LicenseManagementDTO licenseManagementDTO) {
		return licenseManagementService.registerLicense(licenseManagementDTO)
			.map(response -> {
				if (response.getStatusCode().is2xxSuccessful()) {
					return ResponseEntity.ok().body(Map.of("message", (Object) response.getBody()));
				} else {
					return ResponseEntity.status(response.getStatusCode())
						.body(createErrorResponse(response.getBody()));
				}
			});
	}

	@PostMapping("/renewLicense")
	public Mono<ResponseEntity<Map<String, Object>>> renewLicense(@RequestBody LicenseManagementDTO licenseManagementDTO) {
		return licenseManagementService.renewLicense(licenseManagementDTO)
			.map(response -> ResponseEntity.ok().body(createResponse(response.getBody())))
			.defaultIfEmpty(ResponseEntity.ok().body(createResponse("License renewed successfully")))
			.onErrorResume(e -> {
				String message = e.getMessage();
				if (message.contains("No active license found")) {
					return Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND)
						.body(createErrorResponse("We couldn't find an active license for your account. Please check your email and country selection.")));
				} else if (message.contains("License has expired")) {
					return Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN)
						.body(createErrorResponse("Your license has expired. Please purchase a new license to continue.")));
				} else {
					return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
						.body(createErrorResponse("We couldn't renew your license at this time. Please try again later.")));
				}
			});
	}

	@GetMapping("/fetchLicenseInfo")
	public Mono<ResponseEntity<Map<String, Object>>> fetchLicenseInfo(
			@RequestParam Long userProfileId,
			@RequestParam(required = false) String status) {
		return licenseManagementService.fetchLicenseInfo(userProfileId, status)
			.defaultIfEmpty(ResponseEntity.ok().body(Map.of(
				"message", "No licenses found for your account",
				"data", List.of()
			)))
			.onErrorResume(e -> {
				String message = e.getMessage();
				if (message.contains("User profile not found")) {
					return Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND)
						.body(createErrorResponse("We couldn't find your user profile. Please ensure you're logged in.")));
				} else {
					return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
						.body(createErrorResponse("We couldn't retrieve your license information at this time. Please try again later.")));
				}
			});
	}

	@PostMapping("/resend-email")
	public Mono<ResponseEntity<Map<String, Object>>> resendLicenseEmail(
			@RequestParam String licenseKey,
			@RequestParam String email) {
		return licenseManagementService.resendLicenseEmail(licenseKey, email)
			.map(success -> ResponseEntity.ok().body(createResponse("License details have been sent to your email")))
			.onErrorResume(e -> {
				String message = e.getMessage();
				if (message.contains("Unauthorized")) {
					return Mono.just(ResponseEntity.status(HttpStatus.UNAUTHORIZED)
						.body(createErrorResponse("You don't have permission to resend license emails. Please contact an administrator.")));
				} else if (message.contains("License not found")) {
					return Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND)
						.body(createErrorResponse("We couldn't find a license with the provided key. Please check and try again.")));
				} else {
					return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
						.body(createErrorResponse("We couldn't send the license email at this time. Please try again later.")));
				}
			});
	}
}
