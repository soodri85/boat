package com.botea.controller.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.springframework.data.relational.core.mapping.Column;
import lombok.Data;

@Data
public class LicenseManagementResponseDTO {
	@Column("country_code")
	private String countryCode;
	
	@Column("email")
	private String email;
	
	@Column("total_credit")
	private BigDecimal totalCredit;
	
	@Column("remaining_credit")
	private BigDecimal remainingCredit;
	
	@Column("license_type")
	private String licenseType;
	
	@Column("is_registered")
	private Boolean isRegistered;
	
	@Column("is_expired")
	private Boolean isExpired;
	
	@Column("license_key")
	private String licenseKey;
	
	@Column("date_purchased")
	private LocalDateTime datePurchased;
}
