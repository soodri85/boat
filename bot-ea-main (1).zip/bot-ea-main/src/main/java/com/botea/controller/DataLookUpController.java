package com.botea.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.botea.helper.DataLookUpHelper;
import com.botea.helper.dto.CountryLookUpDTO;
import com.botea.helper.dto.NAICSLookUpDTO;
import com.botea.helper.dto.TaxInfoLookUpDTO;

import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/api/lookup/")
public class DataLookUpController {

	@Autowired
	private Flux<CountryLookUpDTO> countryLookUp;

	@Autowired
	private Flux<TaxInfoLookUpDTO> taxInfoLookUp;

	@Autowired
	private DataLookUpHelper dataLookUpHelper;

	@GetMapping("/fetchCountryLookUp")
	public Flux<CountryLookUpDTO> fetchCountryLookUp() {
		return countryLookUp;
	}

	@GetMapping("/fetchNAICSLookUp")
	public Flux<NAICSLookUpDTO> fetchNAICSLookUp(@RequestParam String countryCode) {
		return dataLookUpHelper.fetchNAICSLookUp(countryCode);
	}

	@GetMapping("/fetchTaxInfoLookUp")
	public Flux<TaxInfoLookUpDTO> fetchTaxInfoLookUp() {
		return taxInfoLookUp;
	}
}
