package com.botea.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FileUploadResponse {
    private String status;
    private String extractionId;
    private String batchId;
    private List<FileDetails> files;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FileDetails {
        private String fileId;
        private String fileName;
        private int numberOfPages;
        private String url;
    }
}
