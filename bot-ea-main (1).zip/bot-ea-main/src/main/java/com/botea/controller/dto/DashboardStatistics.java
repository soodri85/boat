package com.botea.controller.dto;

import lombok.Data;
import lombok.Builder;
import java.util.Map;

@Data
@Builder
public class DashboardStatistics {
    private RevenueStats revenueStats;
    private ActiveUserStats activeUserStats;
    private TransactionStats transactionStats;
    private UserStats userStats;
    private SubscriptionStats subscriptionStats;

    @Data
    @Builder
    public static class BasicStats {
        private Double totalRevenue;
        private Integer totalSubscriptions;
        private Integer activeUsers;
    }

    @Data
    @Builder
    public static class RevenueStats {
        private Double totalRevenue;
        private Integer totalSubscriptions;
    }

    @Data
    @Builder
    public static class ActiveUserStats {
        private Integer activeUsers;
        private Integer daysWindow;
    }

    @Data
    @Builder
    public static class TransactionStats {
        private Integer year;
        private MonthlyFormCounts[] monthlyTransactions; // Array of 12 months (0-11)
    }

    @Data
    @Builder
    public static class MonthlyFormCounts {
        private Integer scheduleC;
        private Integer scheduleE;
        private Integer t776;
        private Integer t2125;
    }

    @Data
    @Builder
    public static class UserStats {
        private Integer year;
        private Integer[] monthlyRegistrations; // Array indices 0-11 for months
    }

    @Data
    @Builder
    public static class SubscriptionStats {
        private Integer year;
        private Integer[] monthlySubscriptions; // Array indices 0-11 for months
    }
} 