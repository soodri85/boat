package com.botea.controller;

import com.botea.controller.dto.UserAuthenticationDTO;
import com.botea.dao.entity.BotUser;
import com.botea.helper.SecurityHelper;
import com.botea.service.AuthInfo;
import com.botea.service.DataExtractionService;
import com.botea.service.RegisterAndLoginService;

import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * @author Praveen
 */

@RestController
@RequestMapping("/api")
public class RegisterAndLoginController {

    private static final Logger logger = LoggerFactory.getLogger(RegisterAndLoginController.class);

    private final DataExtractionService dataExtractionService;
    private final AuthInfo authInfo;
    private RegisterAndLoginService registerAndLoginService;

    public RegisterAndLoginController(
            DataExtractionService dataExtractionService,
            AuthInfo authInfo,
            RegisterAndLoginService registerAndLoginService) {
        this.dataExtractionService = dataExtractionService;
        this.authInfo = authInfo;
        this.registerAndLoginService = registerAndLoginService;
    }

    @PostMapping("/register")
    public Mono<Object> register(@Valid @RequestBody BotUser botUser, @RequestParam String[] countryCodes) {
        return registerAndLoginService.registerUser(botUser, countryCodes);
    }

    @PostMapping("/purchaseLicense")
    public Mono<String> purchaseLicense() {
        return Mono.just("Welcome to license purchase!");
    }

    @PostMapping("/view")
    public Mono<String> processRequest() {

        UserAuthenticationDTO user = SecurityHelper.getLoggedInUser();

        return Mono.just("Welcome to view!");
    }

    @PostMapping(path = "/fileUpload", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    public void fileUpload(@RequestPart List<MultipartFile> files) {
        dataExtractionService.readData();
    }
}
