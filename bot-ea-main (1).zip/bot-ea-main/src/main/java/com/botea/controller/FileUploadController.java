package com.botea.controller;

import com.botea.controller.dto.ApiResponse;
import com.botea.controller.dto.FileUploadRequest;
import com.botea.controller.dto.UserAuthenticationDTO;
import com.botea.exception.FileUploadException;
import com.botea.helper.SecurityHelper;
import com.botea.service.FileUploadService;
import com.botea.service.S3Service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/v1")
@Slf4j
public class FileUploadController {

    private static final String UPLOAD_DIR = "uploads/";

    private final FileUploadService fileUploadService;
    private final S3Service s3Service;

    @Autowired
    public FileUploadController(FileUploadService fileUploadService, S3Service s3Service) {
        this.fileUploadService = fileUploadService;
        this.s3Service = s3Service;
    }

    @PostMapping(value = "/uploadFiles", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Mono<ResponseEntity<Object>> uploadFile(
            @ModelAttribute FileUploadRequest request,
            @RequestHeader("Authorization") String authToken) {

        UserAuthenticationDTO user = SecurityHelper.getLoggedInUser();

        return fileUploadService.uploadFile(user, request, authToken)
                .map(batchResponse -> ResponseEntity.ok().body((Object)batchResponse))
                .onErrorResume(FileUploadException.class, e -> {
                    log.error("File upload error: {}", e.getMessage());
                    return Mono.just(ResponseEntity
                            .status(e.getStatus())
                            .body(ApiResponse.error(e.getMessage(), "FILE_UPLOAD_ERROR")));
                })
                .onErrorResume(Exception.class, e -> {
                    log.error("Unexpected error during file upload: {}", e.getMessage(), e);
                    return Mono.just(ResponseEntity
                            .status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body(ApiResponse.error("An unexpected error occurred", "INTERNAL_SERVER_ERROR")));
                });
    }

    @GetMapping("/download/{filename}")
    public Mono<ResponseEntity<Flux<DataBuffer>>> downloadFile(@PathVariable String filename) {
        return s3Service.downloadFile(filename)
                //TODO check authorization
                .map(dataBufferFlux -> ResponseEntity.ok()
                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                        .contentType(MediaType.APPLICATION_OCTET_STREAM)
                        .body(dataBufferFlux));
    }
}