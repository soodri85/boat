package com.botea.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UpdateDraftRequest {

    private Long transactionDataId;
    private Integer year;
    private String documentId;
    private String newEditedData;

}
