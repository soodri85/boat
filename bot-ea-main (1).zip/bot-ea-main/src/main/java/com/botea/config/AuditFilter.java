package com.botea.config;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import lombok.RequiredArgsConstructor;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;
import com.botea.service.AuditService;

@Component
@RequiredArgsConstructor
public class AuditFilter implements WebFilter {

    private final AuditService auditService;

    private static final String AUTH_HEADER = "Authorization";
    private static final String BEARER_PREFIX = "Bearer ";
    private static final String SECRET_KEY = "your_jwt_secret_key"; // Replace with your actual secret key

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        ServerHttpResponse response = exchange.getResponse();

        String email = extractEmailFromToken(request);

        String requestData = "Method: " + request.getMethod() + ", URI: " + request.getURI();
        String action = "HTTP_REQUEST";

        return chain.filter(exchange)
                .doOnSuccess(done -> {
                    String responseData = "Status: " + response.getStatusCode();
                    String comments = "Request completed successfully";

                    auditService.logAudit(action, requestData + ", " + responseData, comments, email).subscribe();
                })
                .doOnError(error -> {
                    String responseData = "Error: " + error.getMessage();
                    String comments = "Request failed";

                    auditService.logAudit(action, requestData + ", " + responseData, comments, email).subscribe();
                });
    }

    /**
     * Extracts the email from the JWT token in the Authorization header.
     *
     * @param request The HTTP request containing the JWT token.
     * @return The email if present, otherwise null.
     */
    private String extractEmailFromToken(ServerHttpRequest request) {
        String authHeader = request.getHeaders().getFirst(AUTH_HEADER);
        if (authHeader != null && authHeader.startsWith(BEARER_PREFIX)) {
            String token = authHeader.substring(BEARER_PREFIX.length());
            try {
                Claims claims = Jwts.parserBuilder()
                        .setSigningKey(SECRET_KEY.getBytes()) // Use your actual secret key
                        .build()
                        .parseClaimsJws(token)
                        .getBody();
                return claims.get("email", String.class); // Extract the email claim
            } catch (Exception e) {
                // Log the error or handle invalid token cases
                e.printStackTrace();
            }
        }
        return null; // Return null if no valid email is found
    }
}
