package com.botea.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.server.WebFilter;

@Configuration
public class WebFluxConfig {
    
    @Bean
    public WebFilter contextWebFilter() {
        return (exchange, chain) -> {
            return chain.filter(exchange)
                    .contextWrite(context -> context.put("REQUEST_ID", exchange.getRequest().getId()));
        };
    }
}