package com.botea.config;

import com.botea.dao.repository.UserRepository;
import com.botea.security.CustomAuthenticationWebFilter;
import com.botea.security.CustomReactiveAuthenticationManager;
import com.botea.service.CustomReactiveUserDetailsService;
import com.botea.service.TokenService;
import com.botea.utils.JwtSecretKeyGenerator;
import com.botea.utils.JwtTokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.ReactiveAuthenticationManager;
import org.springframework.security.config.annotation.method.configuration.EnableReactiveMethodSecurity;
import org.springframework.security.config.web.server.SecurityWebFiltersOrder;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.jwt.NimbusReactiveJwtDecoder;
import org.springframework.security.oauth2.jwt.ReactiveJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.security.oauth2.server.resource.authentication.ReactiveJwtAuthenticationConverter;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.security.web.server.authentication.AuthenticationWebFilter;
import org.springframework.security.web.server.context.NoOpServerSecurityContextRepository;
import org.springframework.security.web.server.context.ServerSecurityContextRepository;
import org.springframework.security.web.server.context.WebSessionServerSecurityContextRepository;
import reactor.core.publisher.Flux;

import javax.crypto.SecretKey;

@Configuration
@EnableReactiveMethodSecurity
public class SecurityConfig {

    @Value("${jwt.secret}")
    private String secretKeyStr;

    @Value("${jwt.refresh-secret}")
    private String refreshSecretKeyStr;  // Add a separate refresh secret key

    @Autowired
    private CustomReactiveUserDetailsService customUserDetailsService;

    @Autowired
    private CorsConfig corsConfig;

    @Autowired
    private UserRepository userRepository;

    @Bean
    public ReactiveJwtDecoder jwtDecoder() {
        SecretKey secretKey = JwtSecretKeyGenerator.convertStringToSecretKey(secretKeyStr);
        return NimbusReactiveJwtDecoder.withSecretKey(secretKey).build();
    }

    @Bean
    public ReactiveJwtDecoder refreshTokenDecoder() {
        SecretKey refreshSecretKey = JwtSecretKeyGenerator.convertStringToSecretKey(refreshSecretKeyStr);
        return NimbusReactiveJwtDecoder.withSecretKey(refreshSecretKey).build();  // Use the refresh token's secret key
    }

    @Bean
    public SecurityWebFilterChain securityWebFilterChain(ServerHttpSecurity http) {
        return http
                .httpBasic(ServerHttpSecurity.HttpBasicSpec::disable)
                .formLogin(ServerHttpSecurity.FormLoginSpec::disable)
                .csrf(ServerHttpSecurity.CsrfSpec::disable)
                .logout(ServerHttpSecurity.LogoutSpec::disable)
                .cors(cors -> cors.configurationSource(corsConfig.corsConfigurationSource()))
                .securityContextRepository(NoOpServerSecurityContextRepository.getInstance())  // Disable security context

                .authorizeExchange(exchange -> exchange
                        .pathMatchers("/api/login", "/api/payment/charge", "/api/register", "/api/refresh-token",
                                    "/api/lookup/fetchCountryLookUp", "/api/promo-code/generate", "/api/promo-code/validate",
                                    "/api/licenseManagement/generateLicense", "/api/payment/update","/api/webhook")
                        .permitAll()
                        .anyExchange()
                        .permitAll()  // TODO - Allow all routes for now
                )
                .authenticationManager(customReactiveAuthenticationManager())
                .addFilterBefore(customAuthenticationWebFilter(), SecurityWebFiltersOrder.AUTHENTICATION)
                .build();
    }

    @Bean
    public ReactiveAuthenticationManager customReactiveAuthenticationManager() {
        return new CustomReactiveAuthenticationManager(jwtDecoder(), customUserDetailsService, passwordEncoder(), new JwtTokenUtil(), new TokenService(), new CustomReactiveUserDetailsService(userRepository));
    }

    @Bean
    public AuthenticationWebFilter customAuthenticationWebFilter() {
        AuthenticationWebFilter authenticationWebFilter = new CustomAuthenticationWebFilter(customReactiveAuthenticationManager());
        authenticationWebFilter.setSecurityContextRepository(securityContextRepository());
        return authenticationWebFilter;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12);
    }

    @Bean
    public ServerSecurityContextRepository securityContextRepository() {
        return new WebSessionServerSecurityContextRepository();
    }

    @Bean
    public ReactiveJwtAuthenticationConverter jwtAuthenticationConverter() {
        JwtGrantedAuthoritiesConverter grantedAuthoritiesConverter = new JwtGrantedAuthoritiesConverter();
        grantedAuthoritiesConverter.setAuthorityPrefix("ROLE_");
        grantedAuthoritiesConverter.setAuthoritiesClaimName("roles");

        ReactiveJwtAuthenticationConverter converter = new ReactiveJwtAuthenticationConverter();
        converter.setJwtGrantedAuthoritiesConverter(jwt ->
                Flux.fromIterable(grantedAuthoritiesConverter.convert(jwt))  // Convert to Flux
        );

        return converter;
    }

}
