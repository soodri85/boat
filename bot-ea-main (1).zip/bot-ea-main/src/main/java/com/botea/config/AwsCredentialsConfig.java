//// AwsCredentialsConfig.java
//package com.botea.config;
//
//import com.amazonaws.auth.AWSStaticCredentialsProvider;
//import com.amazonaws.auth.BasicSessionCredentials;
//import com.amazonaws.services.secretsmanager.AWSSecretsManager;
//import com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder;
//import com.amazonaws.services.securitytoken.AWSSecurityTokenService;
//import com.amazonaws.services.securitytoken.AWSSecurityTokenServiceClientBuilder;
//import com.amazonaws.services.securitytoken.model.AssumeRoleRequest;
//import com.amazonaws.services.securitytoken.model.AssumeRoleResult;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Lazy;
//import org.springframework.retry.annotation.Backoff;
//import org.springframework.retry.annotation.Retryable;
//
//@Configuration
//public class AwsCredentialsConfig {
//
//    @Value("${aws.role.arn}")
//    private String roleArn;
//
//    @Value("${aws.region:us-east-1}")
//    private String region;
//
//    @Lazy
//    @Bean
//    public AWSSecurityTokenService awsSecurityTokenService() {
//        return AWSSecurityTokenServiceClientBuilder.standard()
//                .withRegion(region)
//                .build();
//    }
//
//    @Lazy
//    @Bean
//    @Retryable(maxAttempts = 3, backoff = @Backoff(delay = 1000))
//    public BasicSessionCredentials sessionCredentials(AWSSecurityTokenService stsClient) {
//        AssumeRoleRequest roleRequest = new AssumeRoleRequest()
//            .withRoleArn(roleArn)
//            .withRoleSessionName("ServiceSession")
//            .withDurationSeconds(3600); // 1 hour
//
//        AssumeRoleResult roleResponse = stsClient.assumeRole(roleRequest);
//
//        return new BasicSessionCredentials(
//            roleResponse.getCredentials().getAccessKeyId(),
//            roleResponse.getCredentials().getSecretAccessKey(),
//            roleResponse.getCredentials().getSessionToken()
//        );
//    }
//
//    @Lazy
//    @Bean
//    public AWSSecretsManager awsSecretsManager(BasicSessionCredentials sessionCredentials) {
//        return AWSSecretsManagerClientBuilder.standard()
//            .withCredentials(new AWSStaticCredentialsProvider(sessionCredentials))
//            .withRegion(region)
//            .build();
//    }
//}