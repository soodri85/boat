package com.botea.config;


import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Getter
@Configuration
public class PaymentPublicKeyConfig {

    @Value("${stripe.public.key}")
    private String publicKey;

    @Value("${stripe.secret.key}")
    private String secretKey;

    @Value("${stripe.signature.key}")
    private String signature;



}
