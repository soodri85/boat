package com.botea.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.reactive.CorsConfigurationSource;
import org.springframework.web.cors.reactive.UrlBasedCorsConfigurationSource;
import org.springframework.web.reactive.config.CorsRegistry;
import org.springframework.web.reactive.config.WebFluxConfigurer;

@Configuration
public class CorsConfig implements WebFluxConfigurer {

	private final CorsProperties corsProperties;

	public CorsConfig(CorsProperties corsProperties) {
		this.corsProperties = corsProperties;
	}

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**")
				.allowedOrigins(corsProperties.getAllowed().getOrigins().toArray(new String[0]))
				.allowedMethods(corsProperties.getAllowed().getMethods().toArray(new String[0]))
				.allowedHeaders(corsProperties.getAllowed().getHeaders().toArray(new String[0]))
				.allowCredentials(corsProperties.getAllow().getCredentials())
				.maxAge(corsProperties.getMaxAge());
	}

	@Bean
	public CorsConfigurationSource corsConfigurationSource() {
		CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowedOrigins(corsProperties.getAllowed().getOrigins());
		configuration.setAllowedMethods(corsProperties.getAllowed().getMethods());
		configuration.setAllowedHeaders(corsProperties.getAllowed().getHeaders());
		configuration.setAllowCredentials(corsProperties.getAllow().getCredentials());
		configuration.setMaxAge(corsProperties.getMaxAge());

		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", configuration);
		return source;
	}
}
