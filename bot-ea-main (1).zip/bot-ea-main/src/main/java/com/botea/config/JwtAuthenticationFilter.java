package com.botea.config;// JWT Authentication WebFilter

import com.botea.utils.JwtTokenUtil;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

@Component
public class JwtAuthenticationFilter implements WebFilter {
    private final JwtTokenUtil jwtTokenUtil;
    private final ReactiveUserDetailsService userDetailsService;

    public JwtAuthenticationFilter(
        JwtTokenUtil jwtTokenUtil, 
        ReactiveUserDetailsService userDetailsService
    ) {
        this.jwtTokenUtil = jwtTokenUtil;
        this.userDetailsService = userDetailsService;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        String authHeader = request.getHeaders().getFirst(HttpHeaders.AUTHORIZATION);

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            return validateToken(token)
                .flatMap(username -> 
                    userDetailsService.findByUsername(username)
                        .map(userDetails -> {
                            // Create authentication object
                            UsernamePasswordAuthenticationToken authentication =
                                new UsernamePasswordAuthenticationToken(
                                    userDetails, 
                                    null, 
                                    userDetails.getAuthorities()
                                );
                            
                            // Set authentication in security context
                            return ReactiveSecurityContextHolder.withAuthentication(authentication);
                        })
                )
                .then(chain.filter(exchange))
                .onErrorResume(e -> chain.filter(exchange));
        }

        return chain.filter(exchange);
    }

    private Mono<String> validateToken(String token) {
        try {
            // Extract username from token
            String username = jwtTokenUtil.extractUsername(token);
            
            // Additional token validation
            if (jwtTokenUtil.isTokenValid(username, token)) {
                return Mono.just(username);
            }
            return Mono.empty();
        } catch (Exception e) {
            return Mono.empty();
        }
    }
}