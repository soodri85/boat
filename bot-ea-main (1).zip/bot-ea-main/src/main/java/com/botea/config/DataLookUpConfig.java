package com.botea.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.botea.dao.entity.APIConfig;
import com.botea.dao.entity.Document;
import com.botea.helper.DataLookUpHelper;
import com.botea.helper.dto.CountryLookUpDTO;
import com.botea.helper.dto.TaxInfoLookUpDTO;

import reactor.core.publisher.Flux;

/**
 * @author Praveen
 */
@Configuration
public class DataLookUpConfig {

	@Autowired
	private DataLookUpHelper dataLookUpHelper;

	@Bean
	public Flux<CountryLookUpDTO> countryLookUp() {
		return dataLookUpHelper.countryLookUp();
	}

	@Bean
	public Flux<TaxInfoLookUpDTO> taxInfoLookUp() {
		return dataLookUpHelper.fetchTaxInfoLookUp();
	}

	@Bean
	public Flux<Document> documentLookUp() {
		return dataLookUpHelper.fetchDocumentLookUp();
	}

	@Bean
	public Flux<APIConfig> apiConfigLookUp() {
		return dataLookUpHelper.fetchAPIConfigLookUp();
	}
}
