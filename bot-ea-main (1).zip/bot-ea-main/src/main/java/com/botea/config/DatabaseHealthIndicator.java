package com.botea.config;

import io.r2dbc.spi.ConnectionFactory;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
//TODO
@Component
public class DatabaseHealthIndicator implements HealthIndicator {
    private final ConnectionFactory connectionFactory;

    public DatabaseHealthIndicator(ConnectionFactory connectionFactory) {
        this.connectionFactory = connectionFactory;
    }

    @Override
    public Health health() {
        try {
            // Attempt to create and close a connection
            Mono.from(connectionFactory.create())
                .flatMap(connection -> Mono.fromCallable(() -> {
                    connection.close();
                    return true;
                }))
                .block(); // Blocking here for health check

            return Health.up().build();
        } catch (Exception e) {
            return Health.down()
                .withDetail("Error", "Cannot connect to the database")
                .withDetail("Exception", e.getMessage())
                .build();
        }
    }
}