package com.botea.config;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

public class CustomAuthenticationToken implements Authentication {
    private final Object principal;
    private final String credentials;
    private final Collection<? extends GrantedAuthority> authorities;
    private boolean authenticated = true;

    public CustomAuthenticationToken(Object principal, String credentials, Collection<? extends GrantedAuthority> authorities) {
        this.principal = principal; // Custom object here
        this.credentials = credentials; // Token
        this.authorities = authorities; // User authorities
    }

    @Override
    public String getName() {
        return principal != null ? principal.toString() : null;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public Object getCredentials() {
        return credentials; // JWT token
    }

    @Override
    public Object getDetails() {
        return null; // Add custom details if needed
    }

    @Override
    public Object getPrincipal() {
        return principal; // Return your custom object
    }

    @Override
    public boolean isAuthenticated() {
        return authenticated;
    }

    @Override
    public void setAuthenticated(boolean authenticated) throws IllegalArgumentException {
        this.authenticated = authenticated;
    }
}
