package com.botea.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@ConfigurationProperties(prefix = "cors")
public class CorsProperties {

    private Allowed allowed = new Allowed();
    private Allow allow = new Allow();
    private Long maxAge = 3600l;

    public Allowed getAllowed() {
        return allowed;
    }

    public void setAllowed(Allowed allowed) {
        this.allowed = allowed;
    }

    public Allow getAllow() {
        return allow;
    }

    public void setAllow(Allow allow) {
        this.allow = allow;
    }

    public Long getMaxAge() {
        return maxAge;
    }

    public void setMaxAge(Long maxAge) {
        this.maxAge = maxAge;
    }

    public static class Allowed {
        private List<String> origins;
        private List<String> methods;
        private List<String> headers;

        public List<String> getOrigins() {
            return origins;
        }

        public void setOrigins(List<String> origins) {
            this.origins = origins;
        }

        public List<String> getMethods() {
            return methods;
        }

        public void setMethods(List<String> methods) {
            this.methods = methods;
        }

        public List<String> getHeaders() {
            return headers;
        }

        public void setHeaders(List<String> headers) {
            this.headers = headers;
        }
    }

    public static class Allow {
        private Boolean credentials;

        public Boolean getCredentials() {
            return credentials;
        }

        public void setCredentials(Boolean credentials) {
            this.credentials = credentials;
        }
    }
}
