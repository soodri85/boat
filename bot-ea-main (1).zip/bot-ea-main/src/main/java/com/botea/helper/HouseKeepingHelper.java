package com.botea.helper;

import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 * @author Praveen
 */

public class HouseKeepingHelper {

	public static Long getCreatedBy() {
		Long userId = SecurityHelper.getLoggedInUser() != null ? SecurityHelper.getLoggedInUser().botUserId() : null;
		return userId != null ? userId : 1L;
	}

	public static Long getUpdatedBy() {
		return getCreatedBy();
	}

	public static Timestamp getCreatedOn() {
		return new Timestamp(System.currentTimeMillis());
	}

	public static Timestamp getUpdatedOn() {
		return getCreatedOn();
	}

	public static LocalDateTime getCurrentLocalDateTime(){
		return LocalDateTime.now();
	}
}
