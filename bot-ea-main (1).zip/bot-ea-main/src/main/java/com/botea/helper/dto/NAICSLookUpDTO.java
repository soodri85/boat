package com.botea.helper.dto;

import lombok.Data;

@Data
public class NAICSLookUpDTO {
	private String naicsCode;
	private String naicsDescription;
	private String countryCode;
}
