package com.botea.helper.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class TaxInfoLookUpDTO {
	private String provinceCode;
	private String provinceName;
	private BigDecimal gstPercentage;
	private String countryName;
}
