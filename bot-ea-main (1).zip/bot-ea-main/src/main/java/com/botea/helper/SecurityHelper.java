package com.botea.helper;

import com.botea.controller.dto.UserAuthenticationDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

public class SecurityHelper {

    public static UserAgentDTO getUserDeviceInfo(ServerHttpRequest request) {
        String userAgent = request.getHeaders().getFirst("User-Agent");

        // Check for X-Forwarded-For header (for proxies/load balancers)
        String ipAddress = request.getHeaders().getFirst("X-Forwarded-For");

        if (ipAddress == null || ipAddress.isEmpty()) {
            // Fallback to remote address
            ipAddress = request.getRemoteAddress() != null
                    ? request.getRemoteAddress().getAddress().getHostAddress()
                    : "Unknown";
        } else {
            // If X-Forwarded-For contains multiple IPs, use the first one
            ipAddress = ipAddress.split(",")[0];
        }

        return new UserAgentDTO(userAgent, ipAddress);
    }

    @Getter
    @AllArgsConstructor
    public static class UserAgentDTO {
        private String userAgent;
        private String ipAddress;
    }

    public static UserAuthenticationDTO getLoggedInUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            return (UserAuthenticationDTO) authentication.getPrincipal();
        }

        return new UserAuthenticationDTO("null", "null", null);
    }
}
