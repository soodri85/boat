package com.botea.helper.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class CountryLookUpDTO {
	private String countryName;
	private String countryCode;
	private String currencyCode;
	private BigDecimal licenseCreditDocument;
	private BigDecimal licenseCreditScan;
	private Long defaultScansIncluded;
	private  Long countryProfileId;
}
