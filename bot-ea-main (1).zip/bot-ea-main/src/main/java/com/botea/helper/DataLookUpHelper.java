package com.botea.helper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.botea.dao.entity.APIConfig;
import com.botea.dao.entity.Document;
import com.botea.dao.repository.APIConfigRepository;
import com.botea.dao.repository.CountryProfileRepository;
import com.botea.dao.repository.DocumentRepository;
import com.botea.dao.repository.NAICSRepository;
import com.botea.dao.repository.TaxInfoRepository;
import com.botea.exception.BotApplicationException;
import com.botea.helper.dto.CountryLookUpDTO;
import com.botea.helper.dto.NAICSLookUpDTO;
import com.botea.helper.dto.TaxInfoLookUpDTO;

import reactor.core.publisher.Flux;

/**
 * @author Praveen
 * 
 *         This class fetches and loads the look up data during start up
 */

@Component
public class DataLookUpHelper {

	@Autowired
	private CountryProfileRepository countryProfileRepository;

	@Autowired
	private NAICSRepository naicsRepository;

	@Autowired
	private TaxInfoRepository taxInfoRepository;

	@Autowired
	private DocumentRepository documentRepository;

	@Autowired
	private APIConfigRepository apiConfigRepository;

	/**
	 * Country LookUp
	 * 
	 * @return
	 */
	public Flux<CountryLookUpDTO> countryLookUp() {
		try {
			return countryProfileRepository.fetchCountryLookUp().switchIfEmpty(Flux.empty());
		} catch (Exception e) {
			throw new BotApplicationException(e.getMessage());
		}
	}

	/**
	 * NAICS details LookUp
	 * 
	 * @return
	 */
	public Flux<NAICSLookUpDTO> fetchNAICSLookUp(String countryCode) {
		try {
			return naicsRepository.fetchNAICSLookUp(countryCode).switchIfEmpty(Flux.empty());
		} catch (Exception e) {
			throw new BotApplicationException(e.getMessage());
		}
	}

	/**
	 * Tax information and gst LookUp
	 * 
	 * @return
	 */
	public Flux<TaxInfoLookUpDTO> fetchTaxInfoLookUp() {
		try {
			return taxInfoRepository.fetchTaxInfoLookUp().switchIfEmpty(Flux.empty());
		} catch (Exception e) {
			throw new BotApplicationException(e.getMessage());
		}
	}

	/**
	 * Country wise documents LookUp
	 * 
	 * @return
	 */
	public Flux<Document> fetchDocumentLookUp() {
		try {
			return documentRepository.findAll().switchIfEmpty(Flux.empty());
		} catch (Exception e) {
			throw new BotApplicationException(e.getMessage());
		}
	}

	/**
	 * API configurations LookUp
	 * 
	 * @return
	 */
	public Flux<APIConfig> fetchAPIConfigLookUp() {
		try {
			return apiConfigRepository.findAllAPIConfigLookUp().switchIfEmpty(Flux.empty());
		} catch (Exception e) {
			throw new BotApplicationException(e.getMessage());
		}
	}
}
