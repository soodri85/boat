package com.botea.helper;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Data
@Configuration
@ConfigurationProperties(prefix = "file-upload")
public class FileUploadConfigProperties {
    private List<String> allowedTypes;
    private String uploadUrl;
    private String batchResultsUrl;
    private int maxRetries;
    private int retryDelaySeconds;
    private int batchCheckRetries;
    private int batchCheckDelaySeconds;
    private int timeoutMinutes;
    private String apiToken;
}