package com.botea.security;

import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.concurrent.ConcurrentHashMap;

@Service
public class TokenBlacklistService {
    private final ConcurrentHashMap<String, Long> blacklist = new ConcurrentHashMap<>();

    public Mono<Void> blacklistToken(String token, long expiry) {
        blacklist.put(token, System.currentTimeMillis() + expiry * 1000);
        return Mono.empty();
    }

    public Mono<Boolean> isTokenBlacklisted(String token) {
        Long expiryTime = blacklist.get(token);
        if (expiryTime == null) {
            return Mono.just(false);
        }
        if (System.currentTimeMillis() > expiryTime) {
            blacklist.remove(token);
            return Mono.just(false);
        }
        return Mono.just(true);
    }
}
