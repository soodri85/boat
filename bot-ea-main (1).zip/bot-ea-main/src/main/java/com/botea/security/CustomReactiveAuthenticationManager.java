package com.botea.security;

import com.botea.config.CustomAuthenticationToken;
import com.botea.controller.dto.UserAuthenticationDTO;
import com.botea.service.CustomReactiveUserDetailsService;
import com.botea.service.TokenService;
import com.botea.utils.JwtTokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.ReactiveAuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.jwt.ReactiveJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.BearerTokenAuthenticationToken;
import org.springframework.security.oauth2.server.resource.authentication.JwtReactiveAuthenticationManager;
import reactor.core.publisher.Mono;

/**
 * @author Praveen
 */
@Slf4j
public class CustomReactiveAuthenticationManager implements ReactiveAuthenticationManager {

    private ReactiveUserDetailsService userDetailsService;
    private PasswordEncoder passwordEncoder;
    private JwtReactiveAuthenticationManager jwtReactiveAuthenticationManager;
    private JwtTokenUtil jwtTokenUtil;
    private TokenService tokenService;
    private CustomReactiveUserDetailsService customReactiveUserDetailsService;

    // Constructor for JWT Authentication
    public CustomReactiveAuthenticationManager(ReactiveJwtDecoder jwtDecoder,
                                               ReactiveUserDetailsService userDetailsService,
                                               PasswordEncoder passwordEncoder, JwtTokenUtil jwtTokenUtil, TokenService tokenService, CustomReactiveUserDetailsService customReactiveUserDetailsService) {
        this.userDetailsService = userDetailsService;
        this.passwordEncoder = passwordEncoder;
        this.jwtReactiveAuthenticationManager = new JwtReactiveAuthenticationManager(jwtDecoder);
        this.jwtReactiveAuthenticationManager.setJwtAuthenticationConverter(new ReactiveJwtAuthenticationConverter());
        this.jwtTokenUtil = jwtTokenUtil;
        this.tokenService = tokenService;
        this.customReactiveUserDetailsService = customReactiveUserDetailsService;
    }

    @Override
    public Mono<Authentication> authenticate(Authentication authentication) throws AuthenticationException {

        log.info("Authenticating user: {}", authentication.getName());

        // Handle Username/Password Authentication
        if (authentication instanceof UsernamePasswordAuthenticationToken) {
            log.info("Handling Username/Password Authentication");
            return handleUsernamePasswordAuthentication(authentication);
        }

        // Handle Bearer Token Authentication
        if (authentication instanceof BearerTokenAuthenticationToken) {
            log.info("Handling Bearer Token Authentication");
            return handleBearerTokenAuthentication(authentication);
        }

        log.error("Unsupported authentication type: {}", authentication.getClass().getName());
        // Default case
        return Mono.error(new BadCredentialsException("Unsupported authentication type"));

    }

    private Mono<Authentication> handleUsernamePasswordAuthentication(Authentication authentication) {
        String username = authentication.getName();
        String password = (String) authentication.getCredentials();

        // Find user by username
        return userDetailsService.findByUsername(username)
                .switchIfEmpty(Mono.error(new BadCredentialsException("User not found"))) // Handle user not found
                .filter(userDetails -> passwordEncoder.matches(password, userDetails.getPassword())) // Check password
                .map(userDetails -> (Authentication) new UsernamePasswordAuthenticationToken(userDetails.getUsername(),
                        userDetails.getPassword(), userDetails.getAuthorities())) // Cast to Authentication
                .switchIfEmpty(Mono.error(new BadCredentialsException("Invalid credentials"))); // Handle invalid credentials
    }

    private Mono<Authentication> handleBearerTokenAuthentication(Authentication authentication) {
        String token = ((BearerTokenAuthenticationToken) authentication).getToken();

        if (token != null) {
            return customReactiveUserDetailsService.findUserByToken(token)
                    .switchIfEmpty(Mono.error(new BadCredentialsException("User not found")))
                    .map(userFromDB -> new CustomAuthenticationToken(
                            new UserAuthenticationDTO(userFromDB.getUsername(), userFromDB.getRole(), userFromDB.getBotUserId()),  // Custom object as principal
                            token,       // Token as credentials
                            null         // Authorities (can be null or populated)
                    ));
        }

        return Mono.error(new BadCredentialsException("Invalid token"));
    }

}
