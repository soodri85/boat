//package com.botea.security;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.server.reactive.ServerHttpResponse;
//import org.springframework.security.authentication.ReactiveAuthenticationManager;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.context.ReactiveSecurityContextHolder;
//import org.springframework.security.core.context.SecurityContextImpl;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Component;
//import org.springframework.web.server.ServerWebExchange;
//
//import com.botea.utils.JwtUtilOld;
//
//import reactor.core.publisher.Mono;
//
///**
// * @author Praveen
// */
//@Component
//public class AuthenticationHandler {
//
//	@Autowired
//	private ReactiveAuthenticationManager customReactiveAuthenticationManager;
//
//	@Autowired
//	private JwtUtilOld jwtUtilOld;
//
//	@Autowired
//	@Qualifier("passwordEncoder")
//	private PasswordEncoder passwordEncode;
//
//	public Mono<String> authenticateUser(AuthRequest authRequest, ServerWebExchange exchange) {
//		try {
//			return customReactiveAuthenticationManager.authenticate(
//					new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()))
//					.map(authentication -> {
//						// UserDetails userDetails = (UserDetails) authentication.getPrincipal();
//						CustomUserDetails customUserDetails = new CustomUserDetails();
//						customUserDetails.setUsername((String) authentication.getPrincipal());
//						String jwt = null;
//						try {
//							jwt = jwtUtilOld.generateToken(customUserDetails);
//						} catch (Exception e) {
//							e.printStackTrace();
//						}
//
//						ServerHttpResponse response = exchange.getResponse();
//						response.getHeaders().add(HttpHeaders.AUTHORIZATION, "Bearer " + jwt);
//						response.setStatusCode(HttpStatus.OK);
//						SecurityContextImpl securityContext = new SecurityContextImpl(authentication);
//						ReactiveSecurityContextHolder.withSecurityContext(Mono.just(securityContext));
//						return jwt;
//					});
//		} catch (Exception e) {
//			// TODO Log exception message
//			e.printStackTrace();
//		}
//		return null;
//	}
//}
