package com.botea.security;

import com.botea.service.TokenService;
import com.botea.utils.JwtTokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.ReactiveAuthenticationManager;
import org.springframework.security.authentication.ReactiveAuthenticationManagerResolver;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
import org.springframework.security.oauth2.server.resource.authentication.BearerTokenAuthenticationToken;
import org.springframework.security.web.server.authentication.AuthenticationWebFilter;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

/**
 * @author Praveen
 */
@Slf4j
public class CustomAuthenticationWebFilter extends AuthenticationWebFilter {

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private ReactiveAuthenticationManager customReactiveAuthenticationManager;

    @Autowired
    private ReactiveUserDetailsService reactiveUserDetailsService;

    @Autowired
    private TokenService tokenService;

    public CustomAuthenticationWebFilter(ReactiveAuthenticationManager authenticationManager) {
        super(authenticationManager);
    }

    public CustomAuthenticationWebFilter(
            ReactiveAuthenticationManagerResolver<ServerWebExchange> authenticationManagerResolver) {
        super(authenticationManagerResolver);
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        String path = exchange.getRequest().getURI().getPath();

        log.info("Bot authentication filter for Path: {}", path);
        // Open paths - TODO - read from config file
        if (path.equals("/api/purchaseLicense") ||
            path.equals("/api/register") ||
            path.equals("/api/forgot-password") ||
            path.equals("/api/update-password") ||
            path.equals("/api/lookup/fetchCountryLookUp") ||
            path.equals("/api/otp/verify") ||
            path.equals("/api/send-email-otp") ||
            path.equals("/api/verify-email-otp") ||
            path.equals("/api/promoCode/validate") ||
            path.equals("/api/promoCode/use") ||
            path.equals("/api/licenseManagement/generateLicense") ||
            path.equals("/api/payment/public-key") ||
            path.equals("/api/payment/charge") ||
            path.equals("/api/payment/update") ||
            path.equals("/api/webhook")) {
            log.info("Open path: {}", path);
            return chain.filter(exchange);
        } else if (path.startsWith("/api/login")) {
            // Login path processing
            log.info("Login path: {}", path);
            return chain.filter(exchange);
        } else if (path.equals("/api/refresh-token")) {
            // Refresh token logic
            log.info("Refresh token path: {}", path);
            return handleRefreshToken(exchange, chain);
        } else if (path.equals("/api/logout")) {
            return handleLogout(exchange, chain);
        } else { // JWT Token authentication for other paths
            log.info("JWT Token authentication for path: {}", path);
            return handleJwtAuthentication(exchange, chain);
        }
    }

    private Mono<Void> handleLogout(ServerWebExchange exchange, WebFilterChain chain) {
        // Check if this request has already been processed
        if (exchange.getAttribute("logoutProcessed") != null) {
            return chain.filter(exchange);
        }

        return extractToken(exchange)
                .flatMap(authToken -> {
                    // If token is valid, invalidate it and continue
                    if (jwtTokenUtil.isTokenValid(authToken)) {
                        // Invalidate the token
                        jwtTokenUtil.invalidateToken(authToken);

                        // Mark the request as processed
                        exchange.getAttributes().put("logoutProcessed", true);

                        // Continue to the next filter or controller
                        return chain.filter(exchange);
                    }

                    // If token is not valid, return unauthorized
                    return setUnauthorizedResponse(exchange);
                })
                .switchIfEmpty(Mono.fromRunnable(() -> {
                    // If no token could be extracted, set unauthorized
                    exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                }))
                .onErrorResume(e -> {
                    // Log the error and set unauthorized response
                    return setUnauthorizedResponse(exchange);
                });
    }

    /**
     * Sets the response as Unauthorized.
     */
    private Mono<Void> setUnauthorizedResponse(ServerWebExchange exchange) {
        exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
        return exchange.getResponse().setComplete();
    }

    /**
     * Extracts the Bearer token from the request.
     */
    private Mono<String> extractToken(ServerWebExchange exchange) {
        String authHeader = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return Mono.just(authHeader.substring(7));
        }
        return Mono.empty();
    }

    // Handle refresh token request
    private Mono<Void> handleRefreshToken(ServerWebExchange exchange, WebFilterChain chain) {
        try {
            String refreshToken = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);

            if (refreshToken != null && refreshToken.startsWith("Bearer ")) {
                refreshToken = refreshToken.substring(7); // Remove "Bearer " prefix

                // Validate refresh token and extract the username
                String username = jwtTokenUtil.extractUsernameFromRefreshToken(refreshToken);
                if (username != null && jwtTokenUtil.isRefreshTokenValid(refreshToken)) {
                    // Fetch UserDetails asynchronously based on the username from the ReactiveUserDetailsService
                    return reactiveUserDetailsService.findByUsername(username)
                            .flatMap(userDetails -> {
                                return chain.filter(exchange);
                            }).switchIfEmpty(Mono.defer(() -> {
                                // If user details are not found, return Unauthorized
                                exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                                return exchange.getResponse().setComplete();
                            }));
                }
            }

            // If refresh token is invalid, return Unauthorized
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        } catch (Exception e) {
            // Handle exception and return Unauthorized
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }
    }

    // Handle JWT token authentication for other endpoints
    private Mono<Void> handleJwtAuthentication(ServerWebExchange exchange, WebFilterChain chain) {
        try {
            String authHeader = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);

            if (authHeader != null && authHeader.startsWith("Bearer ")) {
                String authToken = authHeader.substring(7);
                String username = jwtTokenUtil.extractUsername(authToken);

                if (username != null && jwtTokenUtil.isTokenValid(username, authToken)) {
                    // Check if the token is valid in the database
                    return tokenService.isTokenValidInDatabase(authToken)
                            .flatMap(isValid -> {
                                if (isValid) {
                                    // If the token is valid, fetch UserDetails based on the username
                                    return reactiveUserDetailsService.findByUsername(username)
                                            .flatMap(userDetails -> {
                                                BearerTokenAuthenticationToken auth = new BearerTokenAuthenticationToken(authToken);

                                                return customReactiveAuthenticationManager.authenticate(auth)
                                                        .flatMap(authentication -> {
                                                            // Manually create an Authentication object for the SecurityContext
                                                            SecurityContextHolder.getContext().setAuthentication(authentication);
                                                            return chain.filter(exchange); // Continue filter chain
                                                        }).onErrorResume(e -> {
                                                            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                                                            return exchange.getResponse().setComplete(); // Short-circuit on failure
                                                        });
                                            }).switchIfEmpty(Mono.defer(() -> {
                                                exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                                                return exchange.getResponse().setComplete();
                                            }));
                                } else {
                                    // If the token is not valid in the database, return Unauthorized
                                    exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                                    return exchange.getResponse().setComplete();
                                }
                            });
                } else {
                    // Handle exception and return Unauthorized
                    exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                    return exchange.getResponse().setComplete();
                }
            }
            // Handle exception and return Unauthorized
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        } catch (Exception e) {
            // Log error if needed
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }
    }
}
