package com.botea.utils;

import lombok.Getter;

@Getter
public enum PaymentStatus {
    PENDING,
    COMPLETED
}
