package com.botea.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

@Component
public class JwtTokenUtil {

    private final Key SECRET_KEY = Keys.secretKeyFor(SignatureAlgorithm.HS256);  // Use the secret key directly
    private static final long ACCESS_TOKEN_EXPIRATION_TIME = 86400000; // 24 hours
    private static final long REFRESH_TOKEN_EXPIRATION_TIME = 604800000; // 7 days
    private final ConcurrentHashMap<String, Boolean> tokenBlacklist = new ConcurrentHashMap<>(); //TODO move to database

    // Generate Access Token
    public String generateToken(String username) {
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + ACCESS_TOKEN_EXPIRATION_TIME))
                .signWith(SECRET_KEY)  // Directly use the SECRET_KEY without re-creating it
                .compact();
    }

    // Generate Refresh Token
    public String generateRefreshToken(String username) {
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + REFRESH_TOKEN_EXPIRATION_TIME))
                .signWith(SECRET_KEY)  // Directly use the SECRET_KEY without re-creating it
                .compact();
    }

    // Check if a token is blacklisted
    public boolean isTokenValid(String token) {
        return !tokenBlacklist.getOrDefault(token, false) && validateTokenStructure(token);
    }

    // Invalidate token by adding it to the blacklist
    public void invalidateToken(String token) {
        tokenBlacklist.put(token, true);
    }

    public String extractUsernameFromRefreshToken(String refreshToken) {
        try {
            return Jwts.parser()
                    .setSigningKey(SECRET_KEY)
                    .parseClaimsJws(refreshToken)
                    .getBody()
                    .getSubject();
        } catch (Exception e) {
            return null;
        }
    }

    // Extract Username from Token
    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    // Extract Claim from Token
    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    // Extract All Claims from Token
    private Claims extractAllClaims(String token) {
        // Use the SECRET_KEY directly without converting it
        return Jwts.parserBuilder()  // Use the new parserBuilder()
                .setSigningKey(SECRET_KEY)  // Set the signing key directly
                .build()
                .parseClaimsJws(token)  // Parse the JWT
                .getBody();
    }

    // Check if the Token is Valid
    public boolean isTokenValid(String username, String token) {
        final String extractedUsername = extractUsername(token);

        Boolean expiry = tokenBlacklist.get(token);
        if (expiry != null) {
            return false;
        }

        return (extractedUsername.equals(username) && !isTokenExpired(token));
    }

    // Check if the Token is Expired
    private boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    // Extract Expiration Date from Token
    private Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    public boolean isRefreshTokenValid(String refreshToken) {
        try {
            // Parse the token and check if it's expired
            Claims claims = Jwts.parserBuilder()
                    .setSigningKey(SECRET_KEY)
                    .build()
                    .parseClaimsJws(refreshToken)
                    .getBody();

//TODO
            //Refresh token will be issued ONLY of the access token is active - Discussed with Praveen and Pradeep
            // Check if the token is expired
//            if (claims.getExpiration().before(new Date())) {
//                return false;
//            }

            return true;
        } catch (Exception e) {
            // If parsing fails due to expiration, incorrect signature, or any other reason,
            // the token is considered invalid
            return false;
        }
    }

    /**
     * Validates the structure of the provided JWT token.
     *
     * @param token the JWT token to validate
     * @return true if the token structure is valid, false otherwise
     */
    public boolean validateTokenStructure(String token) {
        try {
            // Parse the token to verify its structure
            Jwts.parserBuilder()
                    .setSigningKey(SECRET_KEY) // Replace with your secret key or key resolver
                    .build()
                    .parseClaimsJws(token);
            return true;
        } catch (io.jsonwebtoken.SignatureException e) {
            // Invalid signature
            System.out.println("Invalid JWT signature: " + e.getMessage());
        } catch (io.jsonwebtoken.MalformedJwtException e) {
            // Invalid token format
            System.out.println("Invalid JWT token: " + e.getMessage());
        } catch (io.jsonwebtoken.ExpiredJwtException e) {
            // Token is expired
            System.out.println("Expired JWT token: " + e.getMessage());
        } catch (io.jsonwebtoken.UnsupportedJwtException e) {
            // Unsupported JWT
            System.out.println("Unsupported JWT token: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            // Empty or null token
            System.out.println("JWT claims string is empty: " + e.getMessage());
        }

        return false;
    }

}
