package com.botea.utils;

import org.apache.commons.codec.binary.Base32;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.security.SecureRandom;

/**
 * @author Praveen
 */
@Component
public class LicenseKeyGenerator {

	private static final Logger LOGGER = LogManager.getLogger(LicenseKeyGenerator.class);

	private static final int LICENSE_KEY_LENGTH = 20;

	public static String generateLicenseKey() {
		SecureRandom secureRandom = new SecureRandom();
		byte[] randomBytes = new byte[15];
		secureRandom.nextBytes(randomBytes);

		Base32 base32 = new Base32();
		String encoded = base32.encodeToString(randomBytes);

		// Make sure the encoded string is the desired length
		return encoded.substring(0, LICENSE_KEY_LENGTH).toUpperCase();
	}

	public static void main(String[] args) {
		String licenseKey = generateLicenseKey();
		LOGGER.info("Generated License Key: {}", licenseKey.substring(15) + "***************");
	}
}
