package com.botea.utils;

public final class FileUploadConstants {
    private FileUploadConstants() {
        // Private constructor to prevent instantiation
    }

    public static final String DEFAULT_EXTRACTION_ID = "-OEy2l6kvkTfj5rjiLVa";
    public static final String FILE_UPLOAD_INITIATED = "File upload initiated";
    public static final String BATCH_PROCESSING_COMPLETED = "Batch processing completed";
    public static final String BEARER_PREFIX = "Bearer ";
    
    public static final class ErrorMessages {
        public static final String EXTRACTION_ID_REQUIRED = "ExtractionId is required";
        public static final String FILE_REQUIRED = "File is required";
        public static final String AUTH_TOKEN_REQUIRED = "Authorization token is required";
        public static final String INVALID_FILE_TYPE = "Invalid file type. Allowed types: %s";
        public static final String TRANSACTION_NOT_FOUND = "TransactionData not found for batchId: %s";
        public static final String INVALID_JSON = "Invalid JSON received from batch API";
    }

    public static final class ContentTypes {
        public static final String PDF = "application/pdf";
        public static final String DOC = "application/msword";
        public static final String DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        public static final String OCTET_STREAM = "application/octet-stream";
    }
}