package com.botea.utils;

import com.botea.exception.FileUploadException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Slf4j
public class FileUploadUtil {
    
    private FileUploadUtil() {
        // Private constructor to prevent instantiation
    }
    
    public static void validateFileType(MultipartFile file, List<String> allowedTypes) {
        String contentType = file.getContentType();
        if (contentType == null || !allowedTypes.contains(contentType.toLowerCase())) {
            throw new FileUploadException(
                "Invalid file type. Allowed types: " + String.join(", ", allowedTypes),
                HttpStatus.BAD_REQUEST
            );
        }
    }
    
    public static void validateFileSize(MultipartFile file, long maxSizeInBytes) {
        if (file.getSize() > maxSizeInBytes) {
            throw new FileUploadException(
                "File size exceeds maximum limit of " + (maxSizeInBytes / (1024 * 1024)) + "MB",
                HttpStatus.BAD_REQUEST
            );
        }
    }
}