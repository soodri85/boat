package com.botea.utils;

import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

/**
 * @author Praveen
 */
public class JwtSecretKeyGenerator {
    public static String generateSecretKey() throws NoSuchAlgorithmException {
        KeyGenerator keyGenerator = KeyGenerator.getInstance("HmacSHA256");
        keyGenerator.init(256); // Specify the key size
        SecretKey secretKey = keyGenerator.generateKey();
        return Base64.getEncoder().encodeToString(secretKey.getEncoded());
    }

    public static SecretKey convertStringToSecretKey(String secretKeyString) {
        // Decode the secret key string from Base64
        byte[] decodedKey = Base64.getDecoder().decode(secretKeyString);
        // Create a SecretKeySpec object using the decoded key bytes and the algorithm (HmacSHA256)
        return new SecretKeySpec(decodedKey, 0, decodedKey.length, "HmacSHA256");
    }
    
    public static void main(String[] args) throws NoSuchAlgorithmException {
        String secretKey = generateSecretKey();
        System.out.println("Generated Secret Key: " + secretKey);
    }
}
