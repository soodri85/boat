package com.botea.utils;

import lombok.Getter;

@Getter
public enum EmailType {
    FORGOT_PASSWORD("forgot-password", "FPW", "Forgot password"),
    RESET_PASSWORD("reset-password", "RPW", "Reset password"),
    TWO_FACTOR("two-factor", "TFA", "Two-factor"),
    REGISTRATION("registration", "USR", "User Registration"),
    LICENSE_GENERATED("license-generated", "LGN", "License generated"),
    LICENSE_RENEWED("license-renewed", "LRN", "License renewed"),
    PROMO_CODE("promo_code", "PCG", "Promo Code"),
    PROMO_CODE_BULK("promo_code_bulk", "PCB", "Bulk Promo Codes"),
    PAYMENT_FAILED("payment_failed", "PFA", "Payment Failed"),
    PAYMENT_PROCESSING("payment_processing", "PPR", "Payment Processing");

    private final String templateName;
    private final String otpType;
    private final String displayName;

    EmailType(String templateName, String otpType, String displayName) {
        this.templateName = templateName;
        this.otpType = otpType;
        this.displayName = displayName;
    }

    public String getTemplateName() {
        return templateName;
    }

    public String getOtpType() {
        return otpType;
    }

    public String getDisplayName() {
        return displayName;
    }
}