//package com.botea;
//
//import io.r2dbc.spi.ConnectionFactory;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.boot.context.event.ApplicationFailedEvent;
//import org.springframework.boot.context.event.ApplicationStartingEvent;
//import org.springframework.context.ApplicationListener;
//import org.springframework.context.annotation.Bean;
//import reactor.core.publisher.Mono;
//
//@SpringBootApplication
//public class BotEAApplication {
//	private static final Logger logger = LoggerFactory.getLogger(BotEAApplication.class);
//
//	public static void main(String[] args) {
//		SpringApplication application = new SpringApplication(BotEAApplication.class);
//
//		// Add listeners for different startup stages
//		application.addListeners((ApplicationListener<ApplicationStartingEvent>) event -> {
//			logger.info("Application is starting...");
//		});
//
//		application.addListeners((ApplicationListener<ApplicationFailedEvent>) event -> {
//			Throwable exception = event.getException();
//			logger.error("Application startup failed", exception);
//
//			if (isDataSourceConnectionFailure(exception)) {
//				logger.error("Database connection failed. Stopping the application.");
//				System.exit(1);
//			}
//		});
//
//		try {
//			application.run(args);
//		} catch (Exception e) {
//			logger.error("Unhandled exception during application startup", e);
//			System.exit(1);
//		}
//	}
//
//	// Custom method to check if the exception is related to database connection
//	private static boolean isDataSourceConnectionFailure(Throwable exception) {
//		if (exception == null) return false;
//
//		String errorMessage = exception.getMessage() != null ?
//				exception.getMessage().toLowerCase() : "";
//
//		return errorMessage.contains("connection failed") ||
//				errorMessage.contains("unable to establish connection") ||
//				errorMessage.contains("connection refused") ||
//				(exception.getCause() != null &&
//						(exception.getCause().getMessage() != null &&
//								exception.getCause().getMessage().toLowerCase().contains("connection")));
//	}
//
//	@Bean
//	public Mono<Void> databaseConnectionValidator(ConnectionFactory connectionFactory) {
//		return Mono.from(connectionFactory.create())
//				.flatMap(connection -> {
//					logger.info("Successfully established database connection");
//					return Mono.fromCallable(() -> {
//						connection.close();
//						return Mono.empty();
//					});
//				})
//				.then() // Convert to Mono<Void>
//				.onErrorResume(ex -> {
//					logger.error("Failed to establish database connection", ex);
//					throw new RuntimeException("Database connection validation failed", ex);
//				});
//	}
//}

package com.botea;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationFailedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;

@SpringBootApplication
@EnableR2dbcRepositories(basePackages = "com.botea.dao.repository")
public class BotEAApplication {
	private static final Logger logger = LoggerFactory.getLogger(BotEAApplication.class);

	public static void main(String[] args) {
		SpringApplication application = new SpringApplication(BotEAApplication.class);

		// Add listener for startup failures
		application.addListeners((ApplicationListener<ApplicationFailedEvent>) event -> {
			Throwable exception = event.getException();
			if (exception != null) {
				logger.error("Application startup failed", exception);
				System.exit(1);
			}
		});

		application.run(args);
	}
}