package com.botea.service;

import com.botea.dao.entity.BusinessAddress;
import com.botea.dao.repository.BusinessAddressRepository;
import com.botea.helper.HouseKeepingHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class BusinessAddressService {

    private final BusinessAddressRepository repository;
    private final UserProfileService userProfileService;

    public BusinessAddressService(BusinessAddressRepository repository, UserProfileService userProfileService) {
        this.repository = repository;
        this.userProfileService = userProfileService;
    }

    public Mono<BusinessAddress> saveBusinessAddress(BusinessAddress businessAddress) {
        return repository.save(businessAddress);
    }

    public Flux<BusinessAddress> getAllBusinessAddresses(Long botUserId, Long user_profile_id) {
        return userProfileService.getUserProfilesByBotUserId(botUserId)
                .flatMap(userProfile -> repository.findByUserProfileId(user_profile_id))
                .distinct() // Ensure unique results
                .onErrorResume(e -> {
                    log.error("Error fetching BusinessAddresses: ", e);
                    return Flux.empty();
                });
    }

    public Mono<BusinessAddress> getBusinessAddressById(Long id) {
        return repository.findById(id);
    }

    public Mono<Void> deleteBusinessAddress(Long id) {
        return repository.deleteById(id);
    }

    public Mono<ResponseEntity<BusinessAddress>> updateBusinessAddress(Integer businessAddressId, BusinessAddress businessAddress) {
         return repository.findByBusinessAddressID(businessAddressId)
                 .flatMap(exsitingBusinessAddress -> {
                     updateBusinessAddress(exsitingBusinessAddress, businessAddress);
                     return repository.updateBusinessAddress(businessAddressId,
                             businessAddress.getUserProfileId(),
                             businessAddress.getAddressLine1(),
                             businessAddress.getAddressLine2(),
                             businessAddress.getCity(),
                             businessAddress.getState(),
                             businessAddress.getZip(),
                             businessAddress.getCountry(),
                             businessAddress.getBusinessCategory(),
                             businessAddress.getBusinessName(),
                             businessAddress.getBusinessEmail(),
                             businessAddress.getBusinessNature(),
                             businessAddress.getBusinessNumber(),
                             businessAddress.getBusinessPhone(),
                             businessAddress.getBusinessOwner(),
                             businessAddress.getOtherOwnershipDetails(),
                             businessAddress.getOwnershipStatus(),
                             businessAddress.getContactType(),
                             businessAddress.getNaicsCode(),
                             businessAddress.getNationalIdentifier(),
                             businessAddress.getEmployeeId(), HouseKeepingHelper.getUpdatedOn(), HouseKeepingHelper.getUpdatedBy())
                             .map(updatedBusinessAddress -> ResponseEntity.ok().body(updatedBusinessAddress));

                 });
    }


    private void updateBusinessAddress(BusinessAddress existingBusinessAddress, BusinessAddress businessAddress) {
        if(businessAddress.getEmployeeId() == null){
            businessAddress.setEmployeeId(existingBusinessAddress.getEmployeeId());
        }
        if(businessAddress.getBusinessOwner() == null){
            businessAddress.setBusinessOwner(existingBusinessAddress.getBusinessOwner());
        }
        if(businessAddress.getBusinessPhone() == null){
            businessAddress.setBusinessPhone(existingBusinessAddress.getBusinessPhone());
        }
        if(businessAddress.getBusinessEmail() == null){
            businessAddress.setBusinessEmail(existingBusinessAddress.getBusinessEmail());
        }
        if(businessAddress.getBusinessNumber() == null){
            businessAddress.setBusinessNumber(existingBusinessAddress.getBusinessNumber());
        }
        if(businessAddress.getBusinessCategory() == null){
            businessAddress.setBusinessCategory(existingBusinessAddress.getBusinessCategory());
        }
        if(businessAddress.getBusinessNature() == null){
            businessAddress.setBusinessNature(existingBusinessAddress.getBusinessNature());
        }
        if(businessAddress.getBusinessName() == null){
            businessAddress.setBusinessName(existingBusinessAddress.getBusinessName());
        }
        if(businessAddress.getAddressLine1() == null){
            businessAddress.setAddressLine1(existingBusinessAddress.getAddressLine1());
        }
        if(businessAddress.getAddressLine2() == null){
            businessAddress.setAddressLine2(existingBusinessAddress.getAddressLine2());
        }
        if(businessAddress.getCity() == null){
            businessAddress.setCity(existingBusinessAddress.getCity());
        }
        if(businessAddress.getState() == null){
            businessAddress.setState(existingBusinessAddress.getState());
        }
        if(businessAddress.getZip() == null){
            businessAddress.setZip(existingBusinessAddress.getZip());
        }
        if(businessAddress.getCountry() == null){
            businessAddress.setCountry(existingBusinessAddress.getCountry());
        }
        if(businessAddress.getContactType() == null){
            businessAddress.setContactType(existingBusinessAddress.getContactType());
        }
        if(businessAddress.getNationalIdentifier() == null){
            businessAddress.setNationalIdentifier(existingBusinessAddress.getNationalIdentifier());
        }
        if(businessAddress.getNaicsCode() == null){
            businessAddress.setNaicsCode(existingBusinessAddress.getNaicsCode());
        }
        if(businessAddress.getOwnershipStatus() == null){
            businessAddress.setOwnershipStatus(existingBusinessAddress.getOwnershipStatus());
        }
        if(businessAddress.getOtherOwnershipDetails() == null){
            businessAddress.setOtherOwnershipDetails(existingBusinessAddress.getOtherOwnershipDetails());
        }
    }


}
