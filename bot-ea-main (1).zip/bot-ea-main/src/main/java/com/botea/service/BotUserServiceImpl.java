package com.botea.service;

import com.botea.controller.dto.BotUserResponse;
import com.botea.controller.dto.UserAuthenticationDTO;
import com.botea.dao.entity.BotUser;
import com.botea.dao.repository.UserRepository;
import com.botea.exception.BotApplicationException;
import com.botea.helper.SecurityHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;


@Service
public class BotUserServiceImpl implements BotUserService {

    private final UserRepository botUserRepository;

    @Autowired
    public BotUserServiceImpl(UserRepository botUserRepository) {
        this.botUserRepository = botUserRepository;
    }

    public Mono<BotUserResponse> getUserById(Long id) {
        UserAuthenticationDTO user = SecurityHelper.getLoggedInUser();
        return botUserRepository.findBotUserByUserId(id)
                .flatMap(existingBotUserIn -> {
                    if (user == null || !user.botUserId().equals(existingBotUserIn.getBotUserId())) {
                        return Mono.error(new BotApplicationException("Unauthorized access"));
                    }
                    return botUserRepository.findById(existingBotUserIn.getBotUserId())
                            .flatMap(existingBotUser -> {
                                BotUserResponse botUserResponse = new BotUserResponse();
                                botUserResponse.setUserProfileId(id);
                                botUserResponse.setBotUserId(existingBotUser.getBotUserId());
                                botUserResponse.setUsername(existingBotUser.getUsername());
                                botUserResponse.setRole(existingBotUser.getRole());
                                botUserResponse.setPhone(existingBotUser.getPhone());
                                botUserResponse.setFirstName(existingBotUser.getFirstName());
                                botUserResponse.setMiddleName(existingBotUser.getMiddleName());
                                botUserResponse.setLastName(existingBotUser.getLastName());
                                botUserResponse.setLegalName(existingBotUser.getLegalName());
                                botUserResponse.setDob(existingBotUser.getDob());
                                botUserResponse.setAddressLine1(existingBotUser.getAddressLine1());
                                botUserResponse.setAddressLine2(existingBotUser.getAddressLine2());
                                botUserResponse.setCity(existingBotUser.getCity());
                                botUserResponse.setZip(existingBotUser.getZip());
                                botUserResponse.setState(existingBotUser.getState());
                                botUserResponse.setCountry(existingBotUser.getCountry());
                                botUserResponse.setCreated(existingBotUser.getCreated());
                                botUserResponse.setCreatedBy(existingBotUser.getCreatedBy());
                                botUserResponse.setUpdated(existingBotUser.getUpdated());
                                botUserResponse.setUpdatedBy(existingBotUser.getUpdatedBy());
                                botUserResponse.setIsTwoFactorEnabled(existingBotUser.getIsTwoFactorEnabled());
                                botUserResponse.setIsVerified(existingBotUser.getIsVerified());
                                botUserResponse.setTwoFactorType(existingBotUser.getTwoFactorType());
                                return Mono.just(botUserResponse);
                            })
                            .switchIfEmpty(Mono.error(new BotApplicationException("User not found with ID: " + id)));
                });
    }


    @Override
    public Mono<BotUser> getUserByUsername(String email) {
        return botUserRepository.findByUsername(email).switchIfEmpty(Mono.error(new RuntimeException("User not found with email: " + email)));
    }

    @Override
    public Mono<BotUser> saveUser(BotUser user) {
        return botUserRepository.save(user);
    }

    @Override
    public Mono<Void> markAsVerified(Long botUserId) {
        return botUserRepository.markAsVerified(botUserId);
    }

    @Override
    public Mono<ResponseEntity<BotUserResponse>> updateUser(Long id, BotUser botUser) {
        UserAuthenticationDTO user = SecurityHelper.getLoggedInUser();
        return botUserRepository.findBotUserByUserId(id).flatMap(
                existingbotUser-> {
                    if (user == null || !user.botUserId().equals(existingbotUser.getBotUserId())) {
                        return Mono.just(ResponseEntity.status(HttpStatus.UNAUTHORIZED).build());
                    }
                    return botUserRepository.findById(existingbotUser.getBotUserId())
                                    .flatMap(
                                        botUserDetails -> {
                                            updateBotUser(botUser, botUserDetails);
                                            return botUserRepository.updateUserDetails(id, botUser)
                                                    .map(updatedBotUser -> createBotUserResponse(id, updatedBotUser))
                                                    .defaultIfEmpty(ResponseEntity.notFound().build());

                                        });
                }
        );
    }

    private  ResponseEntity<BotUserResponse> createBotUserResponse(Long id, BotUser updatedBotUser) {
        BotUserResponse botUserResponse = new BotUserResponse();
        botUserResponse.setUserProfileId(id);
        botUserResponse.setBotUserId(updatedBotUser.getBotUserId());
        botUserResponse.setUsername(updatedBotUser.getUsername());
        botUserResponse.setRole(updatedBotUser.getRole());
        botUserResponse.setPhone(updatedBotUser.getPhone());
        botUserResponse.setFirstName(updatedBotUser.getFirstName());
        botUserResponse.setMiddleName(updatedBotUser.getMiddleName());
        botUserResponse.setLastName(updatedBotUser.getLastName());
        botUserResponse.setLegalName(updatedBotUser.getLegalName());
        botUserResponse.setDob(updatedBotUser.getDob());
        botUserResponse.setAddressLine1(updatedBotUser.getAddressLine1());
        botUserResponse.setAddressLine2(updatedBotUser.getAddressLine2());
        botUserResponse.setCity(updatedBotUser.getCity());
        botUserResponse.setZip(updatedBotUser.getZip());
        botUserResponse.setState(updatedBotUser.getState());
        botUserResponse.setCountry(updatedBotUser.getCountry());
        botUserResponse.setCreated(updatedBotUser.getCreated());
        botUserResponse.setCreatedBy(updatedBotUser.getCreatedBy());
        botUserResponse.setUpdated(updatedBotUser.getUpdated());
        botUserResponse.setUpdatedBy(updatedBotUser.getUpdatedBy());
        botUserResponse.setIsTwoFactorEnabled(updatedBotUser.getIsTwoFactorEnabled());
        botUserResponse.setIsVerified(updatedBotUser.getIsVerified());
        botUserResponse.setTwoFactorType(updatedBotUser.getTwoFactorType());
        return ResponseEntity.ok().body(botUserResponse);
    }

    private void updateBotUser(BotUser botUser, BotUser existingbotUser) {

        if(botUser.getFirstName()==null){
            botUser.setFirstName(existingbotUser.getFirstName());
        }
        if(botUser.getLastName()==null){
            botUser.setLastName(existingbotUser.getLastName());
        }
        if(botUser.getMiddleName()==null){
            botUser.setMiddleName(existingbotUser.getMiddleName());
        }
        if(botUser.getLegalName()==null){
            botUser.setLegalName(existingbotUser.getLegalName());
        }
        if(botUser.getPhone()==null){
            botUser.setPhone(existingbotUser.getPhone());
        }
        if(botUser.getIsTwoFactorEnabled()==null){
            botUser.setIsTwoFactorEnabled(existingbotUser.getIsTwoFactorEnabled());
        }
        if(botUser.getAddressLine1()==null){
            botUser.setAddressLine1(existingbotUser.getAddressLine1());
        }
        if(botUser.getAddressLine2()==null){
            botUser.setAddressLine2(existingbotUser.getAddressLine2());
        }
        if(botUser.getDob()==null){
            botUser.setDob(existingbotUser.getDob());
        }
        if(botUser.getCity()==null){
            botUser.setCity(existingbotUser.getCity());
        }
        if(botUser.getZip()==null){
            botUser.setZip(existingbotUser.getZip());
        }
        if(botUser.getState()==null){
            botUser.setState(existingbotUser.getState());
        }
    }
}
