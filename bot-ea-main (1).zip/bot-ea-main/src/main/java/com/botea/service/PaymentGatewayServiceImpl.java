package com.botea.service;

import org.springframework.stereotype.Service;

/**
 * @author Praveen
 */
@Service
public class PaymentGatewayServiceImpl implements PaymentGatewayService{

}
