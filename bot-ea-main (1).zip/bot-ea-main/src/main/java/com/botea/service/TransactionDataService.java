package com.botea.service;

import com.botea.controller.dto.TransactionUserDTO;
import com.botea.controller.dto.UpdateDraftRequest;
import com.botea.dao.entity.TransactionData;
import com.botea.dao.repository.TransactionDataRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.sql.Timestamp;
import java.util.Map;

@Slf4j
@Service
public class TransactionDataService {

    @Autowired
    private TransactionDataRepository transactionDataRepository;

    // Method to get the edited data by transaction ID
    public Mono<String> getEditedData(Long transactionDataId) {
        return transactionDataRepository.findByTransactionDataId(transactionDataId)
                .flatMap(transactionData -> {
                    if (transactionData.getEditedData() == null) {
                        return Mono.empty();
                    }
                    return Mono.just(transactionData.getEditedData());
                })
                .switchIfEmpty(Mono.empty());
    }

    public Mono<TransactionData> updateEditedData(UpdateDraftRequest updateDraftRequest) {
        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());

        return transactionDataRepository.updateEditDataData(currentTimestamp, 1L, updateDraftRequest.getTransactionDataId(), updateDraftRequest.getNewEditedData())
                .flatMap(updatedData -> {
                    if (updatedData == null) {
                        return Mono.error(new RuntimeException("Update failed. TransactionData not found."));
                    }
                    return Mono.just(updatedData);
                })
                .onErrorResume(e -> {
                    // Log the error for debugging
                    System.err.println("Error updating transaction data: " + e.getMessage());
                    return Mono.error(new RuntimeException("Failed to update transaction data.", e));
                });
    }

    public Flux<TransactionUserDTO> fetchTransactionDataByBotUserId(Long user_profile_id) {
        return transactionDataRepository.findTransactionDetails(user_profile_id);
    }

    public Mono<TransactionData> updatePdfPath(
            Long transactionDataId,
            String generatedDocumentPath,
            boolean isDocumentGenerated,
            String editedData,
            Timestamp updated,
            Long updatedBy
    ) {
        return transactionDataRepository.updatePdfPath(
                updated,
                updatedBy,
                transactionDataId,
                generatedDocumentPath,
                isDocumentGenerated,
                editedData
        );
    }

}
