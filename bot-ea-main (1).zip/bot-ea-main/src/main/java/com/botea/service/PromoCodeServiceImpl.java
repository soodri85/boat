package com.botea.service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.botea.dao.entity.PromoCode;
import com.botea.dao.entity.PromoCodeLicense;
import com.botea.dao.repository.PromoCodeRepository;
import com.botea.dao.repository.PromoCodeLicenseRepository;
import com.botea.utils.LicenseKeyGenerator;
import com.botea.utils.EmailType;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import org.springframework.beans.factory.annotation.Value;
import com.botea.dao.repository.LicenseRepository;
import com.botea.helper.SecurityHelper;
import com.botea.controller.dto.UserAuthenticationDTO;
import java.util.Arrays;

@Service
@Transactional
public class PromoCodeServiceImpl implements PromoCodeService {

    @Autowired
    private PromoCodeRepository promoCodeRepository;

    @Autowired
    private PromoCodeLicenseRepository promoCodeLicenseRepository;

    @Autowired
    private EmailService emailService;

    @Autowired
    private LicenseRepository licenseRepository;

    @Value("${license.admin.email}")
    private String adminEmail;

    @Override
    @Transactional
    public Flux<PromoCode> generateBulkPromoCodes(Double discount, String email, Integer expiry, Integer count, Integer usageLimit, String comment) {
        UserAuthenticationDTO user = SecurityHelper.getLoggedInUser();
        if (!"ADM".equals(user.role())) {
            return Flux.error(new RuntimeException("Unauthorized: Only administrators can generate promo codes"));
        }

        return Flux.range(0, count)
            .flatMap(i -> generateUniquePromoCode())
            .map(promoCodeValue -> {
                PromoCode promoCode = new PromoCode();
                promoCode.setPromoCodeValue(promoCodeValue);
                promoCode.setDiscount(discount);
                promoCode.setExpiry(expiry);
                promoCode.setIsUsed(false);
                promoCode.setUsageLimit(usageLimit);
                promoCode.setTimesUsed(0);
                promoCode.setComment(comment);
                return promoCode;
            })
            .flatMap(promoCode -> promoCodeRepository.save(promoCode))
            .collectList()
            .doOnNext(promoCodes -> {
                if (email != null && !email.isEmpty()) {
                    Map<String, Object> variables = new HashMap<>();
                    // For bulk generation, send all promo codes in the email
                    variables.put("promoCodes", promoCodes);  // Send the entire list for bulk template
                    variables.put("discount", promoCodes.get(0).getDiscount());
                    variables.put("usageLimit", promoCodes.get(0).getUsageLimit());
                    variables.put("expiry", promoCodes.get(0).getExpiry());
                    
                    // Get the admin email (first email) and CC emails (remaining emails)
                    String[] emails = email.split(",");
                    String adminEmail = emails[0].trim();
                    String[] ccEmails = emails.length > 1 ? 
                        Arrays.stream(emails).skip(1).map(String::trim).toArray(String[]::new) : 
                        null;

                    // Use bulk template for multiple codes, single template for one code
                    String templateName = promoCodes.size() > 1 ? 
                        EmailType.PROMO_CODE_BULK.getTemplateName() : 
                        EmailType.PROMO_CODE.getTemplateName();

                    // For single code, also set the individual promoCode for backward compatibility
                    if (promoCodes.size() == 1) {
                        variables.put("promoCode", promoCodes.get(0).getPromoCodeValue());
                    }

                    emailService.sendEmail(
                        adminEmail,
                        ccEmails,
                        "Your Bot-EA Promo Code" + (promoCodes.size() > 1 ? "s" : ""),
                        variables,
                        templateName
                    ).subscribe();
                }
            })
            .flatMapMany(Flux::fromIterable);
    }

    @Override
    @Transactional
    public Mono<PromoCode> generatePromoCode(Double discount, String email, Integer expiry) {
        return generateBulkPromoCodes(discount, email, expiry, 1, 1, null)
            .next();
    }

    private Mono<String> generateUniquePromoCode() {
        return Mono.defer(() -> {
            String promoCode = LicenseKeyGenerator.generateLicenseKey().substring(0, 6).toUpperCase();
            return promoCodeRepository.findByPromoCodeValue(promoCode)
                .flatMap(existingCode -> generateUniquePromoCode()) // Retry if exists
                .switchIfEmpty(Mono.just(promoCode));
        });
    }

    private Mono<Void> sendPromoCodeEmail(String email, PromoCode promoCode) {
        Map<String, Object> variables = new HashMap<>();
        variables.put("promoCode", promoCode.getPromoCodeValue());
        variables.put("discount", promoCode.getDiscount());
        variables.put("promoType", promoCode.getPromoType());
        variables.put("usageLimit", promoCode.getUsageLimit());
        variables.put("expiry", promoCode.getExpiry());
        
        // Get the admin email (first email) and CC emails (remaining emails)
        String[] emails = email.split(",");
        String adminEmail = emails[0].trim();
        String[] ccEmails = emails.length > 1 ? 
            Arrays.stream(emails).skip(1).map(String::trim).toArray(String[]::new) : 
            null;
        
        return emailService.sendEmail(
            adminEmail,
            ccEmails,
            "Your Promo Code for Bot-EA", 
            variables, 
            EmailType.PROMO_CODE.getTemplateName()
        );
    }

    @Override
    @Transactional(readOnly = true)
    public Mono<PromoCode> validatePromoCode(String promoCodeValue) {
        return promoCodeRepository.findByPromoCodeValue(promoCodeValue)
                .filter(promoCode -> {
                    if (promoCode.getTimesUsed() >= promoCode.getUsageLimit()) {
                        throw new RuntimeException("Promo code has reached its usage limit");
                    }
                    
                    if (promoCode.getExpiry() != null) {
                        LocalDateTime expiryDate = promoCode.getCreated().plusDays(promoCode.getExpiry());
                        if (LocalDateTime.now().isAfter(expiryDate)) {
                            throw new RuntimeException("Promo code has expired");
                        }
                    }
                    
                    return true;
                })
                .switchIfEmpty(Mono.error(new RuntimeException("Invalid promo code")));
    }

    @Override
    @Transactional
    public Mono<PromoCode> markPromoCodeAsUsed(String promoCodeValue, String licenseKey) {
        UserAuthenticationDTO user = SecurityHelper.getLoggedInUser();
        
        return validatePromoCode(promoCodeValue)
                .flatMap(promoCode -> 
                    licenseRepository.findByLicenseKey(licenseKey)
                        .flatMap(license -> {
                            // Create the relationship record
                            PromoCodeLicense promoCodeLicense = PromoCodeLicense.builder()
                                .promoCodeId(promoCode.getPromoCodeId())
                                .licenseId(license.getLicenseId())
                                .usedOn(LocalDateTime.now())
                                .created(LocalDateTime.now())
                                .createdBy(user.botUserId())
                                .build();

                            // Update promo code usage count
                            promoCode.setTimesUsed(promoCode.getTimesUsed() + 1);
                            promoCode.setIsUsed(promoCode.getTimesUsed() >= promoCode.getUsageLimit());
                            promoCode.setUpdated(LocalDateTime.now());

                            // Save both the relationship and updated promo code
                            return promoCodeLicenseRepository.save(promoCodeLicense)
                                .then(promoCodeRepository.save(promoCode));
                        })
                );
    }

    @Override
    @Transactional(readOnly = true)
    public Flux<PromoCode> getAllPromoCodes() {
        UserAuthenticationDTO user = SecurityHelper.getLoggedInUser();
        if (!"ADM".equals(user.role())) {
            return Flux.error(new RuntimeException("Unauthorized: Admin access required"));
        }
        return promoCodeRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Mono<Boolean> resendPromoCodeEmail(String promoCodeValue, String email) {
        UserAuthenticationDTO user = SecurityHelper.getLoggedInUser();
        if (!"ADM".equals(user.role())) {
            return Mono.error(new RuntimeException("Unauthorized: Admin access required"));
        }
        
        return promoCodeRepository.findByPromoCodeValue(promoCodeValue)
                .flatMap(promoCode -> {
                    if (promoCode.getTimesUsed() >= promoCode.getUsageLimit()) {
                        return Mono.error(new RuntimeException("Promo code has reached its usage limit"));
                    }
                    Map<String, Object> variables = new HashMap<>();
                    variables.put("promoCode", promoCode.getPromoCodeValue());
                    variables.put("discount", promoCode.getDiscount());
                    
                    // Get the admin email (first email) and CC emails (remaining emails)
                    String[] emails = email.split(",");
                    String adminEmail = emails[0].trim();
                    String[] ccEmails = emails.length > 1 ? 
                        Arrays.stream(emails).skip(1).map(String::trim).toArray(String[]::new) : 
                        null;
                    
                    return emailService.sendEmail(
                        adminEmail,
                        ccEmails,
                        "Your Promo Code for Bot-EA", 
                        variables, 
                        EmailType.PROMO_CODE.getTemplateName()
                    ).thenReturn(true);
                })
                .switchIfEmpty(Mono.error(new RuntimeException("Promo code not found")));
    }
} 