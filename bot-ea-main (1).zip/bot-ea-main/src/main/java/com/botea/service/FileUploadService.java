package com.botea.service;

import com.botea.controller.dto.*;
import com.botea.dao.entity.APIConfig;
import com.botea.dao.entity.TransactionData;
import com.botea.dao.repository.TransactionDataRepository;
import com.botea.exception.FileUploadException;
import com.botea.helper.DataLookUpHelper;
import com.botea.helper.FileUploadConfigProperties;
import com.botea.helper.SecurityHelper;
import com.botea.utils.FileUploadConstants;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeoutException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Slf4j
@Service
@RequiredArgsConstructor
public class FileUploadService {
    private final WebClient webClient;
    private final FileUploadConfigProperties config;
    private final TransactionDataRepository transactionRepository;
    private final ObjectMapper objectMapper;
    private final S3Service s3Service;
    private final LicenseManagementService licenseManagementService;
    private final DataLookUpHelper dataLookUpHelper;

    @Value("${license.minimum.credits}")
    private BigDecimal minimumCredits;

    public Mono<BatchResponse> uploadFile(UserAuthenticationDTO user, FileUploadRequest request, String authToken) {
        FilePart[] fileParts = request.getFiles();
        return getExtractionId(request.getTemplate_name())
                .flatMap(extractionId -> validateInput(extractionId, fileParts, authToken, request.getUser_profile_id())
                        .then(uploadFileAndProcessResponse(fileParts, extractionId, request.getBatch_id(), request.getYear()))
                        .flatMap(uploadResponse -> processBatchResults(uploadResponse, request)
                                .flatMap(batchResponse -> {
                                    // Deduct 1 credit for the upload
                                    return licenseManagementService.consumeLicenseCredit(request.getUser_profile_id())
                                            .then(Mono.defer(() -> zipAndUploadFiles(fileParts)
                                                    .flatMap(s3Key -> saveTransactionDataFinal(user, request, fileParts,
                                                            uploadResponse, batchResponse, s3Key)
                                                            .flatMap(transactionData -> updateFinalTransactionData(
                                                                    batchResponse)
                                                                    .thenReturn(batchResponse)))
                                                    .onErrorResume(error -> {
                                                        log.error("Error in S3 upload: {}", error.getMessage());
                                                        return Mono.error(new FileUploadException(
                                                                "S3 upload failed: " + error.getMessage(),
                                                                HttpStatus.INTERNAL_SERVER_ERROR));
                                                    })));
                                })
                                .onErrorResume(error -> {
                                    log.error("Error in batch processing: {}", error.getMessage());
                                    return Mono.error(
                                            new FileUploadException("Batch processing failed: " + error.getMessage(),
                                                    HttpStatus.INTERNAL_SERVER_ERROR));
                                }))
                        .timeout(Duration.ofMinutes(config.getTimeoutMinutes()))
                        .onErrorResume(error -> {
                            if (error instanceof TimeoutException) {
                                return Mono.error(
                                        new FileUploadException("Operation timed out", HttpStatus.REQUEST_TIMEOUT));
                            }
                            return Mono.error(error);
                        }));
    }

    private Mono<String> getExtractionId(String templateName) {
        return dataLookUpHelper.fetchAPIConfigLookUp()
                .filter(apiConfig -> apiConfig.getDocument().getDocumentId().equals(Long.parseLong(templateName)))
                .next()
                .map(APIConfig::getDataExtractionId)
                .defaultIfEmpty(FileUploadConstants.DEFAULT_EXTRACTION_ID);
    }

    private Mono<TransactionData> updateFinalTransactionData(BatchResponse response) {
        return transactionRepository.findByBatchId(response.getBatchId())
                .switchIfEmpty(Mono.error(new RuntimeException(
                        String.format(FileUploadConstants.ErrorMessages.TRANSACTION_NOT_FOUND,
                                response.getBatchId()))))
                .flatMap(data -> {
                    // Set the transaction ID in the response
                    response.setTransactionId(data.getTransactionDataId());
                    try {
                        String jsonResponse = objectMapper.writeValueAsString(response);
                        return transactionRepository.updateTransactionData(
                                null,
                                jsonResponse,
                                FileUploadConstants.BATCH_PROCESSING_COMPLETED,
                                false,
                                new Timestamp(System.currentTimeMillis()),
                                response.getBatchId());
                    } catch (Exception e) {
                        return Mono.error(new RuntimeException(
                                FileUploadConstants.ErrorMessages.INVALID_JSON, e));
                    }
                });
    }

    private boolean isUploaded(FileUploadResponse response) {
        return response != null && "uploaded".equals(response.getStatus());
    }

    private boolean isFinalStatusError(FileUploadResponse response) {
        return response != null &&
                ("FAILED".equals(response.getStatus()) || "ERROR".equals(response.getStatus()));
    }

    private Mono<BatchResponse> processBatchResults(FileUploadResponse response, FileUploadRequest request) {
        return webClient.post()
                .uri(config.getBatchResultsUrl())
                .header(HttpHeaders.AUTHORIZATION, getAuthorizationHeader())
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new BatchRequest(response.getExtractionId(), response.getBatchId()))
                .retrieve()
                .bodyToMono(BatchResponse.class)
                .timeout(Duration.ofMinutes(config.getTimeoutMinutes()))
                .flatMap(batchResponse -> {
                    // Set template_name and year from request
                    batchResponse.setTemplate_name(request.getTemplate_name());
                    batchResponse.setYear(request.getYear());
                    
                    // TODO: if individual items are failed, then return the batch response
                    if (batchResponse.getFinished() || "error".equalsIgnoreCase(batchResponse.getStatus())) {
                        return Mono.just(batchResponse);
                    } else {
                        return Mono.error(new FileUploadException("Batch is not yet processed", HttpStatus.ACCEPTED));
                    }
                })
                .retryWhen(Retry.fixedDelay(90, Duration.ofSeconds(2))
                        .filter(error -> error instanceof FileUploadException
                                && ((FileUploadException) error).getStatus() == HttpStatus.ACCEPTED)
                        .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) -> new FileUploadException(
                                "Batch processing timed out after retries", HttpStatus.REQUEST_TIMEOUT)))
                .onErrorResume(TimeoutException.class, error -> {
                    log.error("Batch processing timed out: {}", error.getMessage());
                    return Mono
                            .error(new FileUploadException("Batch processing timed out", HttpStatus.REQUEST_TIMEOUT));
                });
    }

    private Mono<FileUploadResponse> uploadFileAndProcessResponse(FilePart[] fileParts, String extractionId, String batchId, Integer year) {
        MultipartBodyBuilder bodyBuilder = new MultipartBodyBuilder();
        bodyBuilder.part("extractionId", extractionId);
        if (StringUtils.hasText(batchId)) {
            bodyBuilder.part("batchId", batchId);
        }
        
        if (year != null) {
            bodyBuilder.part("year", year);
        }

        for (FilePart filePart : fileParts) {
            bodyBuilder.asyncPart("files", filePart.content(), DataBuffer.class)
                    .filename(filePart.filename());
        }

        return webClient.post()
                .uri(config.getUploadUrl())
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .header(HttpHeaders.AUTHORIZATION, getAuthorizationHeader())
                .body(BodyInserters.fromMultipartData(bodyBuilder.build()))
                .retrieve()
                .bodyToMono(FileUploadResponse.class)
                .onErrorResume(WebClientResponseException.class, error -> {
                    log.error("API upload failed: {} - {}", error.getStatusCode(), error.getMessage());
                    return Mono.error(new FileUploadException("File upload API failed: " + error.getMessage(),
                            HttpStatus.valueOf(error.getStatusCode().value())));
                })
                .onErrorResume(Exception.class, error -> {
                    log.error("Unexpected error during file upload: {}", error.getMessage());
                    return Mono.error(new FileUploadException("Unexpected error during file upload",
                            HttpStatus.INTERNAL_SERVER_ERROR));
                });
    }

    private Mono<TransactionData> saveTransactionDataFinal(UserAuthenticationDTO user, FileUploadRequest request,
            FilePart[] fileParts,
            FileUploadResponse uploadResponse,
            BatchResponse batchResponse,
            String s3Key) {
        try {
            String fileNames = String.join(",", Arrays.stream(fileParts)
                    .map(FilePart::filename)
                    .toArray(String[]::new));

            String jsonResponse = objectMapper.writeValueAsString(batchResponse);
            UserAuthenticationDTO loggedInUser = SecurityHelper.getLoggedInUser();

            TransactionData transaction = TransactionData.builder()
                    .extractionId(uploadResponse.getExtractionId())
                    .batchId(uploadResponse.getBatchId())
                    .businessAddressId(request.getBusiness_address_id())
                    .userProfileId(request.getUser_profile_id())
                    .isDocumentGenerated(false)
                    .comments(FileUploadConstants.BATCH_PROCESSING_COMPLETED)
                    .uploadedDocumentPath(s3Key)
                    .extractedData(jsonResponse)
                    .editedData(jsonResponse)// for the first time the UI needs this data in this field
                    .year(request.getYear())
                    .document_id(1L)// TODO receive from request
                    .created(new Timestamp(System.currentTimeMillis()))
                    .createdBy(loggedInUser.botUserId())
                    .build();

            return transactionRepository.save(transaction)
                    .onErrorResume(error -> {
                        log.error("Database operation failed: {}", error.getMessage());
                        return Mono.error(new FileUploadException("Database operation failed",
                                HttpStatus.INTERNAL_SERVER_ERROR));
                    });
        } catch (Exception e) {
            return Mono.error(new FileUploadException(FileUploadConstants.ErrorMessages.INVALID_JSON,
                    HttpStatus.INTERNAL_SERVER_ERROR));
        }
    }

    private Mono<String> zipAndUploadFiles(FilePart[] fileParts) {
        return Flux.fromArray(fileParts)
                .flatMap(filePart -> filePart.content()
                        .map(DataBuffer::asByteBuffer)
                        .map(buffer -> {
                            byte[] bytes = new byte[buffer.remaining()];
                            buffer.get(bytes);
                            return bytes;
                        })
                        .reduce((bytes1, bytes2) -> {
                            byte[] result = new byte[bytes1.length + bytes2.length];
                            System.arraycopy(bytes1, 0, result, 0, bytes1.length);
                            System.arraycopy(bytes2, 0, result, bytes1.length, bytes2.length);
                            return result;
                        })
                        .map(bytes -> new FileContent(filePart.filename(), bytes)))
                .collectList()
                .flatMap(fileContents -> {
                    try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            ZipOutputStream zos = new ZipOutputStream(baos)) {

                        for (FileContent content : fileContents) {
                            ZipEntry zipEntry = new ZipEntry(content.filename);
                            zos.putNextEntry(zipEntry);
                            zos.write(content.content);
                            zos.closeEntry();
                        }
                        zos.finish();

                        return s3Service.uploadFile(baos.toByteArray());
                    } catch (Exception e) {
                        return Mono.error(new RuntimeException("Error creating zip file: " + e.getMessage()));
                    }
                });
    }

    private Mono<Void> validateInput(String extractionId, FilePart[] fileParts, String authToken, Long userProfileId) {
        if (!StringUtils.hasText(extractionId)) {
            return Mono.error(new FileUploadException(FileUploadConstants.ErrorMessages.EXTRACTION_ID_REQUIRED,
                    HttpStatus.BAD_REQUEST));
        }

        if (fileParts == null || fileParts.length == 0) {
            return Mono.error(new FileUploadException(FileUploadConstants.ErrorMessages.FILE_REQUIRED,
                    HttpStatus.BAD_REQUEST));
        }

        if (!StringUtils.hasText(authToken)) {
            return Mono.error(new FileUploadException(FileUploadConstants.ErrorMessages.AUTH_TOKEN_REQUIRED,
                    HttpStatus.UNAUTHORIZED));
        }

        // Validate each file in the array
        for (FilePart filePart : fileParts) {
            validateFileType(filePart.filename());
        }

        return validateLicenseCredits(userProfileId);
    }

    private Mono<Void> validateLicenseCredits(Long userProfileId) {
        return licenseManagementService.fetchLicenseInfo(userProfileId, "active")
                .flatMap(response -> {
                    if (response.getStatusCode() != HttpStatus.OK || response.getBody() == null) {
                        return Mono.error(new FileUploadException(
                                "Failed to fetch license info",
                                HttpStatus.INTERNAL_SERVER_ERROR));
                    }

                    Map<String, Object> body = response.getBody();
                    if (!body.containsKey("data")) {
                        return Mono.error(new FileUploadException(
                                "No license found",
                                HttpStatus.PAYMENT_REQUIRED));
                    }

                    @SuppressWarnings("unchecked")
                    List<LicenseManagementResponseDTO> licenses = (List<LicenseManagementResponseDTO>) body.get("data");
                    Optional<LicenseManagementResponseDTO> activeLicense = licenses.stream()
                            .filter(license -> Boolean.FALSE.equals(license.getIsExpired()) &&
                                    Boolean.TRUE.equals(license.getIsRegistered()))
                            .findFirst();

                    if (activeLicense.isEmpty()) {
                        return Mono.error(new FileUploadException(
                                "No active license found. Please register or renew your license.",
                                HttpStatus.PAYMENT_REQUIRED));
                    }

                    BigDecimal remainingCredits = activeLicense.get().getRemainingCredit();
                    if (remainingCredits.compareTo(BigDecimal.ONE) < 0) {
                        return Mono.error(new FileUploadException(
                                String.format("Insufficient credits. You have %d credits, minimum required: 1 credit",
                                        remainingCredits.intValue()),
                                HttpStatus.PAYMENT_REQUIRED));
                    }

                    return Mono.empty();
                });
    }

    private void validateFileType(String filename) {
        String contentType = determineContentType(filename);
        if (!config.getAllowedTypes().contains(contentType)) {
            throw new FileUploadException(
                    String.format(FileUploadConstants.ErrorMessages.INVALID_FILE_TYPE,
                            String.join(", ", config.getAllowedTypes())),
                    HttpStatus.BAD_REQUEST);
        }
    }

    private Retry createRetrySpec(int maxRetries, int delaySeconds) {
        return Retry.backoff(maxRetries, Duration.ofSeconds(delaySeconds))
                .filter(throwable -> throwable instanceof WebClientResponseException.Unauthorized ||
                        throwable instanceof TimeoutException)
                .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) -> new RuntimeException(
                        "Failed after " + maxRetries + " retries", retrySignal.failure()));
    }

    private String getAuthorizationHeader() {
        return FileUploadConstants.BEARER_PREFIX + config.getApiToken();
    }

    private String determineContentType(String filename) {
        String extension = filename.substring(filename.lastIndexOf('.') + 1).toLowerCase();
        return switch (extension) {
            case "pdf" -> FileUploadConstants.ContentTypes.PDF;
            case "doc" -> FileUploadConstants.ContentTypes.DOC;
            case "docx" -> FileUploadConstants.ContentTypes.DOCX;
            default -> FileUploadConstants.ContentTypes.OCTET_STREAM;
        };
    }

    // Helper class to store file content
    private static class FileContent {
        private final String filename;
        private final byte[] content;

        public FileContent(String filename, byte[] content) {
            this.filename = filename;
            this.content = content;
        }
    }

}