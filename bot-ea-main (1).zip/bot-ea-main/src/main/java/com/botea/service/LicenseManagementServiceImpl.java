package com.botea.service;

import com.botea.controller.dto.LicenseManagementDTO;
import com.botea.controller.dto.UserAuthenticationDTO;
import com.botea.controller.dto.LicenseManagementResponseDTO;
import com.botea.dao.entity.License;
import com.botea.dao.repository.CountryProfileRepository;
import com.botea.dao.repository.LicenseRepository;
import com.botea.dao.repository.LicenseTypeRepository;
import com.botea.dao.repository.UserProfileRepository;
import com.botea.helper.HouseKeepingHelper;
import com.botea.helper.SecurityHelper;
import com.botea.utils.EmailType;
import com.botea.utils.LicenseKeyGenerator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;
import com.fasterxml.jackson.databind.ObjectMapper;
import reactor.core.publisher.Flux;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Arrays;

/**
 * Author: Praveen
 * <p>
 * User should hit these APIs from their user profile where the country is
 * mapped.
 */
@Service
@Slf4j
public class LicenseManagementServiceImpl implements LicenseManagementService {

    private final LicenseRepository licenseRepository;
    private final CountryProfileRepository countryProfileRepository;
    private final LicenseTypeRepository licenseTypeRepository;
    private final EmailService emailService;
    private final PromoCodeService promoCodeService;
    private final UserProfileRepository userProfileRepository;
    private final PdfService pdfService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    public LicenseManagementServiceImpl(LicenseRepository licenseRepository,
                                      CountryProfileRepository countryProfileRepository,
                                      LicenseTypeRepository licenseTypeRepository,
                                      EmailService emailService,
                                      PromoCodeService promoCodeService,
                                      UserProfileRepository userProfileRepository,
                                      PdfService pdfService) {
        this.licenseRepository = licenseRepository;
        this.countryProfileRepository = countryProfileRepository;
        this.licenseTypeRepository = licenseTypeRepository;
        this.emailService = emailService;
        this.promoCodeService = promoCodeService;
        this.userProfileRepository = userProfileRepository;
        this.pdfService = pdfService;
    }

    private Mono<Boolean> isValidLicenseType(String licenseType) {
        return licenseTypeRepository.existsByCode(licenseType);
    }

    @Override
    @Transactional
    public Mono<License> generateLicenseOnly(LicenseManagementDTO licenseManagementDTO) {
        // License key generation
        String licenseKey = LicenseKeyGenerator.generateLicenseKey();

        // Validation for country
        if (!isValidCountry(licenseManagementDTO.getCountryCode())) {
            return Mono.error(new IllegalArgumentException("Invalid country code provided"));
        }

        // Validation for license type
        return isValidLicenseType(licenseManagementDTO.getLicenseType())
            .flatMap(isValid -> {
                if (!isValid) {
                    return Mono.error(new IllegalArgumentException("Invalid license type provided"));
                }

                return countryProfileRepository.findByCountryCode(licenseManagementDTO.getCountryCode())
                    .flatMap(countryProfile -> {
                        BigDecimal finalCredit = licenseManagementDTO.getTotalCredit();

                        License license = License.builder()
                            .licenseKey(licenseKey)
                            .countryProfileId(countryProfile.getCountryProfileId())
                            .isRegistered(false)
                            .isExpired(false)
                            .licenseType(licenseManagementDTO.getLicenseType())
                            .totalCredit(finalCredit)
                            .remainingCredit(finalCredit)
                            .comments(licenseManagementDTO.getComment())
                            .created(HouseKeepingHelper.getCreatedOn())
                            .createdBy(HouseKeepingHelper.getCreatedBy())
                            .updated(HouseKeepingHelper.getUpdatedOn())
                            .updatedBy(HouseKeepingHelper.getUpdatedBy())
                            .build();

                        return licenseRepository.save(license);
                    });
            });
    }

    @Override
    public Mono<Void> sendLicenseEmail(List<License> licenses, LicenseManagementDTO licenseManagementDTO) {
        if (licenses.isEmpty()) {
            return Mono.empty();
        }

        License firstLicense = licenses.get(0);
        
        // Prepare email variables
        Map<String, Object> emailVariables = new HashMap<>();
        emailVariables.put("email", licenseManagementDTO.getEmail());
        emailVariables.put("licenseKey", firstLicense.getLicenseKey());  // For backward compatibility
        emailVariables.put("licenseKeys", licenses.stream().map(License::getLicenseKey).toList());  // All license keys
        emailVariables.put("licenseCount", firstLicense.getTotalCredit());
        emailVariables.put("licenseType", firstLicense.getLicenseType());
        emailVariables.put("countryCode", licenseManagementDTO.getCountryCode());
        
        // Add optional payment-related variables only if they exist and have non-zero values
        if (licenseManagementDTO.getTotalPrice() != null && licenseManagementDTO.getTotalPrice().compareTo(BigDecimal.ZERO) > 0) {
            emailVariables.put("totalPrice", licenseManagementDTO.getTotalPrice().divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
            emailVariables.put("showPaymentInfo", true);
        }
        if (licenseManagementDTO.getDiscount() != null && licenseManagementDTO.getDiscount().compareTo(BigDecimal.ZERO) > 0) {
            emailVariables.put("discount", licenseManagementDTO.getDiscount().divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
            emailVariables.put("showDiscountInfo", true);
        }
        if (licenseManagementDTO.getPaidAmount() != null && licenseManagementDTO.getPaidAmount().compareTo(BigDecimal.ZERO) > 0) {
            emailVariables.put("paidAmount", licenseManagementDTO.getPaidAmount().divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
            emailVariables.put("showPaymentInfo", true);
        }
        if (licenseManagementDTO.getPromoCode() != null && !licenseManagementDTO.getPromoCode().trim().isEmpty()) {
            emailVariables.put("promoCode", licenseManagementDTO.getPromoCode());
            emailVariables.put("showPromoInfo", true);
        }

        // Handle promo code update if needed
        Mono<Void> updatePromoCode = licenseManagementDTO.getPromoCode() != null && 
            !licenseManagementDTO.getPromoCode().trim().isEmpty()
            ? Flux.fromIterable(licenses)
                .flatMap(license -> promoCodeService.markPromoCodeAsUsed(
                    licenseManagementDTO.getPromoCode(), 
                    license.getLicenseKey()
                ))
                .then()
            : Mono.empty();

        // Get the admin email (first email) and CC emails (remaining emails)
        String[] emails = licenseManagementDTO.getEmailList();
        String adminEmail = emails[0].trim();
        String[] ccEmails = emails.length > 1 ? 
            Arrays.stream(emails).skip(1).map(String::trim).toArray(String[]::new) : 
            null;

        // Send email with CC
        return updatePromoCode
            .then(emailService.sendEmail(
                adminEmail,
                ccEmails,
                "Your Bot-EA License Details",
                emailVariables,
                EmailType.LICENSE_GENERATED.getTemplateName()
            ));
    }

    @Override
    @Transactional
    public Mono<ResponseEntity<Map<String, Object>>> generateLicense(LicenseManagementDTO licenseManagementDTO) {
        // Set default count if not provided
        int count = licenseManagementDTO.getCount() != null ? licenseManagementDTO.getCount() : 1;
        
        // Validate count
        if (count <= 0) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("message", "Please enter a valid number of licenses to generate");
            return Mono.just(ResponseEntity.badRequest().body(errorResponse));
        }

        // Get list of emails
        String[] emails = licenseManagementDTO.getEmailList();
        if (emails.length == 0) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("message", "At least one email address is required");
            return Mono.just(ResponseEntity.badRequest().body(errorResponse));
        }

        // Generate licenses
        return Flux.range(0, count)
            .flatMap(i -> generateLicenseOnly(licenseManagementDTO))
            .collectList()
            .flatMap(licenses -> {
                // Send email with all licenses
                return sendLicenseEmail(licenses, licenseManagementDTO)
                    .thenReturn(licenses);
            })
            .map(licenses -> {
                Map<String, Object> responseData = new HashMap<>();
                responseData.put("message", "License(s) created");
                
                // Get all license keys
                List<String> allLicenseKeys = licenses.stream()
                    .map(License::getLicenseKey)
                    .toList();
                
                // If only one license was generated, return it in the old format
                if (allLicenseKeys.size() == 1) {
                    Map<String, String> data = new HashMap<>();
                    data.put("licenseKey", allLicenseKeys.get(0));
                    responseData.put("data", data);
                } else {
                    responseData.put("data", allLicenseKeys);
                }
                
                return ResponseEntity.ok(responseData);
            })
            .onErrorResume(e -> {
                String message = e.getMessage();
                Map<String, Object> errorResponse = new HashMap<>();
                if (message.contains("Invalid country code") || message.contains("Invalid license type")) {
                    errorResponse.put("message", message);
                    return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse));
                } else {
                    errorResponse.put("message", "Failed to generate license: " + message);
                    return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse));
                }
            });
    }

    // Helper method to validate country code
    private boolean isValidCountry(String countryCode) {
        // Example logic: Validate against a predefined list of supported country codes
        List<String> supportedCountries = List.of("USA", "CAN");
        return supportedCountries.contains(countryCode);
    }

    @Override
    @Transactional
    public Mono<ResponseEntity<String>> registerLicense(LicenseManagementDTO licenseManagementDTO) {
        return licenseRepository.findByLicenseKey(licenseManagementDTO.getLicenseKey())
                .flatMap(license -> {
                    if (license.getIsExpired()) {
                        return Mono.just(ResponseEntity.status(HttpStatus.GONE).body("License expired"));
                    } else if (license.getIsRegistered()) {
                        return Mono.just(ResponseEntity.status(HttpStatus.CONFLICT).body("License already registered"));
                    }

                    return countryProfileRepository.findByCountryCode(licenseManagementDTO.getCountryCode())
                            .flatMap(countryProfile -> {
                                if (!countryProfile.getCountryProfileId().equals(license.getCountryProfileId())) {
                                    return Mono.just(ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE)
                                            .body("License doesn't belong to the requested country"));
                                }

                                // First find any active license and get its remaining credits
                                Mono<License> activeLicenseMono = licenseRepository.findActiveLicenseForUserAndCountry(
                                        SecurityHelper.getLoggedInUser().botUserId(),
                                        countryProfile.getCountryProfileId()
                                )
                                .defaultIfEmpty(License.builder().remainingCredit(BigDecimal.ZERO).build());

                                return activeLicenseMono.flatMap(activeLicense -> {
                                    BigDecimal remainingCreditsFromOldLicense = activeLicense.getRemainingCredit();
                                    
                                    // Expire the old license
                                    return licenseRepository.expireActiveLicenses(
                                            SecurityHelper.getLoggedInUser().botUserId(),
                                            countryProfile.getCountryProfileId(),
                                            HouseKeepingHelper.getUpdatedBy()
                                    ).then(
                                        // Register new license with carried over credits
                                        licenseRepository.updateLicenseWithCarriedCredits(
                                            SecurityHelper.getLoggedInUser().botUserId(),
                                            license.getLicenseKey(),
                                            remainingCreditsFromOldLicense,
                                            HouseKeepingHelper.getUpdatedBy()
                                        ).map(updatedRows -> updatedRows > 0
                                            ? ResponseEntity.ok("License registered with carried over credits")
                                            : ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                                    .body("License couldn't register"))
                                    );
                                });
                            })
                            .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND)
                                    .body("Country doesn't exist")));
                })
                .onErrorResume(e -> {
                    log.error("Unable to register license: {}", e.getMessage());
                    return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body("License couldn't be registered"));
                })
                .switchIfEmpty(Mono.error(new ResponseStatusException(HttpStatus.NOT_FOUND, "License not found")));
    }

    @Override
    @Transactional
    public Mono<License> renewLicenseOnly(LicenseManagementDTO licenseManagementDTO) {
        UserAuthenticationDTO loggedInUser = SecurityHelper.getLoggedInUser();
        log.info("Starting license renewal for user: {} and country: {}", 
            loggedInUser.username(), licenseManagementDTO.getCountryCode());
            
        return licenseRepository.findActiveLicenseByCountryCodeAndEmail(
                licenseManagementDTO.getCountryCode(),
                loggedInUser.username()
            )
            .doOnNext(license -> log.info("Found active license: {}", license.getLicenseKey()))
            .doOnError(error -> log.error("Error finding active license: {}", error.getMessage()))
            .flatMap(license -> {
                if (license.getValidity() != null && 
                    license.getValidity().before(new Date(System.currentTimeMillis()))) {
                    return Mono.error(new IllegalStateException("License has expired"));
                }

                log.info("Updating license credits for license: {}", license.getLicenseKey());
                BigDecimal newTotalCredit = license.getRemainingCredit().add(licenseManagementDTO.getTotalCredit());
                
                return licenseRepository.updateLicenseCredits(
                        license.getLicenseKey(),
                        newTotalCredit,
                        newTotalCredit,
                        HouseKeepingHelper.getUpdatedBy()
                )
                .doOnNext(result -> log.info("License credit update result: {}", result))
                .flatMap(rowsUpdated -> {
                    if (rowsUpdated > 0) {
                        return licenseRepository.findByLicenseKey(license.getLicenseKey());
                    }
                    return Mono.error(new RuntimeException("Failed to update license credits"));
                });
            })
            .switchIfEmpty(Mono.error(new IllegalStateException("No active license found")));
    }

    @Override
    public Mono<Void> sendRenewalEmail(License license, LicenseManagementDTO licenseManagementDTO) {
        // Prepare email variables
        Map<String, Object> emailVariables = new HashMap<>();
        emailVariables.put("email", licenseManagementDTO.getEmail());
        emailVariables.put("licenseKey", license.getLicenseKey());
        emailVariables.put("licenseCount", license.getTotalCredit());
        emailVariables.put("licenseType", license.getLicenseType());
        emailVariables.put("countryCode", licenseManagementDTO.getCountryCode());
        
        // Add optional payment-related variables only if they exist and have non-zero values
        if (licenseManagementDTO.getTotalPrice() != null && licenseManagementDTO.getTotalPrice().compareTo(BigDecimal.ZERO) > 0) {
            emailVariables.put("totalPrice", licenseManagementDTO.getTotalPrice().divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
            emailVariables.put("showPaymentInfo", true);
        }
        if (licenseManagementDTO.getDiscount() != null && licenseManagementDTO.getDiscount().compareTo(BigDecimal.ZERO) > 0) {
            emailVariables.put("discount", licenseManagementDTO.getDiscount().divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
            emailVariables.put("showDiscountInfo", true);
        }
        if (licenseManagementDTO.getPaidAmount() != null && licenseManagementDTO.getPaidAmount().compareTo(BigDecimal.ZERO) > 0) {
            emailVariables.put("paidAmount", licenseManagementDTO.getPaidAmount().divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
            emailVariables.put("showPaymentInfo", true);
        }
        if (licenseManagementDTO.getPromoCode() != null && !licenseManagementDTO.getPromoCode().trim().isEmpty()) {
            emailVariables.put("promoCode", licenseManagementDTO.getPromoCode());
            emailVariables.put("showPromoInfo", true);
        }

        // Handle promo code update if needed
        Mono<Void> updatePromoCode = licenseManagementDTO.getPromoCode() != null && 
            !licenseManagementDTO.getPromoCode().trim().isEmpty()
            ? promoCodeService.markPromoCodeAsUsed(
                licenseManagementDTO.getPromoCode(), 
                license.getLicenseKey()
            ).then()
            : Mono.empty();

        // Send email
        return updatePromoCode
            .then(emailService.sendEmail(
                licenseManagementDTO.getEmail(),
                "Your Bot-EA License Renewal",
                emailVariables,
                EmailType.LICENSE_RENEWED.getTemplateName()
            ));
    }

    @Override
    @Transactional
    public Mono<ResponseEntity<Map<String, Object>>> renewLicense(LicenseManagementDTO licenseManagementDTO) {
        return renewLicenseOnly(licenseManagementDTO)
            .flatMap(license -> {
                Map<String, Object> responseData = new HashMap<>();
                responseData.put("message", "License renewed");
                Map<String, String> data = new HashMap<>();
                data.put("licenseKey", license.getLicenseKey());
                responseData.put("data", data);

                return sendRenewalEmail(license, licenseManagementDTO)
                    .thenReturn(ResponseEntity.ok(responseData));
            })
            .onErrorResume(e -> {
                String message = e.getMessage();
                Map<String, Object> errorResponse = new HashMap<>();
                if (message.contains("No active license found")) {
                    errorResponse.put("message", "No active license found for renewal");
                    return Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse));
                } else if (message.contains("License has expired")) {
                    errorResponse.put("message", "Cannot renew expired license");
                    return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse));
                } else {
                    errorResponse.put("message", "Failed to renew license: " + message);
                    return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse));
                }
            });
    }

    @Override
    @Transactional
    public Mono<ResponseEntity<String>> consumeLicenseCredit(LicenseManagementDTO licenseManagementDTO) {
        return countryProfileRepository.findByCountryCode(licenseManagementDTO.getCountryCode())
                .flatMap(countryProfile -> {
                    return licenseRepository.findActiveLicenseForUserAndCountry(
                            59L,
                            countryProfile.getCountryProfileId()
                    ).flatMap(activeLicense -> {
                        if (activeLicense.getValidity() != null && 
                            activeLicense.getValidity().before(new Date(System.currentTimeMillis()))) {
                            return Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN)
                                    .body("License has expired"));
                        }

                        // Deduct one credit for the file upload
                        return licenseRepository.atomicUpdateRemainingCredit(
                                activeLicense.getLicenseKey(),
                                BigDecimal.ONE,
                                activeLicense.getRemainingCredit(),
                                HouseKeepingHelper.getUpdatedBy()
                        ).map(rowsUpdated -> rowsUpdated > 0
                                ? ResponseEntity.ok("Success")
                                : ResponseEntity.status(HttpStatus.CONFLICT)
                                        .body("Please try again"));
                    }).switchIfEmpty(Mono.error(new ResponseStatusException(HttpStatus.NOT_FOUND,
                            "No active license found")));
                })
                .switchIfEmpty(Mono.error(new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Country not found")))
                .onErrorResume(e -> {
                    log.error("Credit calculation error: {}", e.getMessage());
                    return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body("An error occurred"));
                });
    }

    @Override
    @Transactional
    public Mono<ResponseEntity<String>> consumeLicenseCredit(Long userProfileId) {
        return userProfileRepository.findUserProfileById(userProfileId)
                .flatMap(userProfile -> {
                    return licenseRepository.findActiveLicenseForUserAndCountry(
                            userProfile.getBotUserId(),
                            userProfile.getCountryProfileId()
                    ).flatMap(activeLicense -> {
                        if (activeLicense.getValidity() != null && 
                            activeLicense.getValidity().before(new Date(System.currentTimeMillis()))) {
                            return Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN)
                                    .body("License has expired"));
                        }

                        // Deduct one credit for the file upload
                        return licenseRepository.atomicUpdateRemainingCredit(
                                activeLicense.getLicenseKey(),
                                BigDecimal.ONE,
                                activeLicense.getRemainingCredit(),
                                HouseKeepingHelper.getUpdatedBy()
                        ).map(rowsUpdated -> rowsUpdated > 0
                                ? ResponseEntity.ok("Success")
                                : ResponseEntity.status(HttpStatus.CONFLICT)
                                        .body("Please try again"));
                    }).switchIfEmpty(Mono.error(new ResponseStatusException(HttpStatus.NOT_FOUND,
                            "No active license found")));
                })
                .switchIfEmpty(Mono.error(new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "User profile not found")))
                .onErrorResume(e -> {
                    log.error("Credit calculation error: {}", e.getMessage());
                    return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body("An error occurred"));
                });
    }

    private BigDecimal calculateCreditRequired(BigDecimal licenseCreditDocument) {
        // Return one credit per file upload
        return licenseCreditDocument;
    }

    @Override
    public Mono<ResponseEntity<Map<String, Object>>> fetchLicenseInfo(Long userProfileId, String status) {
        return userProfileRepository.findById(userProfileId)
            .flatMap(userProfile -> {
                Flux<LicenseManagementResponseDTO> licensesFlux = licenseRepository.findLicenseDetailsByBotUserId(
                        userProfile.getBotUserId(),
                        userProfile.getCountryProfileId()
                    );

                if (status != null && status.equalsIgnoreCase("active")) {
                    licensesFlux = licensesFlux.filter(license -> 
                        Boolean.TRUE.equals(license.getIsRegistered()) && 
                        !Boolean.TRUE.equals(license.getIsExpired())
                    );
                }

                return licensesFlux
                    .collectList()
                    .map(licenses -> {
                        Map<String, Object> response = new HashMap<>();
                        response.put("data", licenses);
                        return ResponseEntity.ok().body(response);
                    });
            })
            .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(Map.of("message", "User profile not found"))))
            .onErrorResume(e -> {
                log.error("Error fetching license info: {}", e.getMessage(), e);
                return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("message", "Failed to fetch license information: " + e.getMessage())));
            });
    }

    @Override
    public Mono<Boolean> resendLicenseEmail(String licenseKey, String email) {
        UserAuthenticationDTO user = SecurityHelper.getLoggedInUser();
        if (!"ADM".equals(user.role())) {
            return Mono.error(new RuntimeException("Unauthorized: Admin access required"));
        }

        return licenseRepository.findByLicenseKey(licenseKey)
                .flatMap(license -> {
                    Map<String, Object> variables = new HashMap<>();
                    variables.put("email", email);
                    variables.put("licenseKey", licenseKey);
                    variables.put("totalCredit", license.getTotalCredit());
                    variables.put("remainingCredit", license.getRemainingCredit());
                    variables.put("licenseType", license.getLicenseType());
                    
                    return emailService.sendEmail(
                        email,
                        "Your Bot-EA License Details",
                        variables,
                        EmailType.LICENSE_GENERATED.getTemplateName()
                    ).thenReturn(true);
                })
                .switchIfEmpty(Mono.error(new RuntimeException("License not found")));
    }
}
