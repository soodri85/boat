package com.botea.service;

import com.botea.controller.dto.VerifyOtpRequest;
import com.botea.dao.entity.BotUser;
import com.botea.dao.entity.Otp;
import com.botea.dao.entity.Token;
import com.botea.dao.repository.OtpRepository;
import com.botea.exception.BotApplicationException;
import com.botea.helper.SecurityHelper;
import com.botea.utils.EmailType;
import com.botea.utils.JwtTokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

@Service
@Slf4j
public class EmailOTPService {

    @Autowired
    private OtpRepository otpRepository;

    @Autowired
    private CustomReactiveUserDetailsService userDetailsService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private BotUserService botUserService;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private  TokenService tokenService;

    @Autowired
    private UserProfileService userProfileService;

    public Mono<String> sendRegisterVerifyEmail(String email) {
        return userDetailsService.findUserByUsername(email)
                .flatMap(user -> {
                    return sendOtpEmail(email, user, "registration", "Registration confirmation for Bot-EA", EmailType.REGISTRATION);
                })
                .doOnError(e -> log.error("Failed to process OTP for email {}: {}", email, e.getMessage()))
                .onErrorMap(e -> !(e instanceof BotApplicationException),
                        e -> new BotApplicationException("Failed to process OTP: " + e.getMessage()));
    }

    public Mono<String> sendOTPAndVerifyUser(String email, String action, String subject, EmailType emailType ) {
        return userDetailsService.findUserByUsername(email)
                .flatMap(user -> {
                    return sendOtpEmail(email, user, action, subject, emailType);
                })
                .doOnError(e -> log.error("Failed to process OTP for email {}: {}", email, e.getMessage()))
                .onErrorMap(e -> !(e instanceof BotApplicationException),
                        e -> new BotApplicationException("Failed to process OTP: " + e.getMessage()));
    }

    private Mono<String> sendOtpEmail(String email, BotUser user, String action, String subject, EmailType emailType) {
        LocalDateTime currentTime = LocalDateTime.now();
        Integer generatedOtp = generateOtp();
        Otp otp = buildOtp(user, currentTime, generatedOtp, emailType);

        return otpRepository.save(otp)
                .flatMap(savedOtp -> {
                    Map<String, Object> emailVariables = Map.of(
                            "name", getName(user),
                            "otp", generatedOtp,
                            "action", action,
                            "duration", "15 minutes",
                            "otpType", emailType.getDisplayName()
                    );

                    return emailService.sendEmail(
                                    email,
                                    subject,
                                    emailVariables,
                                    emailType.getTemplateName()
                            )
                            .thenReturn("Success")
                            .doOnSuccess(result -> log.info("OTP email sent successfully to {}", email))
                            .doOnError(e -> log.error("Failed to send OTP email to {}: {}", email, e.getMessage()));
                })
                .onErrorResume(e -> {
                    log.error("Error occurred while sending OTP email to {}: {}", email, e.getMessage(), e);
                    return Mono.error(new BotApplicationException("Failed to send email. Please try again."));

                });
    }

    private static Otp buildOtp(BotUser user, LocalDateTime currentTime, Integer generatedOtp, EmailType emailType) {
        Otp otp = Otp.builder()
                .created(currentTime)
                .updated(currentTime)
                .createdBy(user.getBotUserId())
                .isExpired(false)
                .otp(generatedOtp)
                .botUserId(user.getBotUserId())
                .otpType(emailType.getOtpType())
                .build();
        return otp;
    }

    private Integer generateOtp() {
        Random random = new Random();
        return 100_000 + random.nextInt(900_000);
    }

    public String getName(BotUser user) {
        StringBuilder nameBuilder = new StringBuilder();
        if (user.getFirstName() != null) {
            nameBuilder.append(user.getFirstName()).append(" ");
        }
        if (user.getMiddleName() != null) {
            nameBuilder.append(user.getMiddleName()).append(" ");
        }
        if (user.getLastName() != null) {
            nameBuilder.append(user.getLastName());
        }
        if (nameBuilder.isEmpty()) {
            nameBuilder.append(user.getUsername());
        }
        return nameBuilder.toString().trim();
    }

    public Mono<String> verifyOtp(VerifyOtpRequest request) {
        return botUserService.getUserByUsername(request.getEmail())
                .switchIfEmpty(Mono.error(new RuntimeException("User not found")))
                .flatMap(user -> otpRepository.findByUserIdAndOtpTypeAndExpiredFalse(
                                user.getBotUserId(),
                                request.getOtp_type(),
                                request.getOtp())
                        .switchIfEmpty(Mono.error(new RuntimeException("Invalid OTP or expired")))
                        .flatMap(otp -> {
                            // Mark OTP as expired
                            return otpRepository.markOtpAsExpired(otp.getBotUserId())
                                    .then(botUserService.markAsVerified(user.getBotUserId())) // mark user as verified
                                    .then(Mono.just("Success")); // Return success message
                        })
                );
    }


    public Mono<ResponseEntity<Map<String, Object>>> buildUserResponse(String userName, ServerHttpRequest servletRequest ) {
        return userDetailsService.findUserByUsername(userName)
                .flatMap(userDetails -> {
                    // Generate tokens
                    String accessToken = jwtTokenUtil.generateToken(userDetails.getUsername());
                    String refreshToken = jwtTokenUtil.generateRefreshToken(userDetails.getUsername());

                    // Create new token entity
                    Token token = createToken(userDetails, accessToken, servletRequest);


                    // Process token and build response
                    return processTokenAndBuildResponse(
                            token,
                            userDetails,
                            accessToken,
                            refreshToken
                    );
                })
                .onErrorResume(this::handleLoginError);
    }


    private Mono<ResponseEntity<Map<String, Object>>> processTokenAndBuildResponse(
            Token token,
            BotUser userDetails,
            String accessToken,
            String refreshToken
    ) {
        return tokenService.deactivatePreviousTokens(userDetails.getBotUserId())
                .then(tokenService.save(token))
                .flatMap(savedToken -> buildUserProfileResponse(
                        userDetails,
                        accessToken,
                        refreshToken
                ));
    }


    private Token createToken(BotUser userDetails, String accessToken, ServerHttpRequest servletRequest) {
        SecurityHelper.UserAgentDTO userDeviceInfo = SecurityHelper.getUserDeviceInfo(servletRequest);

        Token token = new Token();
        token.setToken(accessToken);
        token.setIsLoggedOut(false);
        token.setIsActive(true);
        token.setBotUserId(userDetails.getBotUserId());
        token.setUpdated(null);
        token.setLoginTime(LocalDateTime.now(ZoneId.systemDefault()));
        token.setUserAgent(userDeviceInfo.getUserAgent());
        token.setIpAddress(userDeviceInfo.getIpAddress());

        return token;
    }


    private Mono<ResponseEntity<Map<String, Object>>> handleLoginError(Throwable e) {
        if (e instanceof BadCredentialsException) {
            log.warn("Login failed due to bad credentials");
            return Mono.just(ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "Invalid credentials")));
        }

        log.error("Login failed", e);
        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "An unexpected error occurred")));
    }


    private Mono<ResponseEntity<Map<String, Object>>> buildUserProfileResponse(
            BotUser userDetails,
            String accessToken,
            String refreshToken
    ) {
        return userProfileService.getUserProfilesWithCountryAndLicenseInfo(userDetails.getBotUserId())  // Use the new method with the join
                .collectList() // Collect the Flux into a List
                .flatMap(userProfiles -> {
                    List<Map<String, Object>> profilesList = userProfiles.stream()
                            .map(profile -> {
                                Map<String, Object> profileMap = new HashMap<>();
                                profileMap.put("userProfileId", profile != null ? profile.getUserProfileId() : "N/A");
                                profileMap.put("countryProfileId", profile.getCountryProfileId() != null ? profile.getCountryProfileId() : "N/A");
                                profileMap.put("isDefault", profile.getIsDefault() != null ? profile.getIsDefault() : false);
                                profileMap.put("isVerified", profile.getIsVerified() != null ? profile.getIsVerified() : false);
                                profileMap.put("countryName", profile.getCountryName() != null ? profile.getCountryName() : "N/A");
                                profileMap.put("countryCode", profile.getCountryCode() != null ? profile.getCountryCode() : "N/A");
                                profileMap.put("language", profile.getLanguage() != null ? profile.getLanguage() : "N/A");
                                profileMap.put("languageCode", profile.getLanguageCode() != null ? profile.getLanguageCode() : "N/A");
                                profileMap.put("currency", profile.getCurrency() != null ? profile.getCurrency() : "N/A");
                                profileMap.put("isRegistered", profile.getIsRegistered() != null ? profile.getIsRegistered() : false);
                                profileMap.put("isExpired", profile.getIsExpired() != null ? profile.getIsExpired() : false);
                                profileMap.put("totalCredit", profile.getTotalCredit() != null ? profile.getTotalCredit() : 0);
                                profileMap.put("remainingCredit", profile.getRemainingCredit() != null ? profile.getRemainingCredit() : 0);
                                List<Map<String, Object>> documentsList = profile.getDocuments().stream()
                                        .map(document -> {
                                            Map<String, Object> documentMap = new HashMap<>();
                                            documentMap.put("documentId", document.getDocumentId() != null ? document.getDocumentId() : "N/A");
                                            documentMap.put("documentName", document.getDocumentName() != null ? document.getDocumentName() : "N/A");
                                            return documentMap;
                                        })
                                        .collect(Collectors.toList());
                                profileMap.put("documents", documentsList != null ? documentsList : "N/A");

                                return profileMap;
                            })
                            .collect(Collectors.toList());

                    Map<String, Object> response = new HashMap<>();
                    response.put("token", accessToken);
                    response.put("refresh_token", refreshToken);
                    response.put("country", userDetails.getCountry());
                    response.put("username", userDetails.getUsername());
                    response.put("legalName", userDetails.getLegalName());
                    response.put("role", userDetails.getRole());
                    response.put("is_two_factor_enabled", userDetails.getIsTwoFactorEnabled());
                    response.put("userProfiles", profilesList);

                    return Mono.just(ResponseEntity.ok(response));

                });
    }

}
