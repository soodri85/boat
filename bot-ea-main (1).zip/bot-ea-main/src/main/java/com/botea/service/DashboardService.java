package com.botea.service;

import com.botea.controller.dto.DashboardStatistics;
import reactor.core.publisher.Mono;

public interface DashboardService {
    Mono<DashboardStatistics.RevenueStats> getRevenueStats();
    Mono<DashboardStatistics.ActiveUserStats> getActiveUserStats();
    Mono<DashboardStatistics.TransactionStats> getTransactionStats(Integer year);
    Mono<DashboardStatistics.UserStats> getUserRegistrationStats(Integer year);
    Mono<DashboardStatistics.SubscriptionStats> getSubscriptionStats(Integer year);
    Mono<DashboardStatistics.BasicStats> getBasicStats();
} 