package com.botea.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.botea.dao.entity.CountryProfile;
import com.botea.dao.repository.CountryProfileRepository;

import reactor.core.publisher.Mono;

@Service
public class CountryProfileService {

    private final CountryProfileRepository countryProfileRepository;

    @Autowired
    public CountryProfileService(CountryProfileRepository countryProfileRepository) {
        this.countryProfileRepository = countryProfileRepository;
    }

    // Create or update a country profile
    public Mono<CountryProfile> createOrUpdateCountryProfile(CountryProfile countryProfile) {
        return countryProfileRepository.save(countryProfile);
    }

    public Mono<CountryProfile> getCountryProfileByCountryName(String countryName) {
        return countryProfileRepository.findByCountryName(countryName);
    }

    public Mono<CountryProfile> getCountryProfileByCountryCode(String countryName) {
        return countryProfileRepository.findByCountryCode(countryName);
    }

    // Get a country profile by ID
    public Mono<CountryProfile> getCountryProfileById(Long countryProfileId) {
        return countryProfileRepository.findById(countryProfileId);
    }

    // Delete a country profile by ID
    public Mono<Void> deleteCountryProfileById(Long countryProfileId) {
        return countryProfileRepository.deleteById(countryProfileId);
    }

}
