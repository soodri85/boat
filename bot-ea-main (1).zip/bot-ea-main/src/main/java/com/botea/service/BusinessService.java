package com.botea.service;

import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class BusinessService {

    public Mono<String> performBusinessAction(Long userId, String data) {
        // Business logic
        return Mono.just("Processed data: " + data);
    }
}
