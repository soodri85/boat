package com.botea.service;

import org.springframework.stereotype.Component;
import java.net.NetworkInterface;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Enumeration;

@Component
public class UniqueIdGenerator {
    private static final long CUSTOM_EPOCH = Instant.parse("2024-01-01T00:00:00Z").toEpochMilli();
    
    // Configuration parameters
    private static final int NODE_ID_BITS = 10;
    private static final int SEQUENCE_BITS = 12;
    
    private static final long MAX_NODE_ID = (1L << NODE_ID_BITS) - 1;
    private static final long MAX_SEQUENCE = (1L << SEQUENCE_BITS) - 1;
    
    // Shift amounts
    private static final int NODE_ID_SHIFT = SEQUENCE_BITS;
    private static final int TIMESTAMP_SHIFT = NODE_ID_BITS + SEQUENCE_BITS;
    
    private final long nodeId;
    private volatile long lastTimestamp = -1L;
    private volatile long sequence = 0L;

    public UniqueIdGenerator() {
        this.nodeId = createNodeId();
    }

    public synchronized long generateId() {
        long currentTimestamp = timestamp();

        if (currentTimestamp < lastTimestamp) {
            throw new IllegalStateException("Clock moved backwards. Refusing to generate id.");
        }

        if (currentTimestamp == lastTimestamp) {
            sequence = (sequence + 1) & MAX_SEQUENCE;
            if (sequence == 0) {
                // Sequence overflow, wait for next millisecond
                currentTimestamp = waitNextMillis(currentTimestamp);
            }
        } else {
            sequence = 0;
        }

        lastTimestamp = currentTimestamp;

        return ((currentTimestamp - CUSTOM_EPOCH) << TIMESTAMP_SHIFT) |
               (nodeId << NODE_ID_SHIFT) |
               sequence;
    }

    private long timestamp() {
        return Instant.now().toEpochMilli();
    }

    private long waitNextMillis(long currentTimestamp) {
        long timestamp = timestamp();
        while (timestamp <= currentTimestamp) {
            timestamp = timestamp();
        }
        return timestamp;
    }

    private long createNodeId() {
        long nodeId;
        try {
            // Try to create a unique node ID based on MAC address
            StringBuilder sb = new StringBuilder();
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()) {
                NetworkInterface networkInterface = networkInterfaces.nextElement();
                if (!networkInterface.isLoopback() && networkInterface.getHardwareAddress() != null) {
                    byte[] mac = networkInterface.getHardwareAddress();
                    for (byte macByte : mac) {
                        sb.append(String.format("%02X", macByte));
                    }
                    break;
                }
            }
            
            // If no MAC address found, use a secure random
            if (sb.length() == 0) {
                nodeId = new SecureRandom().nextInt(1 << NODE_ID_BITS);
            } else {
                nodeId = Math.abs(sb.toString().hashCode()) % MAX_NODE_ID;
            }
        } catch (Exception e) {
            // Fallback to secure random if any error occurs
            nodeId = new SecureRandom().nextInt(1 << NODE_ID_BITS);
        }
        
        return nodeId;
    }
}