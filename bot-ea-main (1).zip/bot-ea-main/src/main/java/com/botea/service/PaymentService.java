package com.botea.service;

import com.botea.controller.dto.LicenseManagementDTO;
import com.botea.controller.dto.PaymentRequest;
import com.botea.controller.dto.PaymentStatusDTO;
import com.botea.controller.dto.UserAuthenticationDTO;
import com.botea.dao.entity.BotUser;
import com.botea.dao.entity.License;
import com.botea.dao.entity.LicensePayment;
import com.botea.dao.repository.LicensePaymentRepository;
import com.botea.dao.repository.LicenseRepository;
import com.botea.dao.repository.PromoCodeRepository;
import com.botea.dao.repository.UserRepository;
import com.botea.exception.BotApplicationException;
import com.botea.helper.HouseKeepingHelper;
import com.botea.helper.SecurityHelper;
import com.botea.utils.EmailType;
import com.botea.utils.PaymentStatus;
import com.stripe.model.Event;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
@Slf4j
public class PaymentService {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    PromoCodeRepository promoCodeRepository;

    @Autowired
    LicenseManagementService licenseManagementService;

    @Autowired
    public LicensePaymentRepository licensePaymentRepository;

    @Autowired
    LicenseRepository licenseRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    private PromoCodeService promoCodeService;

    @Autowired
    EmailService emailService;

    public Mono<LicensePayment> getLicenseDetails(String idempotencyKey) {
        return licensePaymentRepository.findByPaymentDetails(createPaymentDetailsJson(idempotencyKey, PaymentStatus.PENDING.name()));

    }

    public Mono<License> findLicenseByKey(String licenseKey) {
        return licenseRepository.findByLicenseKey(licenseKey);
    }

    public String createPaymentDetailsJson(String paymentIntentId, String status) {
        Map<String, String> paymentDetails = new HashMap<>();
        paymentDetails.put("paymentIntentId", paymentIntentId);
        paymentDetails.put("status", status);
        try {
            return objectMapper.writeValueAsString(paymentDetails);
        } catch (JsonProcessingException e) {
            log.error("Error creating payment details JSON", e);
            // Fallback to a simple format in case of JSON processing error
            return "{\"paymentIntentId\":\"" + paymentIntentId + "\",\"status\":\"" + status + "\"}";
        }
    }

    public Mono<PaymentIntent> charge(PaymentRequest paymentRequest) {
        return calculateAmountPostDiscount(paymentRequest)
                .flatMap(discountedAmount -> {
                    PaymentIntentCreateParams params = PaymentIntentCreateParams.builder()
                            .setAmount(discountedAmount)
                            .setCurrency(paymentRequest.getCurrency())
                            .setReceiptEmail(paymentRequest.getEmailID())
                            .putMetadata("promoCode",paymentRequest.getPromoCode())
                            .putMetadata("countryCode",paymentRequest.getCountryCode())
                            .putMetadata("licenseType",paymentRequest.getLicenseType())
                            .putMetadata("totalCredits", String.valueOf(paymentRequest.getAmount()))
                            .putMetadata("idempotencyKey",null)
                            .putMetadata("email",paymentRequest.getEmailID())
                            .putMetadata("isRenewal", String.valueOf(paymentRequest.getIsRenewal()))
                            .putMetadata("licenseCount", String.valueOf(paymentRequest.getLicenseCount()))
                            .build();
                    try {
                        PaymentIntent paymentIntent = PaymentIntent.create(params);
                        
                        // First check if we already have a payment record for this intent
                        return licensePaymentRepository.findByPaymentDetails(
                                createPaymentDetailsJson(paymentIntent.getId(), PaymentStatus.PENDING.name())
                            )
                            .flatMap(existingPayment -> {
                                log.info("Found existing payment record for intent: {}", paymentIntent.getId());
                                return Mono.just(paymentIntent);
                            })
                            .switchIfEmpty(Mono.defer(() -> {
                                // Create a pending payment record with system user as default creator
                                Long systemUserId = 1L; // Default system user ID
                                LicensePayment payment = LicensePayment.builder()
                                    .purchasedOn(Timestamp.valueOf(LocalDateTime.now()))
                                    .paymentMethod("stripe")
                                    .paymentDetails(createPaymentDetailsJson(paymentIntent.getId(), PaymentStatus.PENDING.name()))
                                    .paymentAmount(BigDecimal.valueOf(discountedAmount).divide(BigDecimal.valueOf(100))) // Convert cents to dollars
                                    .paymentCurrencyCode(paymentRequest.getCurrency().toUpperCase())
                                    .created(HouseKeepingHelper.getCreatedOn())
                                    .createdBy(systemUserId)
                                    .updated(HouseKeepingHelper.getUpdatedOn())
                                    .updatedBy(systemUserId)
                                    .build();
                                
                                // Build detailed comments
                                String comments = "Payment initiated via Stripe" +
                                        "\nPayment Intent ID: " + paymentIntent.getId() +
                                        "\nPayment Status: " + paymentIntent.getStatus() +
                                        "\nPurpose: " + (paymentRequest.getIsRenewal() != null && paymentRequest.getIsRenewal() ? "License Renewal" : "New License") +
                                        "\nLicense Count: " + paymentRequest.getLicenseCount() +
                                        "\nMetadata:" +
                                        "\n- Email: " + paymentRequest.getEmailID() +
                                        "\n- License Type: " + paymentIntent.getMetadata().get("licenseType") +
                                        "\n- Country Code: " + paymentIntent.getMetadata().get("countryCode") +
                                        "\n- Total Credits: " + paymentIntent.getMetadata().get("totalCredits") +
                                        "\n- Promo Code: " + paymentIntent.getMetadata().get("promoCode") +
                                        "\n- Idempotency Key: " + paymentIntent.getMetadata().get("idempotencyKey");
                                
                                payment.setComments(comments);
                                
                                // Try to get logged-in user
                                UserAuthenticationDTO loggedInUser = SecurityHelper.getLoggedInUser();
                                if (loggedInUser.botUserId() != null) {
                                    return userRepository.findById(loggedInUser.botUserId())
                                            .doOnNext(user -> {
                                                payment.setPurchasedById(user.getBotUserId());
                                                payment.setCreatedBy(user.getBotUserId());
                                                payment.setUpdatedBy(user.getBotUserId());
                                                payment.setComments(payment.getComments() + "\nInitiated by logged-in user: " + user.getUsername());
                                            })
                                            .then(licensePaymentRepository.save(payment))
                                            .thenReturn(paymentIntent);
                                }
                                
                                // If no logged-in user, try to find by email
                                return userRepository.findByUsername(paymentIntent.getReceiptEmail())
                                        .doOnNext(user -> {
                                            payment.setPurchasedById(user.getBotUserId());
                                            payment.setCreatedBy(user.getBotUserId());
                                            payment.setUpdatedBy(user.getBotUserId());
                                            payment.setComments(payment.getComments() + "\nInitiated by registered user: " + user.getUsername());
                                        })
                                        .defaultIfEmpty(new BotUser()) // Empty user for anonymous case
                                        .flatMap(user -> {
                                            if (user.getBotUserId() == null) {
                                                // Anonymous purchase
                                                payment.setComments(payment.getComments() + "\nInitiated by anonymous user with email: " + paymentIntent.getReceiptEmail());
                                            }
                                            return licensePaymentRepository.save(payment);
                                        })
                                        .thenReturn(paymentIntent);
                            }));
                                
                    } catch (StripeException e) {
                        return Mono.error(new BotApplicationException(e.getMessage()));
                    }
                });
    }

    private Mono<Long> calculateAmountPostDiscount(PaymentRequest paymentRequest) {
        if (paymentRequest.getPromoCode() == null || paymentRequest.getPromoCode().trim().isEmpty()) {
            return Mono.just(paymentRequest.getAmount());
        }

        return promoCodeRepository.findByPromoCodeValue(paymentRequest.getPromoCode())
                .flatMap(promoCode -> {
                    // Check usage limit instead of isUsed flag
                    if (promoCode.getTimesUsed() >= promoCode.getUsageLimit()) {
                        return Mono.error(new BotApplicationException("Promo code has reached its usage limit"));
                    }

                    // Handle expiry check with null safety
                    if (promoCode.getExpiry() != null) {
                        LocalDateTime currentDateTime = LocalDateTime.now();
                        LocalDateTime expiryDateTime = promoCode.getCreated().plusDays(promoCode.getExpiry());

                        if (currentDateTime.isAfter(expiryDateTime)) {
                            return Mono.error(new BotApplicationException("Promo code has expired"));
                        }
                    }

                    double discount = promoCode.getDiscount();
                    double discountAmt = (paymentRequest.getAmount() * discount) / 100;
                    long finalAmount = paymentRequest.getAmount() - (long)discountAmt;

                    // Ensure minimum amount
                    return Mono.just(Math.max(finalAmount, 1L)); // Minimum 1 cent charge
                })
                .switchIfEmpty(Mono.error(new BotApplicationException("Invalid promo code")));
    }


    public Mono<ResponseEntity<Map<String, Object>>> handleEvents(Event event) {
        // Handle the event
        return switch (event.getType()) {
            case "payment_intent.succeeded" -> handlePaymentIntentSucceeded(event);
            case "payment_intent.payment_failed", "payment_intent.canceled" -> {
                PaymentIntent paymentIntent = (PaymentIntent) event.getData().getObject();
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("status", "payment_failed");
                response.put("message", "Payment failed or was canceled");
                response.put("payment_intent_id", paymentIntent.getId());
                yield Mono.just(ResponseEntity.ok().body(response));
            }
            case "payment_intent.processing" -> {
                PaymentIntent paymentIntent = (PaymentIntent) event.getData().getObject();
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("status", "processing");
                response.put("message", "Payment is being processed");
                response.put("payment_intent_id", paymentIntent.getId());
                yield Mono.just(ResponseEntity.ok().body(response));
            }
            case "payment_intent.partially_funded" -> {
                PaymentIntent paymentIntent = (PaymentIntent) event.getData().getObject();
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("status", "partially_funded");
                response.put("message", "Payment is partially funded");
                response.put("payment_intent_id", paymentIntent.getId());
                yield Mono.just(ResponseEntity.ok().body(response));
            }
            case "payment_intent.requires_payment_method", 
                 "payment_intent.requires_confirmation",
                 "payment_intent.requires_action" -> {
                PaymentIntent paymentIntent = (PaymentIntent) event.getData().getObject();
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("status", paymentIntent.getStatus());
                response.put("message", "Payment requires further action: " + paymentIntent.getStatus());
                response.put("payment_intent_id", paymentIntent.getId());
                yield Mono.just(ResponseEntity.ok().body(response));
            }
            default -> {
                log.warn("Unhandled event type: {}", event.getType());
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("status", "unknown");
                response.put("message", "Unhandled event type: " + event.getType());
                yield Mono.just(ResponseEntity.ok().body(response));
            }
        };
    }

    private Mono<ResponseEntity<Map<String, Object>>> handlePaymentIntentSucceeded(Event event) {
        PaymentIntent paymentIntent = (PaymentIntent) event.getData().getObject();
        if (paymentIntent != null) {
            log.info("Processing successful payment intent: {}", paymentIntent.getId());
            
            // Create PaymentStatusDTO directly from the PaymentIntent
            PaymentStatusDTO paymentStatusDTO = new PaymentStatusDTO();
            paymentStatusDTO.setPaymentId(paymentIntent.getId());
            paymentStatusDTO.setStatus(paymentIntent.getStatus());
            paymentStatusDTO.setCountryCode(paymentIntent.getMetadata().get("countryCode"));
            paymentStatusDTO.setEmail(paymentIntent.getMetadata().get("email"));
            paymentStatusDTO.setTotalCredit(new BigDecimal(paymentIntent.getMetadata().get("licenseCount")));
            paymentStatusDTO.setLicenseType(paymentIntent.getMetadata().get("licenseType"));
            paymentStatusDTO.setPromoCode(paymentIntent.getMetadata().get("promoCode"));
            paymentStatusDTO.setIsRenewal(Boolean.valueOf(paymentIntent.getMetadata().get("isRenewal")));
            paymentStatusDTO.setTotalPrice(BigDecimal.valueOf(paymentIntent.getAmount()));
            
            // Process the payment directly
            return updateLicenseInformation(paymentStatusDTO)
                .onErrorResume(e -> {
                    log.error("Error processing successful payment: {}", e.getMessage());
                    Map<String, Object> response = new HashMap<>();
                    response.put("success", false);
                    response.put("status", "error");
                    response.put("message", e.getMessage());
                    response.put("payment_intent_id", paymentIntent.getId());
                    return Mono.just(ResponseEntity.ok().body(response));
                });
        }
        
        log.error("Received null payment intent in success webhook");
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("status", "error");
        response.put("message", "Payment Intent is null");
        return Mono.just(ResponseEntity.ok().body(response));
    }


    private Mono<ResponseEntity<Map<String, Object>>> handlePaymentIntentCancelled(Event event) {
        PaymentIntent paymentIntent = (PaymentIntent) event.getData().getObject();
        if(paymentIntent!=null) {
            return handlePaymentIntentCancelled(paymentIntent.getReceiptEmail(),paymentIntent.getId(), new BigDecimal(paymentIntent.getAmount()));
        }

        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("message", "Payment Intent is null");
        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse));

    }

    private Mono<ResponseEntity<Map<String, Object>>> handlePaymentProcessing(Event event, boolean ispartiallyFunded) {
        PaymentIntent paymentIntent = (PaymentIntent) event.getData().getObject();
        if(paymentIntent!=null) {
            if (ispartiallyFunded) {
                return handlePaymentIntentPartialProcessing(paymentIntent.getReceiptEmail(), paymentIntent.getId(), new BigDecimal(paymentIntent.getAmount()));
            }
            if (!ispartiallyFunded) {
                return handlePaymentIntentProcessing(paymentIntent.getReceiptEmail(), paymentIntent.getId(), new BigDecimal(paymentIntent.getAmount()));
            }
        }

        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("message", "Payment Intent is null");
        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse));

    }




    private String extractLicenseKey(ResponseEntity<?> response) {
        if (response != null && response.getBody() != null) {
            @SuppressWarnings("unchecked")
            Map<String, Object> responseBody = (Map<String, Object>) response.getBody();
            if (responseBody != null && responseBody.containsKey("data")) {
                @SuppressWarnings("unchecked")
                Map<String, String> data = (Map<String, String>) responseBody.get("data");
                if (data != null && data.containsKey("licenseKey")) {
                    return data.get("licenseKey");
                }
            }
        }
        return null;
    }

    private static @NotNull PaymentStatusDTO getPaymentStatusDTO(PaymentIntent paymentIntent, LicensePayment licenseDetails) {
        PaymentStatusDTO paymentStatusDTO = new PaymentStatusDTO();
        paymentStatusDTO.setIsRenewal(false);
        String purpose = extractValue(licenseDetails.getComments(),"Purpose");
        if(purpose.equalsIgnoreCase("License Renewal")){
            paymentStatusDTO.setIsRenewal(true);
        }
        paymentStatusDTO.setPaymentId(paymentIntent.getId());
        paymentStatusDTO.setCountryCode(extractValue(licenseDetails.getComments(),"Country Code"));
        paymentStatusDTO.setTotalCredit(new BigDecimal(extractValue(licenseDetails.getComments(),"License Count")));
        paymentStatusDTO.setLicenseType(extractValue(licenseDetails.getComments(),"License Type"));
        paymentStatusDTO.setPromoCode(extractValue(licenseDetails.getComments(),"Promo Code"));
        paymentStatusDTO.setTotalPrice(new BigDecimal(extractValue(licenseDetails.getComments(),"Total Credits")));
        paymentStatusDTO.setPaidAmount(licenseDetails.getPaymentAmount());
        paymentStatusDTO.setEmail(extractValue(licenseDetails.getComments(),"Email"));
        paymentStatusDTO.setStatus(paymentIntent.getStatus());
        return  paymentStatusDTO;
    }


    private  Mono<ResponseEntity<Map<String, Object>>> handlePaymentIntentProcessing(Event event) {
        PaymentIntent paymentIntent = (PaymentIntent) event.getData().getObject();
        if (paymentIntent != null) {
            log.info("PaymentIntent status: {}", paymentIntent.getStatus());
            return Mono.just(ResponseEntity.ok().body(Map.of("message", "PaymentIntent status: "+  paymentIntent.getStatus())));
        }

        return Mono.just(ResponseEntity.badRequest().body(Map.of("error", "PaymentIntent intent is null ")));

    }

    private Mono<ResponseEntity<Map<String, Object>>> handleSuccessfulPayment(
            PaymentStatusDTO paymentStatusDTO,
            LicenseManagementDTO licenseManagementDTO) {
        
        // First check if this payment was already processed
        return licensePaymentRepository.findByPaymentDetails(
                createPaymentDetailsJson(paymentStatusDTO.getPaymentId(), "COMPLETED")
            )
            .flatMap(existingPayment -> {
                // Payment was already processed, return existing license details
                return licenseRepository.findById(existingPayment.getLicenseId())
                    .map(existingLicense -> {
                        Map<String, Object> response = new HashMap<>();
                        Map<String, Object> data = new HashMap<>();
                        response.put("message", Boolean.TRUE.equals(paymentStatusDTO.getIsRenewal()) 
                            ? "License already renewed" 
                            : "License already created");
                        data.put("licenseKey", existingLicense.getLicenseKey());
                        response.put("data", data);
                        return ResponseEntity.ok().body(response);
                    })
                    .switchIfEmpty(Mono.defer(() -> {
                        Map<String, Object> response = new HashMap<>();
                        response.put("message", "Payment was already processed but license details not found");
                        return Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND).body(response));
                    }));
            })
            .switchIfEmpty(Mono.defer(() -> {
                // Payment not processed yet, try to process it
                Mono<License> licenseMono;
                if (Boolean.TRUE.equals(paymentStatusDTO.getIsRenewal())) {
                    licenseMono = licenseManagementService.renewLicenseOnly(licenseManagementDTO);
                } else {
                    licenseMono = licenseManagementService.generateLicenseOnly(licenseManagementDTO);
                }

                return licenseMono
                    .flatMap(license -> 
                        licensePaymentRepository.atomicUpdateLicenseId(
                            license.getLicenseId(),
                            createPaymentDetailsJson(paymentStatusDTO.getPaymentId(), "COMPLETED"),
                            createPaymentDetailsJson(paymentStatusDTO.getPaymentId(), "PENDING"),
                            HouseKeepingHelper.getUpdatedBy()
                        )
                        .flatMap(updatedPayment -> {
                            if (updatedPayment == null) {
                                // Another request won the race to process this payment
                                // Delete the license we just created as it's now dangling
                                return licenseRepository.deleteById(license.getLicenseId())
                                    .then(Mono.defer(() -> {
                                        Map<String, Object> response = new HashMap<>();
                                        Map<String, Object> data = new HashMap<>();
                                        response.put("message", "Your license will be emailed to you shortly");
                                        response.put("data", data);
                                        return Mono.just(ResponseEntity.ok().body(response));
                                    }));
                            }

                            // Update successful, add comments and send email
                            String updatedComments = updatedPayment.getComments() +
                                    "\n\nPayment Completed Successfully" +
                                    (Boolean.TRUE.equals(paymentStatusDTO.getIsRenewal()) ? " (Renewal)" : "") +
                                    "\nLicense Key: " + license.getLicenseKey() +
                                    "\nFinal Status: " + paymentStatusDTO.getStatus() +
                                    "\nDiscount Applied: " + licenseManagementDTO.getDiscount() +
                                    "\nFinal Amount Paid: " + licenseManagementDTO.getPaidAmount();
                            
                            updatedPayment.setComments(updatedComments);
                            Mono<Void> emailMono = Boolean.TRUE.equals(paymentStatusDTO.getIsRenewal())
                                ? licenseManagementService.sendRenewalEmail(license, licenseManagementDTO)
                                : licenseManagementService.sendLicenseEmail(List.of(license), licenseManagementDTO);

                            return licensePaymentRepository.save(updatedPayment)
                                .then(emailMono)
                                .then(Mono.defer(() -> {
                                    Map<String, Object> response = new HashMap<>();
                                    Map<String, Object> data = new HashMap<>();
                                    response.put("message", Boolean.TRUE.equals(paymentStatusDTO.getIsRenewal())
                                        ? "License renewed successfully"
                                        : "License created successfully");
                                    data.put("licenseKey", license.getLicenseKey());
                                    response.put("data", data);
                                    return Mono.just(ResponseEntity.ok().body(response));
                                }));
                        })
                    )
                    .onErrorResume(e -> {
                        log.error("Error processing payment: {}", e.getMessage());
                        Map<String, Object> errorResponse = new HashMap<>();
                        String operation = Boolean.TRUE.equals(paymentStatusDTO.getIsRenewal()) ? "renew" : "create";
                        errorResponse.put("message", "Failed to " + operation + " license: " + e.getMessage());
                        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                .body(errorResponse));
                    });
            }));
    }

    public Mono<ResponseEntity<Map<String, Object>>> updateLicenseInformation(PaymentStatusDTO paymentStatusDTO) {
        LicenseManagementDTO licenseManagementDTO = new LicenseManagementDTO();
        licenseManagementDTO.setEmail(paymentStatusDTO.getEmail());
        licenseManagementDTO.setTotalCredit(paymentStatusDTO.getTotalCredit());
        licenseManagementDTO.setLicenseType(paymentStatusDTO.getLicenseType());
        licenseManagementDTO.setCountryCode(paymentStatusDTO.getCountryCode());
        licenseManagementDTO.setPromoCode(paymentStatusDTO.getPromoCode());
        licenseManagementDTO.setTotalPrice(paymentStatusDTO.getTotalPrice());

        // Handle promo code if present
        if (paymentStatusDTO.getPromoCode() != null && !paymentStatusDTO.getPromoCode().trim().isEmpty()) {
            // Use PromoCodeService to validate and update promo code usage
            return promoCodeService.validatePromoCode(paymentStatusDTO.getPromoCode())
                    .flatMap(promoCode -> {
                        // Calculate discount amount from percentage
                        BigDecimal discountPercentage = BigDecimal.valueOf(promoCode.getDiscount());
                        BigDecimal discountAmount = paymentStatusDTO.getTotalPrice()
                                .multiply(discountPercentage)
                                .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);

                        licenseManagementDTO.setDiscount(discountAmount);
                        BigDecimal paidAmount = paymentStatusDTO.getTotalPrice().subtract(discountAmount);
                        licenseManagementDTO.setPaidAmount(paidAmount);

                        // Mark promo code as used
                        return promoCodeService.markPromoCodeAsUsed(paymentStatusDTO.getPromoCode(), null)
                                .then(handleSuccessfulPayment(paymentStatusDTO, licenseManagementDTO));
                    })
                    .onErrorResume(e -> {
                        Map<String, Object> errorMap = new HashMap<>();
                        errorMap.put("message", "Error processing promo code: " + e.getMessage());
                        return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                .body(errorMap));
                    });
        } else {
            // No promo code, proceed with full price
            licenseManagementDTO.setDiscount(BigDecimal.ZERO);
            licenseManagementDTO.setPaidAmount(paymentStatusDTO.getTotalPrice());
            return handleSuccessfulPayment(paymentStatusDTO, licenseManagementDTO);
        }
    }


    public Mono<ResponseEntity<Map<String, Object>>> updateLicense(PaymentStatusDTO paymentStatusDTO) {
            paymentStatusDTO.setTotalPrice(paymentStatusDTO.getTotalPrice().divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
            LicenseManagementDTO licenseManagementDTO = new LicenseManagementDTO();
            licenseManagementDTO.setLicenseType(paymentStatusDTO.getLicenseType());
            licenseManagementDTO.setEmail(paymentStatusDTO.getEmail());
            licenseManagementDTO.setCountryCode(paymentStatusDTO.getCountryCode());
            licenseManagementDTO.setTotalCredit(paymentStatusDTO.getTotalCredit());
            licenseManagementDTO.setPromoCode(paymentStatusDTO.getPromoCode());
            licenseManagementDTO.setTotalPrice(paymentStatusDTO.getTotalPrice());
            licenseManagementDTO.setLicenseCost(paymentStatusDTO.getTotalPrice());

            if (paymentStatusDTO.getPromoCode() != null && !paymentStatusDTO.getPromoCode().trim().isEmpty()) {
                // Use PromoCodeService to validate the promo code
                return promoCodeService.validatePromoCode(paymentStatusDTO.getPromoCode())
                        .flatMap(promoCode -> {
                            // Calculate discount amount from percentage
                            BigDecimal discountPercentage = BigDecimal.valueOf(promoCode.getDiscount());
                            BigDecimal discountAmount = paymentStatusDTO.getTotalPrice()
                                    .multiply(discountPercentage)
                                    .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);

                            licenseManagementDTO.setDiscount(discountAmount); // Set actual discount amount
                            BigDecimal paidAmount = paymentStatusDTO.getTotalPrice().subtract(discountAmount);
                            licenseManagementDTO.setPaidAmount(paidAmount);

                            return handleSuccessfulPayment(paymentStatusDTO, licenseManagementDTO);
                        })
                        .onErrorResume(e -> {
                            Map<String, Object> errorMap = new HashMap<>();
                            errorMap.put("message", "The promo code you entered is invalid or has expired. Please check and try again.");
                            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                    .body(errorMap));
                        });
            } else {
                // No promo code, so no discount
                licenseManagementDTO.setDiscount(BigDecimal.ZERO);
                licenseManagementDTO.setPaidAmount(paymentStatusDTO.getTotalPrice());
                return handleSuccessfulPayment(paymentStatusDTO, licenseManagementDTO);
            }
    }

    private Mono<License> findExistingLicense(String paymentId) {
        return licensePaymentRepository.findByPaymentDetails(createPaymentDetailsJson(paymentId, "COMPLETED"))
            .switchIfEmpty(Mono.error(new RuntimeException("Payment record not found")))
            .flatMap(payment -> {
                if (payment.getLicenseId() == null) {
                    return Mono.error(new RuntimeException("Payment found but no license attached"));
                }
                return licenseRepository.findById(payment.getLicenseId())
                    .switchIfEmpty(Mono.error(new RuntimeException("License not found for payment")));
            });
    }

    private static String extractValue(String text, String key) {
        String[] lines = text.split("\\R");
        for (String line : lines) {
            if (line.contains(key + ":")) {
                return line.split(":", 2)[1].trim();
            }
        }
        return null;
    }

    private Mono<ResponseEntity<Map<String, Object>>> handlePaymentIntentCancelled(String email,
                                                                                   String Id,
                                                                                   BigDecimal paidAmount) {
        Map<String, Object> variables = new HashMap<>();
        return getLicenseDetails(Id)
                .flatMap(licensePayment -> {
                    if (licensePayment != null) {
                        variables.put("paymentRef", licensePayment.getLicensePaymentId());
                        variables.put("paymentType", "card");
                        variables.put("paidAmount", paidAmount.divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
                        variables.put("licenseCount", new BigDecimal(Objects.requireNonNull(extractValue(licensePayment.getComments(), "License Count"))));
                        emailService.sendEmail(extractValue(licensePayment.getComments(),"Email"), "Payment Failed Notification", variables, EmailType.PAYMENT_FAILED.getTemplateName())
                                .doOnSuccess(unused -> log.info("Email sent successfully "))
                                .doOnError(error -> log.error("Failed to send email: " + error.getMessage())).subscribe();
                        Map<String, Object> responseMap = new HashMap<>();
                        responseMap.put("message", "Payment has failed for your license. Kindly check email for details");
                        return Mono.just(ResponseEntity.status(HttpStatus.PAYMENT_REQUIRED).body(responseMap));
                    } else {
                        variables.put("paymentRef", "Failed to generate Payment Reference");
                        variables.put("paymentType", "card");
                        variables.put("paidAmount", paidAmount.divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
                        variables.put("licenseCount", null);
                        emailService.sendEmail(email, "Payment Failed Notification", variables, EmailType.PAYMENT_FAILED.getTemplateName())
                                .doOnSuccess(unused -> log.info("Email sent successfully "))
                                .doOnError(error ->log.error("Failed to send email: " + error.getMessage())).subscribe();
                        Map<String, Object> responseMap = new HashMap<>();
                        responseMap.put("message", "Payment has failed for your license. Failed to generate Payment Reference.");
                        return Mono.just(ResponseEntity.status(HttpStatus.PAYMENT_REQUIRED).body(responseMap));
                    }
                })
                .onErrorResume(e -> {
                    Map<String, Object> errorMap = new HashMap<>();
                    errorMap.put("message", "An error occurred while processing your request. Please try again later.");
                    return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMap));
                });
    }

    private Mono<ResponseEntity<Map<String, Object>>> handlePaymentIntentProcessing(String email,
                                                                                   String Id,
                                                                                   BigDecimal paidAmount) {
        Map<String, Object> variables = new HashMap<>();
        return getLicenseDetails(Id)
                .flatMap(licensePayment -> {
                    if (licensePayment != null) {
                        variables.put("paymentRef", licensePayment.getLicensePaymentId());
                        variables.put("paymentType", "card");
                        variables.put("paidAmount", paidAmount.divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
                        variables.put("partial",false);
                        variables.put("licenseCount", new BigDecimal(Objects.requireNonNull(extractValue(licensePayment.getComments(), "License Count"))));
                        emailService.sendEmail(extractValue(licensePayment.getComments(),"Email"), "Payment Processing Notification", variables, EmailType.PAYMENT_PROCESSING.getTemplateName())
                                .doOnSuccess(unused -> log.info("Email sent successfully "))
                                .doOnError(error ->log.error("Failed to send email: " + error.getMessage())).subscribe();

                        Map<String, Object> responseMap = new HashMap<>();
                        responseMap.put("message", "Payment is in processing for your license. Will notify once completed ");
                        return Mono.just(ResponseEntity.ok().body(responseMap));
                    } else {
                        variables.put("paymentRef", "Failed to generated!!!");
                        variables.put("paymentType", "card");
                        variables.put("paidAmount", paidAmount.divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
                        variables.put("licenseCount", null);
                        variables.put("partial",false);
                        emailService.sendEmail(email, "Payment Processing Notification", variables, EmailType.PAYMENT_PROCESSING.getTemplateName())
                                .doOnSuccess(unused -> log.info("Email sent successfully "))
                                .doOnError(error ->log.error("Failed to send email: " + error.getMessage())).subscribe();

                        Map<String, Object> responseMap = new HashMap<>();
                        responseMap.put("message", "Payment processing in progress. Payment Reference not found.");
                        return Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMap));
                    }
                })
                .onErrorResume(e -> {
                    Map<String, Object> errorMap = new HashMap<>();
                    errorMap.put("message", "An error occurred while processing your request. Please try again later.");
                    return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMap));
                });
    }

    private Mono<ResponseEntity<Map<String, Object>>> handlePaymentIntentPartialProcessing(String email,
                                                                                    String Id,
                                                                                    BigDecimal paidAmount) {
        Map<String, Object> variables = new HashMap<>();
        return getLicenseDetails(Id)
                .flatMap(licensePayment -> {
                    if (licensePayment != null) {
                        variables.put("paymentRef", licensePayment.getLicensePaymentId());
                        variables.put("paymentType", "card");
                        variables.put("paidAmount", paidAmount.divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
                        variables.put("partial",true);
                        variables.put("licenseCount",  new BigDecimal(Objects.requireNonNull(extractValue(licensePayment.getComments(), "License Count"))));
                        emailService.sendEmail(extractValue(licensePayment.getComments(),"Email"), "Payment Processing Notification", variables, EmailType.PAYMENT_PROCESSING.getTemplateName())
                                .doOnSuccess(unused -> log.info("Email sent successfully "))
                                .doOnError(error ->log.error("Failed to send email: " + error.getMessage())).subscribe();

                        Map<String, Object> responseMap = new HashMap<>();
                        responseMap.put("message", "Payment is partially complete for your license. Kindly complete the payment. ");
                        return Mono.just(ResponseEntity.ok().body(responseMap));
                    } else {
                        variables.put("paymentRef", "Failed to generate. Kindly retry!!!");
                        variables.put("paymentType", "card");
                        variables.put("paidAmount", paidAmount.divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
                        variables.put("licenseCount", null);
                        variables.put("true",false);
                        emailService.sendEmail(email, "Payment Processing Notification", variables, EmailType.PAYMENT_PROCESSING.getTemplateName())
                                .doOnSuccess(unused -> log.info("Email sent successfully "))
                                .doOnError(error ->log.error("Failed to send email: " + error.getMessage())).subscribe();

                        Map<String, Object> responseMap = new HashMap<>();
                        responseMap.put("message", "Payment is not complete. Payment Reference not found.");
                        return Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMap));
                    }
                })
                .onErrorResume(e -> {
                    Map<String, Object> errorMap = new HashMap<>();
                    errorMap.put("message", "An error occurred while processing your request. Please try again later.");
                    return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMap));
                });
    }

}
