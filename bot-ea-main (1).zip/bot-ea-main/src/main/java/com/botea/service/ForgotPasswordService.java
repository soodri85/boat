package com.botea.service;

import com.botea.controller.dto.PasswordResetRequest;
import com.botea.dao.repository.UserRepository;
import com.botea.exception.BotApplicationException;
import com.botea.helper.SecurityHelper;
import com.botea.utils.EmailType;
import com.botea.utils.JwtTokenUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

@Service
public class ForgotPasswordService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmailOTPService emailOTPService;


    public ForgotPasswordService(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtTokenUtil jwtTokenUtil, TokenService tokenService, EmailOTPService emailOTPService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.emailOTPService = emailOTPService;
    }

    public Mono<ResponseEntity<Map<String,String>>> processForgotPassword(String email) {

        return userRepository.findByUsername(email)
                .switchIfEmpty(Mono.error(new BotApplicationException("User not found")))
                .flatMap(user -> {
                    return  emailOTPService.sendOTPAndVerifyUser(email, EmailType.FORGOT_PASSWORD.getDisplayName(),"Account Verification for Bot-EA" ,EmailType.FORGOT_PASSWORD)
                            .flatMap(response -> {
                                if ("Success".equals(response)) {
                                    Map<String, String> map = new HashMap<>();
                                    map.put("otp_type", EmailType.FORGOT_PASSWORD.getOtpType());
                                    map.put("otp_type_display", EmailType.FORGOT_PASSWORD.getDisplayName());
                                    map.put("message", "OTP sent on the email");
                                    return Mono.just(ResponseEntity.ok(map));
                                } else {
                                    Map<String, String>  map = new HashMap<>();
                                    map.put("message", "Unable to send otp on email");
                                    return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                            .body(map));
                                }
                            })
                            .onErrorResume(e ->  {
                                Map<String, String>  map = new HashMap<>();
                                map.put("message", "An error occurred while sending otp");
                                return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                    .body(map));});
                });
    }

    public Mono<ResponseEntity<String>> resetPassword(PasswordResetRequest passwordResetRequest) {
        return userRepository.findByUsername(SecurityHelper.getLoggedInUser().username())
                .switchIfEmpty(Mono.error(new BotApplicationException("Invalid or expired token")))
                .flatMap(user -> {
                    if (!passwordEncoder.matches(passwordResetRequest.getOldPassword(), user.getPassword())) {
                        return Mono.error(new BotApplicationException("Old password is incorrect"));
                    }
                    if (!passwordResetRequest.getNewPassword().equals(passwordResetRequest.getConfirmPassword())) {
                        return Mono.error(new BotApplicationException("New password and confirm password do not match"));
                    }
                    // Encode the password before saving
                    String encodedPassword = passwordEncoder.encode(passwordResetRequest.getNewPassword());
                    user.setPassword(encodedPassword); // Encrypt the password before saving.
                    return userRepository.save(user).thenReturn(user).thenReturn(ResponseEntity.ok("Password reset successful."));
                });


    }

    public Mono<ResponseEntity<String>> updateNewPassword(String token, String newPassword, String confirmPassword) {
        return userRepository.findByUsername(token)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("Invalid user")))
                .flatMap(user -> {
                    // Encode the password before saving
                    if (!confirmPassword.equals(newPassword)) {
                        return Mono.error(new BotApplicationException("New password and confirm password do not match"));
                    }
                    String encodedPassword = passwordEncoder.encode(newPassword);
                    user.setPassword(encodedPassword); // Encrypt the password before saving.
                    return userRepository.save(user).thenReturn(user).thenReturn(ResponseEntity.ok("Password reset successful."));

                });


    }



}
