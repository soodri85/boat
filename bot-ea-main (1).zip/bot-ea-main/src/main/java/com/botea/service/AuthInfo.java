package com.botea.service;

import com.botea.controller.dto.UserAuthenticationDTO;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

@Component
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class AuthInfo {

    // Get logged in user info from the security context - need to change to reactive context
    public UserAuthenticationDTO getLoggedInUserInfoBlocking() {
        return (UserAuthenticationDTO) authentication().getPrincipal();
    }

    // Get authentication from the security context
    public Authentication authentication() {
        return SecurityContextHolder.getContext().getAuthentication();

    }

}