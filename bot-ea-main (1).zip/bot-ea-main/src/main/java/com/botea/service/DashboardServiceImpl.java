package com.botea.service;

import com.botea.controller.dto.DashboardStatistics;
import com.botea.controller.dto.DashboardStatistics.MonthlyFormCounts;
import lombok.RequiredArgsConstructor;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class DashboardServiceImpl implements DashboardService {
    
    private final DatabaseClient databaseClient;

    @Override
    public Mono<DashboardStatistics.BasicStats> getBasicStats() {
        return Mono.zip(
            getRevenueStatistics(),
            getSubscriptionStatistics(),
            getActiveUserStatistics()
        ).map(tuple -> DashboardStatistics.BasicStats.builder()
                .totalRevenue(tuple.getT1())
                .totalSubscriptions(tuple.getT2())
                .activeUsers(tuple.getT3())
                .build());
    }

    @Override
    public Mono<DashboardStatistics.RevenueStats> getRevenueStats() {
        return Mono.zip(
            getRevenueStatistics(),
            getSubscriptionStatistics()
        ).map(tuple -> DashboardStatistics.RevenueStats.builder()
                .totalRevenue(tuple.getT1())
                .totalSubscriptions(tuple.getT2())
                .build());
    }

    @Override
    public Mono<DashboardStatistics.ActiveUserStats> getActiveUserStats() {
        return getActiveUserStatistics()
            .map(activeUsers -> DashboardStatistics.ActiveUserStats.builder()
                .activeUsers(activeUsers)
                .daysWindow(30)
                .build());
    }

    @Override
    public Mono<DashboardStatistics.TransactionStats> getTransactionStats(Integer year) {
        return getTransactionStatistics(year)
            .map(monthlyTransactions -> DashboardStatistics.TransactionStats.builder()
                .year(year)
                .monthlyTransactions(monthlyTransactions)
                .build());
    }

    @Override
    public Mono<DashboardStatistics.UserStats> getUserRegistrationStats(Integer year) {
        return getUserStatistics(year)
            .map(monthlyRegistrations -> DashboardStatistics.UserStats.builder()
                .year(year)
                .monthlyRegistrations(monthlyRegistrations)
                .build());
    }

    @Override
    public Mono<DashboardStatistics.SubscriptionStats> getSubscriptionStats(Integer year) {
        return getMonthlySubscriptionStatistics(year)
            .map(monthlySubscriptions -> DashboardStatistics.SubscriptionStats.builder()
                .year(year)
                .monthlySubscriptions(monthlySubscriptions)
                .build());
    }

    private Mono<Double> getRevenueStatistics() {
        return databaseClient.sql("SELECT * FROM get_revenue_statistics()")
                .map(row -> row.get("total_revenue", Double.class))
                .one();
    }

    private Mono<Integer> getSubscriptionStatistics() {
        return databaseClient.sql("SELECT * FROM get_subscription_statistics()")
                .map(row -> row.get("total_subscriptions", Integer.class))
                .one();
    }

    private Mono<Integer> getActiveUserStatistics() {
        return databaseClient.sql("SELECT * FROM get_active_user_statistics(:days)")
                .bind("days", 30)
                .map(row -> row.get("active_users", Integer.class))
                .one();
    }

    private Mono<MonthlyFormCounts[]> getTransactionStatistics(Integer year) {
        return databaseClient.sql("""
                SELECT 
                    EXTRACT(MONTH FROM td.created) as month, 
                    d.document_name as form_type,
                    COUNT(*) as form_count
                FROM transaction_data td
                LEFT JOIN document d ON td.document_id = d.document_id
                WHERE EXTRACT(YEAR FROM td.created) = :year 
                GROUP BY EXTRACT(MONTH FROM td.created), d.document_name 
                ORDER BY EXTRACT(MONTH FROM td.created)""")
                .bind("year", year)
                .map(row -> {
                    int month = row.get("month", Integer.class);
                    String formType = row.get("form_type", String.class);
                    int count = row.get("form_count", Integer.class);
                    return new Object[]{month - 1, formType, count}; // month - 1 for 0-based array index
                })
                .all()
                .collectList()
                .map(list -> {
                    MonthlyFormCounts[] monthlyTransactions = new MonthlyFormCounts[12];
                    
                    // Initialize all months with zero counts
                    for (int i = 0; i < 12; i++) {
                        monthlyTransactions[i] = MonthlyFormCounts.builder()
                            .scheduleC(0)
                            .scheduleE(0)
                            .t776(0)
                            .t2125(0)
                            .build();
                    }
                    
                    // Fill in the actual counts
                    for (Object[] entry : list) {
                        int month = (int) entry[0];
                        String formType = (String) entry[1];
                        int count = (int) entry[2];
                        
                        MonthlyFormCounts currentCounts = monthlyTransactions[month];
                        MonthlyFormCounts.MonthlyFormCountsBuilder updatedCounts = 
                            MonthlyFormCounts.builder()
                                .scheduleC(currentCounts.getScheduleC())
                                .scheduleE(currentCounts.getScheduleE())
                                .t776(currentCounts.getT776())
                                .t2125(currentCounts.getT2125());
                        
                        if (formType != null) {
                            switch (formType.toUpperCase()) {
                                case "SCHEDULE C" -> updatedCounts.scheduleC(count);
                                case "SCHEDULE E" -> updatedCounts.scheduleE(count);
                                case "T776" -> updatedCounts.t776(count);
                                case "T2125" -> updatedCounts.t2125(count);
                            }
                        }
                        
                        monthlyTransactions[month] = updatedCounts.build();
                    }
                    
                    return monthlyTransactions;
                });
    }

    private Mono<Integer[]> getUserStatistics(Integer year) {
        return databaseClient.sql("SELECT month, new_users_this_month FROM get_user_statistics(:year) ORDER BY month")
                .bind("year", year)
                .map(row -> {
                    int month = row.get("month", Integer.class);
                    int newUsers = row.get("new_users_this_month", Integer.class);
                    return new Object[]{month - 1, newUsers}; // month - 1 for 0-based array index
                })
                .all()
                .collectList()
                .map(list -> {
                    Integer[] monthlyRegistrations = new Integer[12];
                    // Initialize all months with zero
                    for (int i = 0; i < 12; i++) {
                        monthlyRegistrations[i] = 0;
                    }
                    
                    // Fill in the actual counts
                    for (Object[] entry : list) {
                        int month = (int) entry[0];
                        int users = (int) entry[1];
                        monthlyRegistrations[month] = users;
                    }
                    
                    return monthlyRegistrations;
                });
    }

    private Mono<Integer[]> getMonthlySubscriptionStatistics(Integer year) {
        return databaseClient.sql("""
                SELECT 
                    EXTRACT(MONTH FROM purchased_on) as month, 
                    COUNT(*) as subscription_count
                FROM license_payment 
                WHERE EXTRACT(YEAR FROM purchased_on) = :year 
                GROUP BY EXTRACT(MONTH FROM purchased_on)
                ORDER BY month""")
                .bind("year", year)
                .map(row -> {
                    int month = row.get("month", Integer.class);
                    int count = row.get("subscription_count", Integer.class);
                    return new Object[]{month - 1, count}; // month - 1 for 0-based array index
                })
                .all()
                .collectList()
                .map(list -> {
                    Integer[] monthlySubscriptions = new Integer[12];
                    // Initialize all months with zero
                    for (int i = 0; i < 12; i++) {
                        monthlySubscriptions[i] = 0;
                    }
                    
                    // Fill in the actual counts
                    for (Object[] entry : list) {
                        int month = (int) entry[0];
                        int count = (int) entry[1];
                        monthlySubscriptions[month] = count;
                    }
                    
                    return monthlySubscriptions;
                });
    }
} 