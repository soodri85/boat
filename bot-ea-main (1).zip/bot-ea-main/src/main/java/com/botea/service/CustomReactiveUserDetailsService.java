package com.botea.service;// Reactive User Details Service

import com.botea.dao.entity.BotUser;
import com.botea.dao.repository.UserRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class CustomReactiveUserDetailsService implements BotCustomReactiveUserDetailsService {
    private final UserRepository userRepository;

    public CustomReactiveUserDetailsService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public Mono<UserDetails> findByUsername(String username) {
        return userRepository.findByUsername(username)
            .map(user -> org.springframework.security.core.userdetails.User
                .withUsername(user.getUsername())
                .password(user.getPassword())
                .authorities("ROLE_USER")
                .build()
            );
    }

    @Override
    public Mono<BotUser> findUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public Mono<BotUser> findUserByToken(String token) {
        return userRepository.findUserByToken(token);
    }
}