package com.botea.service;

import com.botea.dao.entity.Audit;
import com.botea.dao.entity.BotUser;
import com.botea.dao.repository.AuditRepository;
import com.botea.dao.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.sql.Timestamp;
import java.time.Instant;

@Service
@RequiredArgsConstructor
public class AuditService {

    private final AuditRepository auditRepository;
    private final UserRepository userRepository;

    /**
     * Logs an audit action, fetching the user ID from the database based on email.
     *
     * @param action   The action being logged.
     * @param data     Additional data related to the action.
     * @param comments Comments describing the action.
     * @param email    The email of the user performing the action.
     * @return A Mono that completes when the audit record is saved.
     */
    public Mono<Void> logAudit(String action, String data, String comments, String email) {
        return userRepository.findByUsername(email) // Find the user by email
                .map(BotUser::getBotUserId)         // Extract the user ID
                .defaultIfEmpty(-1L)               // Default to -1 if user not found
                .flatMap(userId -> {
                    Audit audit = Audit.builder()
                            .action(action)
                            .data(data)
                            .comments(comments)
                            .created(Timestamp.from(Instant.now()))
                            .createdBy(userId) // Use the resolved user ID
                            .build();

                    return auditRepository.save(audit).then();
                });
    }
}
