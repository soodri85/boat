package com.botea.service;

public interface PaymentGatewayService {

}
