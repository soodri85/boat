package com.botea.service;

import com.botea.dao.entity.PromoCode;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface PromoCodeService {
    Mono<PromoCode> generatePromoCode(Double discount, String email, Integer expiry);
    Flux<PromoCode> generateBulkPromoCodes(Double discount, String email, Integer expiry, Integer count, Integer usageLimit, String comment);
    Mono<PromoCode> validatePromoCode(String promoCodeValue);
    Flux<PromoCode> getAllPromoCodes();
    Mono<PromoCode> markPromoCodeAsUsed(String promoCodeValue, String licenseKey);
    Mono<Boolean> resendPromoCodeEmail(String promoCodeValue, String email);
} 