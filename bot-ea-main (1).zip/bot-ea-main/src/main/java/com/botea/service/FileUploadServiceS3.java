package com.botea.service;

import com.botea.controller.dto.FileUploadResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class FileUploadServiceS3 {
    //private final AmazonS3 s3Client;
    //private final Map<String, String> awsCredentials;

    //@Value("${aws.s3.bucket}")
    private String bucketName = "botBucket";

    public FileUploadResponse uploadFile(MultipartFile multipartFile) throws IOException {
//        File file = convertMultiPartToFile(multipartFile);
//        String fileName = generateFileName(multipartFile);
//
//        // Upload file to S3
//        s3Client.putObject(new PutObjectRequest(bucketName, fileName, file)
//            .withCannedAcl(CannedAccessControlList.PublicRead));
//
//        // Get file URL
//        String fileUrl = s3Client.getUrl(bucketName, fileName).toString();
//
//        // Clean up local file
//        file.delete();
//
//        return new FileUploadResponse(
//            fileName,
//            fileUrl,
//            multipartFile.getSize()
//        );
        //return new FileUploadResponse(true, "https://s3.amazonaws.com/" + bucketName + "/" + multipartFile.getOriginalFilename(), null);
        return null;
    }

    private File convertMultiPartToFile(MultipartFile file) throws IOException {
        File convFile = new File(System.getProperty("java.io.tmpdir") + "/" +
                UUID.randomUUID() + file.getOriginalFilename());
        FileOutputStream fos = new FileOutputStream(convFile);
        fos.write(file.getBytes());
        fos.close();
        return convFile;
    }

    private String generateFileName(MultipartFile multipartFile) {
        return UUID.randomUUID() + "_" + multipartFile.getOriginalFilename();
    }
}