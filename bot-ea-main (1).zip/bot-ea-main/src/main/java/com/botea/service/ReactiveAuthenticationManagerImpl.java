////package com.botea.service;
//
//import org.springframework.security.authentication.ReactiveAuthenticationManager;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.userdetails.User;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import reactor.core.publisher.Mono;
//
//import java.util.HashMap;
//import java.util.Map;
//
//public class ReactiveAuthenticationManagerImpl implements ReactiveAuthenticationManager {
//
//    private final Map<String, UserDetails> users = new HashMap<>();
//    private final PasswordEncoder passwordEncoder;
//
//    // Constructor with dependency injection
//    public ReactiveAuthenticationManagerImpl(PasswordEncoder passwordEncoder) {
//        this.passwordEncoder = passwordEncoder;
//
//        // Populate in-memory users for demonstration
//        users.put("user", User.withUsername("user")
//                .password(passwordEncoder.encode("password"))
//                .roles("USER")
//                .build());
//        users.put("admin", User.withUsername("admin")
//                .password(passwordEncoder.encode("adminpass"))
//                .roles("ADMIN", "USER")
//                .build());
//    }
//
//    @Override
//    public Mono<Authentication> authenticate(Authentication authentication) {
//        String username = authentication.getName();
//        String password = authentication.getCredentials().toString();
//
//        return Mono.justOrEmpty(users.get(username))
//                .flatMap(userDetails -> {
//                    if (passwordEncoder.matches(password, userDetails.getPassword())) {
//                        // If authentication successful, create a new Authentication object
//                        UsernamePasswordAuthenticationToken authenticated = new UsernamePasswordAuthenticationToken(
//                                userDetails.getUsername(),
//                                null,
//                                userDetails.getAuthorities());
//                        authenticated.setDetails(authentication.getDetails());
//                        return Mono.just(authenticated);
//                    } else {
//                        return Mono.error(new IllegalArgumentException("Invalid credentials"));
//                    }
//                })
//                .switchIfEmpty(Mono.error(new IllegalArgumentException("User not found")))
//                .map(auth -> (Authentication) auth); // Explicitly cast to Authentication
//    }
//}