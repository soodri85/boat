package com.botea.service;

import com.botea.dao.entity.Token;
import com.botea.dao.repository.TokenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Service
public class TokenService {

    @Autowired
    private TokenRepository repository;

    public Flux<Token> findTokensByUser(Long user_id) {
        return repository.findByBotUserId(user_id);
    }

    public Mono<Token> save(Token token) {
        return repository.save(token);
    }

    // Find a specific token by its token string
    public Mono<Token> findByToken(String token) {
        return repository.findByToken(token);
    }

    // Check if a specific token is valid in the database and return true/false based on its is_active status
    public Mono<Boolean> isTokenValidInDatabase(String token) {
        return repository.findByToken(token)
                .flatMap(savedToken -> savedToken.getIsActive() ? Mono.just(true) : Mono.just(false)) // Return true if active, false if not
                .defaultIfEmpty(false); // In case no token is found, return false
    }

    public Mono<Integer> markTokenAsLoggedOut(String token) {
        LocalDateTime now = LocalDateTime.now();
        return repository.markTokenAsLoggedOut(token, now, now);
    }

    public Mono<Void> deactivatePreviousTokens(Long userId) {
        return repository.findByBotUserId(userId)
                .flatMap(token -> {
                    token.setUpdated(LocalDateTime.now());
                    token.setIsActive(false);
                    token.setIsLoggedOut(true);


                    // Add more detailed logging
                    System.out.println("Token before save: " + token);
                    System.out.println("Is_active set to: " + token.getIsActive());

                    // Explicitly use an update method instead of save
                    return repository.updateTokenActiveStatus(
                            token.getTokenId(),
                            false,
                            LocalDateTime.now()
                    );
                })
                .then()
                .onErrorResume(error -> {
                    System.err.println("Error in deactivatePreviousTokens: " + error.getMessage());
                    return Mono.empty();
                });
    }

    public Mono<ResponseEntity<Map<String, String>>> refreshToken(Token token, Long userId, String newAccessToken, String newRefreshToken) {
        // Save the new token
        Mono<Map<String, String>> saveTokenOperation = this.save(token)
                .map(savedToken -> {
                    Map<String, String> response = new HashMap<>();
                    response.put("token", newAccessToken);
                    response.put("refresh_token", newRefreshToken);
                    return response; // Return the saved token response
                })
                .onErrorResume(error -> {
                    // Handle error during token save
                    Map<String, String> errorResponse = new HashMap<>();
                    errorResponse.put("error", "Failed to save token: " + error.getMessage());
                    return Mono.just(errorResponse); // Return error response map
                });

        // Deactivate previous tokens and chain the save operation
        return this.deactivatePreviousTokens(userId)
                .then(saveTokenOperation) // Continue with the saveTokenOperation after deactivation
                .map(responseMap -> {
                    if (responseMap.containsKey("error")) {
                        // Return error response if saveTokenOperation failed
                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseMap);
                    }
                    // Return success response
                    return ResponseEntity.ok(responseMap);
                })
                .onErrorResume(error -> {
                    // Handle error during deactivation
                    Map<String, String> errorResponse = new HashMap<>();
                    errorResponse.put("error", "Failed to deactivate previous tokens: " + error.getMessage());
                    return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse));
                });
    }


}
