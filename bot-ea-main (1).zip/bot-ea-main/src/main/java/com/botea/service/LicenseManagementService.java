package com.botea.service;

import org.springframework.http.ResponseEntity;

import com.botea.controller.dto.LicenseManagementDTO;
import com.botea.dao.entity.License;

import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

public interface LicenseManagementService {
	public Mono<ResponseEntity<Map<String, Object>>> generateLicense(LicenseManagementDTO licenseManagementDTO);

	public Mono<License> generateLicenseOnly(LicenseManagementDTO licenseManagementDTO);

	public Mono<Void> sendLicenseEmail(List<License> licenses, LicenseManagementDTO licenseManagementDTO);

	public Mono<ResponseEntity<String>> registerLicense(LicenseManagementDTO licenseManagementDTO);

	public Mono<ResponseEntity<Map<String, Object>>> renewLicense(LicenseManagementDTO licenseManagementDTO);

	public Mono<License> renewLicenseOnly(LicenseManagementDTO licenseManagementDTO);

	public Mono<Void> sendRenewalEmail(License license, LicenseManagementDTO licenseManagementDTO);

	public Mono<ResponseEntity<String>> consumeLicenseCredit(LicenseManagementDTO licenseManagementDTO);

	public Mono<ResponseEntity<Map<String, Object>>> fetchLicenseInfo(Long userProfileId, String status);

	public Mono<Boolean> resendLicenseEmail(String licenseKey, String email);

	public Mono<ResponseEntity<String>> consumeLicenseCredit(Long userProfileId);
}
