package com.botea.service;

import com.botea.controller.dto.UserAuthenticationDTO;
import com.botea.controller.dto.UserProfileCountryDTO;
import com.botea.dao.entity.UserProfile;
import com.botea.dao.repository.UserProfileRepository;
import java.util.List;

import com.botea.exception.BotApplicationException;
import com.botea.helper.SecurityHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;



@Service
public class UserProfileService {

    private final UserProfileRepository userProfileRepository;

    @Autowired
    public UserProfileService(UserProfileRepository userProfileRepository) {
        this.userProfileRepository = userProfileRepository;
    }

    // Method to retrieve UserProfiles by botUserId
    public Flux<UserProfile> getUserProfilesByBotUserId(Long botUserId) {
        return userProfileRepository.findByBotUserId(botUserId);
    }

    // Create or update a UserProfile
    public Mono<UserProfile> createOrUpdateUserProfile(UserProfile userProfile) {
        return userProfileRepository.save(userProfile);
    }

    // Retrieve a UserProfile by ID
    public Mono<UserProfile> getUserProfileById(Long id) {
        return userProfileRepository.findById(id);
    }

    // Retrieve all UserProfiles
    public Flux<UserProfile> getAllUserProfiles() {
        return userProfileRepository.findAll();
    }

    // Delete a UserProfile by ID
    public Mono<Void> deleteUserProfileById(Long id) {
        return userProfileRepository.deleteById(id);
    }

    public Flux<UserProfileCountryDTO> getUserProfilesWithCountryAndLicenseInfo(Long botUserId) {
        return userProfileRepository.findUserProfilesWithCountryAndLicenseInfo(botUserId);
    }

    public Mono<List<UserProfileCountryDTO>> updateUserProfile(Long userProfileId, Boolean isDefault) {
        return userProfileRepository.findUserProfileById(userProfileId)
                .flatMap(existingUserProfile -> {
                    Long botUserId = existingUserProfile.getBotUserId();
                    if (isDefault) {
                        return userProfileRepository.findByBotUserId(botUserId)
                                .flatMap(userProfile -> {
                                    if (!userProfile.getUserProfileId().equals(userProfileId) && userProfile.getIsDefault()) {
                                        userProfile.setIsDefault(false);
                                        return userProfileRepository.updateUserProfile(userProfile.getUserProfileId(), userProfile.getIsDefault());
                                    }
                                    else if (userProfile.getUserProfileId().equals(userProfileId)) {
                                        userProfile.setIsDefault(true);
                                        return userProfileRepository.updateUserProfile(userProfile.getUserProfileId(), userProfile.getIsDefault());
                                    }
                                    else {
                                        return Mono.just(userProfile);
                                    }
                                })
                                .then(Mono.defer(() -> getUserProfilesWithCountryAndLicenseInfo(botUserId).collectList()));

                    }else {
                        return userProfileRepository.findByBotUserId(botUserId)
                                .filter(userProfile -> !userProfile.getUserProfileId().equals(userProfileId) && userProfile.getIsDefault())
                                .collectList()
                                .flatMap(defaultProfiles -> {
                                    if (defaultProfiles.isEmpty())
                                    {
                                        return Mono.error(new BotApplicationException("Cannot set isDefault to false. No other profiles with isDefault=true found for the same bot_user_id."));
                                    }
                                    else {
                                        return userProfileRepository.updateUserProfile(userProfileId, isDefault)
                                                .then(Mono.defer(() -> getUserProfilesWithCountryAndLicenseInfo(botUserId).collectList()));
                                    }
                                });
                    }

                });

    }

    public Mono<List<UserProfileCountryDTO>> addCountryProfileToUser(Long userProfileId, Long countryProfileId) {
        UserAuthenticationDTO user = SecurityHelper.getLoggedInUser();
        return userProfileRepository.findUserProfileById(userProfileId)
                .flatMap(existingUserProfile -> {
                    Long botUserId = existingUserProfile.getBotUserId();
                    if (user == null || !user.botUserId().equals(botUserId)) {
                        return Mono.error(new BotApplicationException("Unauthorized"));
                    }
                    return userProfileRepository.findUserProfileByBotAndCountryId(botUserId, countryProfileId)
                            .switchIfEmpty( Mono.defer(() -> {
                                UserProfile userProfile = UserProfile.builder()
                                        .botUserId(botUserId)
                                        .countryProfileId(countryProfileId)
                                        .isDefault(false)
                                        .build();
                                return userProfileRepository.save(userProfile);
                            }))
                            .then(getUserProfilesWithCountryAndLicenseInfo(botUserId).collectList());
                });
    }
}
