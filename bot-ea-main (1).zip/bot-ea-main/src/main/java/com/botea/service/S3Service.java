package com.botea.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import software.amazon.awssdk.core.async.AsyncRequestBody;
import software.amazon.awssdk.core.async.AsyncResponseTransformer;
import software.amazon.awssdk.services.s3.S3AsyncClient;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class S3Service {

    private final S3AsyncClient s3AsyncClient;

    @Value("${aws.s3.bucket}")
    private String bucketName;

    private static final DefaultDataBufferFactory BUFFER_FACTORY = new DefaultDataBufferFactory();


    public Mono<String> uploadFile(FilePart[] fileParts) {
        // This method is called when uploading multiple files
        // Since we're zipping the files before upload, we only need to handle one zip file
        String key = UUID.randomUUID() + "-batch.zip";
        return Mono.just(key);
    }

    public Mono<String> uploadFile(byte[] content) {
        String fileName = "batch-" + LocalDateTime.now().toEpochSecond(java.time.ZoneOffset.systemDefault().getRules().getOffset(LocalDateTime.now())) + ".zip";

        String key = UUID.randomUUID() + "-" + fileName;

        try {
            // Create the S3 put object request
            PutObjectRequest objectRequest = PutObjectRequest.builder()
                    .bucket(bucketName)
                    .key(key)
                    .contentType(determineContentType(fileName))
                    .build();

            // Upload to S3 using the async client
            return Mono.fromFuture(
                            s3AsyncClient.putObject(objectRequest, AsyncRequestBody.fromBytes(content))
                    ).thenReturn(key)
                    .doOnSuccess(k -> log.info("Successfully uploaded file: {}", k))
                    .doOnError(e -> log.error("Error uploading file: {}", e.getMessage()));

        } catch (Exception e) {
            log.error("Error processing file for upload: {}", e.getMessage());
            return Mono.error(e);
        }
    }

    public Mono<Flux<DataBuffer>> downloadFile(String filename) {
        GetObjectRequest request = GetObjectRequest.builder()
                .bucket(bucketName)
                .key(filename)
                .build();

        return Mono.fromFuture(() ->
                s3AsyncClient.getObject(request, AsyncResponseTransformer.toPublisher())
        ).map(responsePublisher ->
                Flux.from(responsePublisher)
                        .map(byteBuffer -> {
                            ByteBuffer buffer = (ByteBuffer) byteBuffer;
                            DataBuffer dataBuffer = BUFFER_FACTORY.allocateBuffer(buffer.remaining());
                            dataBuffer.write(buffer);
                            return dataBuffer;
                        })
        ).onErrorMap(e -> new RuntimeException("Error downloading file: " + e.getMessage()));
    }

    public Mono<String> uploadSingleFile(FilePart filePart) {
        String key = UUID.randomUUID() + "-" + filePart.filename();

        return filePart.content()
                .reduce((dataBuffer1, dataBuffer2) -> {
                    dataBuffer1.write(dataBuffer2);
                    return dataBuffer1;
                })
                .flatMap(dataBuffer -> {
                    try {
                        byte[] bytes = new byte[dataBuffer.readableByteCount()];
                        dataBuffer.read(bytes);
                        // Properly release the DataBuffer
                        DataBufferUtils.release(dataBuffer);

                        // Create the S3 put object request
                        PutObjectRequest objectRequest = PutObjectRequest.builder()
                                .bucket(bucketName)
                                .key(key)
                                .contentType(filePart.headers().getContentType().toString())
                                .build();

                        // Upload to S3 using the async client
                        return Mono.fromFuture(
                                        s3AsyncClient.putObject(objectRequest, AsyncRequestBody.fromBytes(bytes))
                                ).thenReturn(key)
                                .doOnSuccess(k -> log.info("Successfully uploaded file: {}", k))
                                .doOnError(e -> log.error("Error uploading file: {}", e.getMessage()));
                    } catch (Exception e) {
                        DataBufferUtils.release(dataBuffer);
                        log.error("Error processing file for upload: {}", e.getMessage());
                        return Mono.error(e);
                    }
                })
                .onErrorResume(e -> {
                    log.error("Error processing file for upload: {}", e.getMessage());
                    return Mono.error(e);
                });
    }

    public Mono<String> uploadFileFromFile(File file) {
        String key = UUID.randomUUID() + "-" + file.getName();

        try {
            // Read the file content as bytes
            byte[] bytes = Files.readAllBytes(file.toPath());

            // Create the S3 put object request
            PutObjectRequest objectRequest = PutObjectRequest.builder()
                    .bucket(bucketName)
                    .key(key)
                    .contentType(Files.probeContentType(file.toPath()))
                    .build();

            // Upload to S3 using the async client
            return Mono.fromFuture(
                            s3AsyncClient.putObject(objectRequest, AsyncRequestBody.fromBytes(bytes))
                    ).thenReturn(key)
                    .doOnSuccess(k -> log.info("Successfully uploaded file: {}", k))
                    .doOnError(e -> log.error("Error uploading file: {}", e.getMessage()));

        } catch (Exception e) {
            log.error("Error processing file for upload: {}", e.getMessage());
            return Mono.error(e);
        }
    }

    private String determineContentType(String filename) {
        try {
            String extension = filename.substring(filename.lastIndexOf('.') + 1).toLowerCase();
            return switch (extension) {
                case "pdf" -> "application/pdf";
                case "doc" -> "application/msword";
                case "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                case "zip" -> "application/zip";
                default -> "application/octet-stream";
            };
        } catch (Exception e) {
            return "application/octet-stream";
        }
    }
}