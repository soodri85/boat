package com.botea.service;

import jakarta.activation.DataHandler;
import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;
import jakarta.mail.util.ByteArrayDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class EmailSender {

    @Value("${spring.mail.host}")
    private String smtpServer;

    @Value("${spring.mail.port}")
    private int smtpPort;

    @Value("${spring.mail.username}")
    private String username;

    @Value("${spring.mail.password}")
    private String password;

    public void sendEmail(String toEmail, String[] ccEmails, String subject, String emailContent) {
        try {
            Session session = createSession();
            Message message = createMessage(session, toEmail, ccEmails, subject, emailContent);
            Transport.send(message);
            System.out.println("Email sent successfully to " + toEmail + (ccEmails != null && ccEmails.length > 0 ? " with CC to " + String.join(", ", ccEmails) : ""));
        } catch (Exception e) {
            System.out.println("Failed to send email to " + toEmail + ": " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void sendEmail(String toEmail, String subject, String emailContent) {
        sendEmail(toEmail, null, subject, emailContent);
    }

    public void sendEmailWithAttachment(String toEmail, String[] ccEmails, String subject, String emailContent, 
            byte[] attachment, String attachmentName) {
        try {
            Session session = createSession();
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));
            
            // Add CC recipients if provided
            if (ccEmails != null && ccEmails.length > 0) {
                InternetAddress[] ccAddresses = new InternetAddress[ccEmails.length];
                for (int i = 0; i < ccEmails.length; i++) {
                    ccAddresses[i] = new InternetAddress(ccEmails[i].trim());
                }
                message.addRecipients(Message.RecipientType.CC, ccAddresses);
            }
            
            message.setSubject(subject);

            // Create the message parts
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setContent(emailContent, "text/html; charset=utf-8");

            // Create attachment part
            MimeBodyPart attachmentPart = new MimeBodyPart();
            ByteArrayDataSource source = new ByteArrayDataSource(attachment, "application/pdf");
            attachmentPart.setDataHandler(new DataHandler(source));
            attachmentPart.setFileName(attachmentName);

            // Create Multipart and add parts
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);
            multipart.addBodyPart(attachmentPart);

            // Set the content
            message.setContent(multipart);

            Transport.send(message);
            System.out.println("Email with attachment sent successfully to " + toEmail + (ccEmails != null && ccEmails.length > 0 ? " with CC to " + String.join(", ", ccEmails) : ""));
        } catch (Exception e) {
            System.out.println("Failed to send email with attachment to " + toEmail + ": " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void sendEmailWithAttachment(String toEmail, String subject, String emailContent, 
            byte[] attachment, String attachmentName) {
        sendEmailWithAttachment(toEmail, null, subject, emailContent, attachment, attachmentName);
    }

    private Session createSession() {
        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", smtpServer);
        properties.put("mail.smtp.port", smtpPort);

        return Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });
    }

    private Message createMessage(Session session, String toEmail, String[] ccEmails, String subject, String content) 
            throws MessagingException {
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(username));
        message.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));
        
        // Add CC recipients if provided
        if (ccEmails != null && ccEmails.length > 0) {
            InternetAddress[] ccAddresses = new InternetAddress[ccEmails.length];
            for (int i = 0; i < ccEmails.length; i++) {
                ccAddresses[i] = new InternetAddress(ccEmails[i].trim());
            }
            message.addRecipients(Message.RecipientType.CC, ccAddresses);
        }
        
        message.setSubject(subject);
        message.setContent(content, "text/html; charset=utf-8");
        return message;
    }

    private Message createMessage(Session session, String toEmail, String subject, String content) 
            throws MessagingException {
        return createMessage(session, toEmail, null, subject, content);
    }
}
