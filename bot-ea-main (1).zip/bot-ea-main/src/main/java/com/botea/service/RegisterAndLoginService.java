package com.botea.service;

import com.botea.dao.entity.BotUser;
import com.botea.dao.entity.CountryProfile;
import com.botea.dao.entity.UserProfile;
import com.botea.dao.repository.UserRepository;
import com.botea.exception.BotApplicationException;
import com.botea.helper.HouseKeepingHelper;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;

@Service
@Slf4j
public class RegisterAndLoginService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserProfileService userProfileService;

    @Autowired
    private CountryProfileService countryProfileService;

    @Autowired
    private EmailOTPService emailOTPService;

    public Mono<Object> registerUser(@Valid BotUser botUser, String[] countryCodes) {
        return userRepository.findByUsername(botUser.getUsername())
                .flatMap(existingUser -> {
                    // If user exists, throw a ResponseStatusException with a 409 status code
                    log.warn("Attempt to register an existing user: {}", botUser.getUsername());
                    return Mono.error(new ResponseStatusException(HttpStatus.CONFLICT, "User already exists"));
                })
                .switchIfEmpty(
                        userRepository.save(getUserWithEncodedPassword(botUser))
                                .flatMap(savedUser -> {
                                    log.info("User created successfully: {}", savedUser.getUsername());
                                    // Set the password to null before returning the response
                                    savedUser.setPassword(null);

                                    // Create user profiles for each country code // Rajat Please review the same
                                    /*final String[] countryCodesTemp ={};
                                    if (botUser.getCountryCodes() == null || botUser.getCountryCodes().length == 0) {
                                        // If no country codes provided, use the default country from the user object
                                        if (botUser.getCountry() == null || botUser.getCountry().trim().isEmpty()) {
                                            return Mono.error(new ResponseStatusException(HttpStatus.BAD_REQUEST, "At least one country must be provided"));
                                        }
                                        countryCodes = new String[]{botUser.getCountry()};
                                    } else {
                                        countryCodes = botUser.getCountryCodes();
                                    }*/

                                    // Validate that we have at least one valid country code
                                    if (countryCodes.length == 0) {
                                        return Mono.error(new ResponseStatusException(HttpStatus.BAD_REQUEST, "At least one country must be provided"));
                                    }

                                    // Create a list of Monos for each country profile creation
                                    Flux<UserProfile> profileCreationFlux = Flux.fromArray(countryCodes)
                                            .flatMap(countryCode -> 
                                                countryProfileService.getCountryProfileByCountryCode(countryCode)
                                                    .flatMap(countryProfile -> {
                                                        UserProfile userProfile = UserProfile.builder()
                                                            .botUserId(savedUser.getBotUserId())
                                                            .countryProfileId(countryProfile.getCountryProfileId())
                                                            .isDefault(countryCode.equals(countryCodes[0])) // First country is default
                                                            .created(LocalDateTime.now())
                                                            .createdBy(savedUser.getBotUserId())
                                                            .build();
                                                        return userProfileService.createOrUpdateUserProfile(userProfile);
                                                    })
                                            );

                                    return profileCreationFlux
                                            .collectList()
                                            .flatMap(profiles -> {
                                                // Send verification email
                                                return emailOTPService.sendRegisterVerifyEmail(savedUser.getUsername())
                                                        .thenReturn(savedUser);
                                            })
                                            .onErrorResume(ex -> {
                                                log.error("Error creating user profiles or sending verification email for user: {}", savedUser.getUsername(), ex);
                                                return Mono.error(new BotApplicationException("Error while creating user profiles or sending verification email: " + ex.getMessage()));
                                            });
                                })
                                .doOnError(ex -> log.error("Error creating user: {}", botUser.getUsername(), ex))
                );
    }

    private static @NotNull UserProfile getUserProfile(BotUser savedUser, CountryProfile countryProfile) {
        UserProfile.UserProfileBuilder userProfileBuilder = UserProfile.builder()
                .botUserId(savedUser.getBotUserId())
                .countryProfileId(countryProfile.getCountryProfileId())
                .created(LocalDateTime.now())
                .isDefault(true)
                .createdBy(savedUser.getBotUserId());
        return userProfileBuilder.build();
    }

    private BotUser getUserWithEncodedPassword(BotUser botUser) {
        // Encode the password before saving
        String encodedPassword = passwordEncoder.encode(botUser.getPassword());

        // Build and return a new User with the encoded password
        return BotUser.builder()
                .username(botUser.getUsername())
                .password(encodedPassword)
                .firstName(botUser.getFirstName())
                .role(botUser.getRole())
                .phone(botUser.getPhone())
                .middleName(botUser.getMiddleName())
                .lastName(botUser.getLastName())
                .legalName(botUser.getLegalName())
                .dob(botUser.getDob())
                .addressLine1(botUser.getAddressLine1())
                .addressLine2(botUser.getAddressLine2())
                .city(botUser.getCity())
                .zip(botUser.getZip())
                .state(botUser.getState())
                .country(botUser.getCountry())
                .created(HouseKeepingHelper.getCurrentLocalDateTime())
                .createdBy(HouseKeepingHelper.getCreatedBy())
                .isVerified(false)
                .build();
    }
}

