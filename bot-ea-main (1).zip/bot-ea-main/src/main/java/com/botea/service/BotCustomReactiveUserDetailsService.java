package com.botea.service;

import com.botea.dao.entity.BotUser;
import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
import reactor.core.publisher.Mono;

public interface BotCustomReactiveUserDetailsService extends ReactiveUserDetailsService {
    Mono<BotUser> findUserByUsername(String username);
}
