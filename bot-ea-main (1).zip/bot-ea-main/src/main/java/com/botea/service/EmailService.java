package com.botea.service;

import com.botea.dao.repository.OtpRepository;
import com.botea.exception.BotApplicationException;
import com.botea.utils.EmailType;
import jakarta.mail.util.ByteArrayDataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class EmailService {

    @Autowired
    private EmailSender emailSender;

    @Autowired
    private TemplateEngine templateEngine;

    @Autowired
    private OtpRepository otpRepository;

    public Mono<Void> sendEmail(String to, String[] cc, String subject, Map<String, Object> variables, String template) {
        return sendEmailWithAttachment(to, cc, subject, variables, template, null, null);
    }

    public Mono<Void> sendEmail(String to, String subject, Map<String, Object> variables, String template) {
        return sendEmail(to, null, subject, variables, template);
    }

    public Mono<Void> sendEmailWithAttachment(String to, String[] cc, String subject, Map<String, Object> variables, 
            String template, byte[] attachment, String attachmentName) {
        return Mono.defer(() -> {
            try {
                // Prepare the context with variables to render the email template
                Context context = new Context();
                for (Map.Entry<String, Object> entry : variables.entrySet()) {
                    context.setVariable(entry.getKey(), entry.getValue());
                }

                // Process the email template
                String emailContent = templateEngine.process(template, context);

                // Send the email with or without attachment
                if (attachment != null && attachmentName != null) {
                    return Mono.fromRunnable(() -> 
                        emailSender.sendEmailWithAttachment(to, cc, subject, emailContent, attachment, attachmentName)
                    );
                } else {
                    return Mono.fromRunnable(() -> 
                        emailSender.sendEmail(to, cc, subject, emailContent)
                    );
                }
            } catch (Exception e) {
                return Mono.error(new BotApplicationException("Failed to send email: " + e.getMessage()));
            }
        });
    }

    public Mono<Void> sendEmailWithAttachment(String to, String subject, Map<String, Object> variables, 
            String template, byte[] attachment, String attachmentName) {
        return sendEmailWithAttachment(to, null, subject, variables, template, attachment, attachmentName);
    }

    public Mono<Void> sendResetEmail(String toEmail, String token) {
        String resetUrl = "/api/v1/auth/reset-password?token=" + token;
        String message = "Click the link to reset your password: " + resetUrl;
        return Mono.fromRunnable(() -> emailSender.sendEmail(toEmail, "Password Reset", message));
    }

    public void verifyEmail(String email_to) {
        // Variables to pass to the email template
        Map<String, Object> variables = new HashMap<>();
        variables.put("otp", "John Doe");
        variables.put("orderId", "123456");

        String subject = "Account Verification";
        this.sendEmail(email_to, subject, variables, EmailType.TWO_FACTOR.name());
    }
}