package com.botea.service;

import org.springframework.stereotype.Service;

/**
 * @author Praveen
 */

@Service
public class DataExtractionServiceImpl implements DataExtractionService {

	// private WebClient webClient;

	@Override
	public void readData() {
		// TODO Auto-generated method stub
	}
}
