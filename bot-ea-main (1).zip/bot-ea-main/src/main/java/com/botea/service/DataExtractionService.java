package com.botea.service;

public interface DataExtractionService {
	public void readData();
}
