package com.botea.service;

import com.botea.controller.dto.UserAuthenticationDTO;
import com.botea.exception.BotApplicationException;
import com.botea.helper.DataLookUpHelper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class PdfService {

    @Value("${pdf.url:https://app.useanvil.com/api/v1/fill}")
    private String apiUrl;

    @Value("${pdf.key:6bCF4GFDPLtjTWGSpNNnfrojq1UEkw3i}")
    private String apiKey;

    @Value("${pdf.secret}")
    private String apiSecret;

    @Value("${pdf.invoice.template.id}")
    private String invoiceTemplateId;

    private final WebClient.Builder webClientBuilder;
    
    @Autowired(required = false)
    private S3Service s3Service;

    @Autowired(required = false)
    private TransactionDataService transactionDataService;

    @Autowired(required = false)
    private DataLookUpHelper dataLookUpHelper;

    public PdfService(WebClient.Builder webClientBuilder) {
        this.webClientBuilder = webClientBuilder;
    }

    public Mono<byte[]> generateLicenseInvoice(String licenseKey, String email, BigDecimal totalPrice, 
            BigDecimal discount, BigDecimal paidAmount, String promoCode, BigDecimal totalCredit, 
            String licenseType) {
        
        // Skip PDF generation if template ID is not configured or is default value
        if (invoiceTemplateId == null || invoiceTemplateId.equals("your-template-id-here")) {
            return Mono.empty();
        }

        WebClient webClient = webClientBuilder.build();

        // Create the authentication token
        String credentials = apiKey + ":" + apiSecret;
        String encodedAuth = Base64.getEncoder().encodeToString(credentials.getBytes());

        // Prepare invoice data
        Map<String, Object> invoiceData = new HashMap<>();
        invoiceData.put("licenseKey", licenseKey);
        invoiceData.put("email", email);
        invoiceData.put("totalPrice", totalPrice);
        invoiceData.put("discount", discount);
        invoiceData.put("paidAmount", paidAmount);
        invoiceData.put("promoCode", promoCode != null ? promoCode : "N/A");
        invoiceData.put("totalCredit", totalCredit);
        invoiceData.put("licenseType", licenseType);
        invoiceData.put("invoiceDate", new Timestamp(System.currentTimeMillis()));
        invoiceData.put("invoiceNumber", "INV-" + System.currentTimeMillis());

        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("data", invoiceData);
        requestBody.put("templateId", invoiceTemplateId);

        return webClient.post()
                .uri(apiUrl)
                .header(HttpHeaders.AUTHORIZATION, "Basic " + encodedAuth)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestBody)
                .retrieve()
                .bodyToMono(byte[].class)
                .onErrorResume(e -> {
                    String errorMessage = "Failed to generate invoice PDF: " + e.getMessage();
                    return Mono.error(new BotApplicationException(errorMessage));
                });
    }

    public Mono<byte[]> generatePdf(UserAuthenticationDTO user, Map<String, Object> inputData) {
        WebClient webClient = webClientBuilder.build();
        Long transactionDataId = Long.parseLong(inputData.get("transaction_data_id").toString());
        Map<String, Object> draftData = (LinkedHashMap<String, Object>)inputData.get("draftData");
        ObjectMapper objectMapper = new ObjectMapper();
        String editedData;
        try {
            editedData = objectMapper.writeValueAsString(draftData);
        } catch (JsonProcessingException e) {
            String errorMessage = "An error occurred while reading the draft data : " + e.getMessage();
            return Mono.error(new IOException(errorMessage, e));
        }
        inputData.remove("draftData");

        // Create the authentication token
        String credentials = apiKey + ":" + apiSecret;
        String encodedAuth = Base64.getEncoder().encodeToString(credentials.getBytes());

        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("data", inputData);

            Long documentId = Long.parseLong(inputData.get("taxForm").toString());

            return getUrl(documentId)
                    .flatMap(url -> webClient.post()
                            .uri(url)
                            .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                            .header(HttpHeaders.AUTHORIZATION, "Basic " + encodedAuth)
                            .body(Mono.just(requestBody), Map.class)
                            .retrieve()
                            .onStatus(
                                    status -> !status.is2xxSuccessful(),
                                    clientResponse -> clientResponse.bodyToMono(String.class)
                                            .flatMap(errorMessage -> Mono.error(new BotApplicationException("Failed to generate PDF: " + errorMessage)))
                            )
                            .bodyToMono(byte[].class)
                    )
                    .flatMap(pdfBytes ->
                            // Upload the PDF to S3 and get the uploaded key
                            uploadPdfToS3Async(pdfBytes)
                                    .flatMap(uploadedFileKey -> {
                                        // Define the document path based on the uploaded file key
                                        String generatedDocumentPath = uploadedFileKey;

                                        // Get the current timestamp
                                        Timestamp updated = new Timestamp(System.currentTimeMillis());

                                        // Call the service method to update the database
                                        return transactionDataService.updatePdfPath(
                                                transactionDataId,
                                                generatedDocumentPath,
                                                true,
                                                editedData,
                                                updated,
                                                user.botUserId() // Assuming user contains this info
                                        ).thenReturn(pdfBytes); // Return the original PDF bytes
                                    })
                    )
                    .onErrorResume(throwable -> {
                        String errorMessage = "An error occurred while generating the PDF: " + throwable.getMessage();
                        return Mono.error(new IOException(errorMessage, throwable));
                    });


    }

    private Mono<String> getUrl(Long documentId) {

         return dataLookUpHelper.fetchAPIConfigLookUp()
                .filter(apiConfig -> apiConfig.getDocument().getDocumentId().equals(documentId))
                .next()
                .map(apiConfig -> apiUrl + "/" + apiConfig.getAnvilPdfTemplateId() + ".pdf")
                 .defaultIfEmpty(apiUrl + "/");


    }

    private Mono<String> uploadPdfToS3Async(byte[] pdfBytes) {
        try {
            // Create a temporary file
            File tempFile = File.createTempFile("generated-pdf-", ".pdf");
            try (FileOutputStream fos = new FileOutputStream(tempFile)) {
                fos.write(pdfBytes);
            }

            // Asynchronously upload to S3 and return the uploaded file key
            return s3Service.uploadFileFromFile(tempFile)
                    .doOnTerminate(() -> {
                        // Ensure the file is deleted after the upload is completed (success or error)
                        if (!tempFile.delete()) {
                            System.err.println("Failed to delete temporary file: " + tempFile.getPath());
                        }
                    });

        } catch (IOException e) {
            System.err.println("Failed to create temporary file for PDF upload: " + e.getMessage());
            return Mono.error(e);
        }
    }


}