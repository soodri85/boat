// Service Interface
package com.botea.service;

import com.botea.controller.dto.BotUserResponse;
import com.botea.dao.entity.BotUser;
import org.springframework.http.ResponseEntity;
import reactor.core.publisher.Mono;

public interface BotUserService {
    Mono<BotUserResponse> getUserById(Long id);

    Mono<BotUser> getUserByUsername(String email);

    Mono<BotUser> saveUser(BotUser user);

    Mono<Void> markAsVerified(Long botUserId);

    Mono<ResponseEntity<BotUserResponse>> updateUser(Long id, BotUser botUser);
}