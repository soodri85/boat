-- Reference Tables

CREATE TABLE role (
    code VARCHAR(50),
    name VARCHAR(250)
);

CREATE TABLE otp_type (
    code VARCHAR(50),
    name VARCHAR(250)
);

CREATE TABLE license_type (
    code VARCHAR(50),
    name VARCHAR(250)
);

CREATE TABLE two_factor_type (
    code VARCHAR(50),
    name VARCHAR(250)
);

CREATE TABLE audit_action (
    name VARCHAR(250)
);

-- Master data start
CREATE TABLE country_profile (
    country_profile_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name VARCHAR(255),
    country_name VARCHAR(255) NOT NULL,
    country_code VARCHAR(15) NOT NULL,
    language VARCHAR(255),
    language_code VARCHAR(50),
    currency VARCHAR(255),
    currency_code VARCHAR(50),
    license_credit_document DECIMAL(10, 2),
    license_credit_scan DECIMAL(10, 2),
    default_scans_included INT DEFAULT 0,
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated TIMESTAMP DEFAULT NULL,
    updated_by INT DEFAULT NULL
);

CREATE TABLE document (
    document_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    document_name VARCHAR(255),
    country_profile_id INT,
    version VARCHAR(50),
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated TIMESTAMP DEFAULT NULL,
    updated_by INT DEFAULT NULL,
    FOREIGN KEY (country_profile_id) REFERENCES country_profile(country_profile_id)
);

CREATE TABLE api_config (
    api_config_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    document_id INT,
    data_extraction_id VARCHAR(255),
    data_extraction_name VARCHAR(255),
    data_extraction_comments TEXT,
    data_extraction_version VARCHAR(50),
    anvil_pdf_template_id VARCHAR(255),
    anvil_pdf_template_name VARCHAR(255),
    anvil_pdf_template_comments TEXT,
    anvil_pdf_template_version VARCHAR(50),
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated TIMESTAMP DEFAULT NULL,
    updated_by INT DEFAULT NULL,
    FOREIGN KEY (document_id) REFERENCES document(document_id)
);

-- Master data end

-- Table naics
CREATE TABLE naics (
    naics_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    naics_code VARCHAR(50) NOT NULL,
    naics_description VARCHAR(255) NOT NULL,
    country_profile_id INT,
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated TIMESTAMP DEFAULT NULL,
    updated_by INT DEFAULT NULL,
    FOREIGN KEY (country_profile_id) REFERENCES country_profile(country_profile_id)
);

-- Table: public.bot_user
CREATE TABLE bot_user
(
    bot_user_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(3),
    phone VARCHAR(15),
    first_name VARCHAR(255) NOT NULL,
    middle_name VARCHAR(255),
    last_name VARCHAR(255) NOT NULL,
    legal_name VARCHAR(255),
    dob DATE,
    address_line1 VARCHAR(255),
    address_line2 VARCHAR(255),
    city VARCHAR(255),
    zip VARCHAR(20),
    state VARCHAR(50),
    country VARCHAR(50),
    is_verified BOOLEAN DEFAULT false,
    is_two_factor_enabled BOOLEAN DEFAULT false,
    two_factor_type VARCHAR(20),
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated TIMESTAMP DEFAULT NULL,
    updated_by INT DEFAULT NULL
);

-- Table: user_profile
CREATE TABLE user_profile (
    user_profile_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    bot_user_id INT,
    country_profile_id INT,
    is_default BOOLEAN,
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated TIMESTAMP DEFAULT NULL,
    updated_by INT DEFAULT NULL,
    FOREIGN KEY (bot_user_id) REFERENCES bot_user(bot_user_id),
    FOREIGN KEY (country_profile_id) REFERENCES country_profile(country_profile_id)
);

-- Table: business_address
CREATE TABLE business_address (
    business_address_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_profile_id INT,
    contact_type VARCHAR(10),
    employee_id VARCHAR(255),
    national_identifier VARCHAR(100),
    business_owner VARCHAR(255),
    business_name VARCHAR(255),
    business_number VARCHAR(50),
    business_nature VARCHAR(255),
    business_category VARCHAR(255),
    naics_code VARCHAR(50),
    address_line1 VARCHAR(255),
    address_line2 VARCHAR(255),
    city VARCHAR(255),
    zip VARCHAR(20),
    state VARCHAR(255),
    country VARCHAR(255),
    business_phone VARCHAR(15),
    business_email VARCHAR(255),
    ownership_status VARCHAR(50),
    other_ownership_details TEXT,
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated TIMESTAMP DEFAULT NULL,
    updated_by INT DEFAULT NULL,
    FOREIGN KEY (user_profile_id) REFERENCES user_profile(user_profile_id)
);

-- Table: otp
CREATE TABLE otp (
    otp_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    bot_user_id INT,
    is_expired BOOLEAN,
    otp INT,
    otp_type VARCHAR(20),
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated TIMESTAMP DEFAULT NULL,
    updated_by INT DEFAULT NULL,
    FOREIGN KEY (bot_user_id) REFERENCES bot_user(bot_user_id)
);

-- Table: license
CREATE TABLE license (
    license_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    license_key VARCHAR(255),
    bot_user_id INT,
    country_profile_id INT,
    is_registered BOOLEAN,
    is_expired BOOLEAN,
    validity DATE,
    license_type VARCHAR(50),
    total_credit DECIMAL(10, 2),
    remaining_credit DECIMAL(10, 2),
    comments TEXT,
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated TIMESTAMP DEFAULT NULL,
    updated_by INT DEFAULT NULL,
    FOREIGN KEY (bot_user_id) REFERENCES bot_user(bot_user_id),
    FOREIGN KEY (country_profile_id) REFERENCES country_profile(country_profile_id)
);

-- Table: license_payment
CREATE TABLE license_payment (
    license_payment_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    license_id INT,
    purchased_on TIMESTAMP,
    purchased_by INT,
    payment_method VARCHAR(50),
    payment_details TEXT,
    payment_amount DECIMAL(10, 2),
    payment_currency_code VARCHAR(50),
    comments TEXT,
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated TIMESTAMP DEFAULT NULL,
    updated_by INT DEFAULT NULL,
    FOREIGN KEY (license_id) REFERENCES license(license_id),
    FOREIGN KEY (purchased_by) REFERENCES bot_user(bot_user_id)
);

-- Table: transaction_data
CREATE TABLE transaction_data (
    transaction_data_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_profile_id INT,
    business_address_id INT,
    extracted_data TEXT,
    edited_data TEXT,
    generated_document_data TEXT,
    extraction_id VARCHAR(255),
    batch_id VARCHAR(255),
    document_id INT
    is_document_generated BOOLEAN,
    uploaded_document_path VARCHAR(255),
    generated_document_path VARCHAR(255),
    comments TEXT,
    version VARCHAR(50),
    year VARCHAR(4),
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated TIMESTAMP DEFAULT NULL,
    updated_by INT DEFAULT NULL,
    FOREIGN KEY (user_profile_id) REFERENCES user_profile(user_profile_id),
    FOREIGN KEY (business_address_id) REFERENCES business_address(business_address_id)
);

-- Table: token
CREATE TABLE token (
    token_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    token VARCHAR(255) NOT NULL,
    is_logged_out BOOLEAN NOT NULL DEFAULT FALSE,
    bot_user_id INT,
    login_time TIMESTAMP,
    logout_time TIMESTAMP,
    is_refresh BOOLEAN NOT NULL DEFAULT FALSE,
    is_active BOOLEAN NOT NULL DEFAULT FALSE,
    user_agent VARCHAR(255) NOT NULL,
    ip_address VARCHAR(255) NOT NULL,
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated TIMESTAMP DEFAULT NULL,
    updated_by INT DEFAULT NULL,
    FOREIGN KEY (bot_user_id) REFERENCES bot_user(bot_user_id)
);

-- Table: tax_info
CREATE TABLE tax_info (
    tax_info_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    province_code VARCHAR(15),
    province_name VARCHAR(100),
    gst_percentage DECIMAL(10, 2),
    country_profile_id INT,
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated TIMESTAMP DEFAULT NULL,
    updated_by INT DEFAULT NULL,
    FOREIGN KEY (country_profile_id) REFERENCES country_profile(country_profile_id)
);

-- Table: audit
CREATE TABLE audit (
    audit_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    action VARCHAR(50),
    data TEXT,
    comments TEXT,
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated TIMESTAMP DEFAULT NULL,
    updated_by INT DEFAULT NULL
);

--promo_code
-- promo_type: 
--   SNG = Single use promo code (usage_limit = 1)
--   MUL = Multi use promo code (usage_limit > 1)
CREATE TABLE promo_code (
    promo_code_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    promo_code_value VARCHAR(50) NOT NULL,
    promo_type VARCHAR(3) DEFAULT 'SNG',
    discount DECIMAL(5,2) NOT NULL,
    is_used BOOLEAN DEFAULT FALSE,
    expiry INT,
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    updated TIMESTAMP DEFAULT NULL,
    updated_by INT DEFAULT NULL,
    usage_limit INT NOT NULL DEFAULT 1,
    times_used INT NOT NULL DEFAULT 0,
); 

-- licence id removed from promo_code table
ALTER TABLE promo_code DROP COLUMN license_id;

-- Create join table for promo code and license relationships
CREATE TABLE promo_code_license (
    promo_code_license_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    promo_code_id INT NOT NULL,
    license_id INT NOT NULL,
    used_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    FOREIGN KEY (promo_code_id) REFERENCES promo_code(promo_code_id),
    FOREIGN KEY (license_id) REFERENCES license(license_id)
);

--sequences
CREATE SEQUENCE token_id_seq START 1 INCREMENT 1;

-- Admin Dashboard Stored Procedures

-- 1. Subscription Statistics
CREATE OR REPLACE FUNCTION public.get_revenue_statistics()
 RETURNS TABLE(total_revenue numeric, current_month_revenue numeric, last_month_revenue numeric, total_payments bigint, avg_payment_amount numeric, payment_methods jsonb, year_to_date_revenue numeric)
 LANGUAGE plpgsql
AS $function$
BEGIN
    RETURN QUERY
    WITH method_totals AS (
        SELECT 
            payment_method,
            SUM(payment_amount) as method_total
        FROM license_payment
        GROUP BY payment_method
    ),
    payment_stats AS (
        SELECT 
            SUM(payment_amount) as total_revenue,
            COUNT(*) as total_payments,
            AVG(payment_amount) as avg_payment_amount,
            SUM(CASE 
                WHEN EXTRACT(YEAR FROM purchased_on) = EXTRACT(YEAR FROM CURRENT_DATE)
                THEN payment_amount 
                ELSE 0 
            END) as year_to_date_revenue,
            SUM(CASE 
                WHEN EXTRACT(YEAR FROM purchased_on) = EXTRACT(YEAR FROM CURRENT_DATE)
                AND EXTRACT(MONTH FROM purchased_on) = EXTRACT(MONTH FROM CURRENT_DATE)
                THEN payment_amount 
                ELSE 0 
            END) as current_month_revenue,
            SUM(CASE 
                WHEN EXTRACT(YEAR FROM purchased_on) = EXTRACT(YEAR FROM CURRENT_DATE)
                AND EXTRACT(MONTH FROM purchased_on) = EXTRACT(MONTH FROM CURRENT_DATE) - 1
                THEN payment_amount 
                ELSE 0 
            END) as last_month_revenue
        FROM license_payment
    ),
    payment_methods_agg AS (
        SELECT jsonb_object_agg(
            COALESCE(payment_method, 'unknown'), 
            method_total
        ) as payment_methods
        FROM method_totals
    )
    SELECT 
        COALESCE(ps.total_revenue, 0) as total_revenue,
        COALESCE(ps.current_month_revenue, 0) as current_month_revenue,
        COALESCE(ps.last_month_revenue, 0) as last_month_revenue,
        COALESCE(ps.total_payments, 0) as total_payments,
        COALESCE(ps.avg_payment_amount, 0) as avg_payment_amount,
        COALESCE(pm.payment_methods, '{}'::jsonb) as payment_methods,
        COALESCE(ps.year_to_date_revenue, 0) as year_to_date_revenue
    FROM payment_stats ps
    CROSS JOIN payment_methods_agg pm;
END;
$function$
;

-- 2. Subscription Statistics
CREATE OR REPLACE FUNCTION get_subscription_statistics()
RETURNS TABLE (
    total_subscriptions BIGINT,
    active_subscriptions BIGINT,
    expired_subscriptions BIGINT,
    current_month_subscriptions BIGINT,
    last_month_subscriptions BIGINT,
    subscription_types JSONB,
    subscription_revenue DECIMAL,
    avg_subscription_value DECIMAL,
    renewal_rate DECIMAL
) AS $$
BEGIN
    RETURN QUERY
    WITH subscription_counts AS (
        SELECT
            COUNT(*) as total_subscriptions,
            COUNT(*) FILTER (WHERE is_expired = false) as active_subscriptions,
            COUNT(*) FILTER (WHERE is_expired = true) as expired_subscriptions,
            COUNT(*) FILTER (
                WHERE EXTRACT(YEAR FROM created) = EXTRACT(YEAR FROM CURRENT_DATE)
                AND EXTRACT(MONTH FROM created) = EXTRACT(MONTH FROM CURRENT_DATE)
            ) as current_month_subscriptions,
            COUNT(*) FILTER (
                WHERE EXTRACT(YEAR FROM created) = EXTRACT(YEAR FROM CURRENT_DATE)
                AND EXTRACT(MONTH FROM created) = EXTRACT(MONTH FROM CURRENT_DATE) - 1
            ) as last_month_subscriptions
        FROM license
    ),
    license_type_counts AS (
        SELECT 
            license_type,
            COUNT(*) as type_count
        FROM license
        GROUP BY license_type
    ),
    license_types_agg AS (
        SELECT jsonb_object_agg(
            COALESCE(license_type, 'unknown'),
            type_count
        ) as subscription_types
        FROM license_type_counts
    ),
    renewal_base AS (
        SELECT 
            l1.bot_user_id,
            COUNT(DISTINCT l2.license_id) as renewal_count
        FROM license l1
        LEFT JOIN license l2 ON l1.bot_user_id = l2.bot_user_id 
            AND l2.created > l1.created
        GROUP BY l1.bot_user_id
    ),
    revenue_base AS (
        SELECT 
            SUM(payment_amount) as total_revenue,
            AVG(payment_amount) as avg_payment,
            COUNT(DISTINCT license_id) as total_licenses
        FROM license_payment
    ),
    renewal_stats AS (
        SELECT 
            (SUM(CASE WHEN renewal_count > 0 THEN 1 ELSE 0 END)::DECIMAL / 
            NULLIF(COUNT(*), 0)) * 100 as renewal_rate
        FROM renewal_base
    )
    SELECT
        COALESCE(sc.total_subscriptions, 0) as total_subscriptions,
        COALESCE(sc.active_subscriptions, 0) as active_subscriptions,
        COALESCE(sc.expired_subscriptions, 0) as expired_subscriptions,
        COALESCE(sc.current_month_subscriptions, 0) as current_month_subscriptions,
        COALESCE(sc.last_month_subscriptions, 0) as last_month_subscriptions,
        COALESCE(lta.subscription_types, '{}'::jsonb) as subscription_types,
        COALESCE(rb.total_revenue, 0) as subscription_revenue,
        COALESCE(rb.avg_payment, 0) as avg_subscription_value,
        COALESCE(rs.renewal_rate, 0) as renewal_rate
    FROM subscription_counts sc
    CROSS JOIN license_types_agg lta
    CROSS JOIN revenue_base rb
    CROSS JOIN renewal_stats rs;
END;
$$ LANGUAGE plpgsql;


-- 3. Active User Statistics
CREATE OR REPLACE FUNCTION get_active_user_statistics(p_days_threshold INTEGER DEFAULT 30)
RETURNS TABLE (
    active_users BIGINT,
    active_last_day BIGINT,
    active_last_week BIGINT,
    active_last_month BIGINT,
    activity_by_type JSONB
) AS $$
BEGIN
    RETURN QUERY
    WITH user_last_activity AS (
        -- Last login from token table
        SELECT 
            bot_user_id,
            login_time as activity_time,
            'login' as activity_type
        FROM token
        WHERE login_time >= CURRENT_TIMESTAMP - (p_days_threshold || ' days')::INTERVAL
        
        UNION ALL
        
        -- Last transaction
        SELECT 
            created_by as bot_user_id,
            created as activity_time,
            'transaction' as activity_type
        FROM transaction_data
        WHERE created >= CURRENT_TIMESTAMP - (p_days_threshold || ' days')::INTERVAL
        
        UNION ALL
        
        -- Last license purchase
        SELECT 
            purchased_by as bot_user_id,
            purchased_on as activity_time,
            'purchase' as activity_type
        FROM license_payment
        WHERE purchased_on >= CURRENT_TIMESTAMP - (p_days_threshold || ' days')::INTERVAL
    ),
    activity_counts AS (
        SELECT
            COUNT(DISTINCT bot_user_id) as active_users,
            COUNT(DISTINCT CASE 
                WHEN activity_time >= CURRENT_TIMESTAMP - INTERVAL '1 day'
                THEN bot_user_id END) as last_day_active,
            COUNT(DISTINCT CASE 
                WHEN activity_time >= CURRENT_TIMESTAMP - INTERVAL '7 days'
                THEN bot_user_id END) as last_week_active,
            COUNT(DISTINCT CASE 
                WHEN activity_time >= CURRENT_TIMESTAMP - INTERVAL '30 days'
                THEN bot_user_id END) as last_month_active
        FROM user_last_activity
    ),
    activity_types AS (
        SELECT 
            activity_type,
            COUNT(DISTINCT bot_user_id) as type_count
        FROM user_last_activity
        GROUP BY activity_type
    ),
    activity_json AS (
        SELECT jsonb_object_agg(
            activity_type,
            type_count
        ) as activity_by_type
        FROM activity_types
    )
    SELECT 
        COALESCE(ac.active_users, 0) as active_users,
        COALESCE(ac.last_day_active, 0) as active_last_day,
        COALESCE(ac.last_week_active, 0) as active_last_week,
        COALESCE(ac.last_month_active, 0) as active_last_month,
        COALESCE(aj.activity_by_type, '{}'::jsonb) as activity_by_type
    FROM activity_counts ac
    CROSS JOIN activity_json aj;
END;
$$ LANGUAGE plpgsql;

-- 4. Transaction Statistics
CREATE OR REPLACE FUNCTION get_transaction_statistics(p_year INTEGER)
RETURNS TABLE (
    month INTEGER,
    total_transactions BIGINT,
    successful_generations BIGINT,
    failed_generations BIGINT,
    transactions_by_document JSONB
) AS $$
BEGIN
    RETURN QUERY
    WITH document_counts AS (
        SELECT 
            EXTRACT(MONTH FROM td.created)::INTEGER as doc_month,
            d.document_name,
            COUNT(*) as doc_count
        FROM transaction_data td
        LEFT JOIN document d ON td.document_id = d.document_id
        WHERE EXTRACT(YEAR FROM td.created) = p_year
        GROUP BY EXTRACT(MONTH FROM td.created), d.document_name
    ),
    monthly_transactions AS (
        SELECT 
            EXTRACT(MONTH FROM td.created)::INTEGER as trans_month,
            COUNT(*) as total_transactions,
            COUNT(*) FILTER (WHERE is_document_generated = true) as successful_generations,
            COUNT(*) FILTER (WHERE is_document_generated = false) as failed_generations
        FROM transaction_data td
        WHERE EXTRACT(YEAR FROM td.created) = p_year
        GROUP BY EXTRACT(MONTH FROM td.created)
    ),
    doc_aggs AS (
        SELECT 
            doc_month,
            jsonb_object_agg(
                COALESCE(document_name, 'unknown'), 
                doc_count
            ) as transactions_by_document
        FROM document_counts
        GROUP BY doc_month
    )
    SELECT 
        m.month,
        COALESCE(mt.total_transactions, 0) as total_transactions,
        COALESCE(mt.successful_generations, 0) as successful_generations,
        COALESCE(mt.failed_generations, 0) as failed_generations,
        COALESCE(da.transactions_by_document, '{}'::jsonb) as transactions_by_document
    FROM generate_series(1,12) m(month)
    LEFT JOIN monthly_transactions mt ON mt.trans_month = m.month
    LEFT JOIN doc_aggs da ON da.doc_month = m.month
    ORDER BY m.month;
END;
$$ LANGUAGE plpgsql;

-- 5. User Statistics
CREATE OR REPLACE FUNCTION get_user_statistics(p_year INTEGER)
RETURNS TABLE (
    month INTEGER,
    total_users BIGINT,
    verified_users BIGINT,
    unverified_users BIGINT,
    users_with_2fa BIGINT,
    new_users_this_month BIGINT
) AS $$
BEGIN
    RETURN QUERY
    WITH monthly_stats AS (
        SELECT 
            EXTRACT(MONTH FROM bu.created)::INTEGER as user_month,
            COUNT(*) as total_users,
            COUNT(*) FILTER (WHERE is_verified = true) as verified_users,
            COUNT(*) FILTER (WHERE is_verified = false) as unverified_users,
            COUNT(*) FILTER (WHERE is_two_factor_enabled = true) as users_with_2fa,
            COUNT(*) FILTER (
                WHERE EXTRACT(YEAR FROM bu.created) = p_year 
                AND EXTRACT(MONTH FROM bu.created) = EXTRACT(MONTH FROM bu.created)
            ) as new_users_this_month
        FROM bot_user bu
        WHERE EXTRACT(YEAR FROM bu.created) <= p_year
        GROUP BY EXTRACT(MONTH FROM bu.created)
    )
    SELECT 
        m.month,
        COALESCE(ms.total_users, 0) as total_users,
        COALESCE(ms.verified_users, 0) as verified_users,
        COALESCE(ms.unverified_users, 0) as unverified_users,
        COALESCE(ms.users_with_2fa, 0) as users_with_2fa,
        COALESCE(ms.new_users_this_month, 0) as new_users_this_month
    FROM generate_series(1,12) m(month)
    LEFT JOIN monthly_stats ms ON ms.user_month = m.month
    ORDER BY m.month;
END;
$$ LANGUAGE plpgsql;

-- 6. License Usage Statistics
CREATE OR REPLACE FUNCTION get_license_statistics(p_year INTEGER)
RETURNS TABLE (
    month INTEGER,
    total_licenses BIGINT,
    active_licenses BIGINT,
    expired_licenses BIGINT,
    total_credit_sum DECIMAL,
    remaining_credit_sum DECIMAL,
    licenses_expiring_30days BIGINT,
    new_licenses_this_month BIGINT
) AS $$
BEGIN
    RETURN QUERY
    WITH monthly_stats AS (
        SELECT 
            EXTRACT(MONTH FROM l.created)::INTEGER as license_month,
            COUNT(*) as total_licenses,
            COUNT(*) FILTER (WHERE is_expired = false) as active_licenses,
            COUNT(*) FILTER (WHERE is_expired = true) as expired_licenses,
            COALESCE(SUM(total_credit), 0) as total_credit_sum,
            COALESCE(SUM(remaining_credit), 0) as remaining_credit_sum,
            COUNT(*) FILTER (WHERE validity BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '30 days')) as licenses_expiring_30days,
            COUNT(*) FILTER (
                WHERE EXTRACT(YEAR FROM l.created) = p_year 
                AND EXTRACT(MONTH FROM l.created) = EXTRACT(MONTH FROM l.created)
            ) as new_licenses_this_month
        FROM license l
        WHERE EXTRACT(YEAR FROM l.created) <= p_year
        GROUP BY EXTRACT(MONTH FROM l.created)
    )
    SELECT 
        m.month,
        COALESCE(ms.total_licenses, 0) as total_licenses,
        COALESCE(ms.active_licenses, 0) as active_licenses,
        COALESCE(ms.expired_licenses, 0) as expired_licenses,
        COALESCE(ms.total_credit_sum, 0) as total_credit_sum,
        COALESCE(ms.remaining_credit_sum, 0) as remaining_credit_sum,
        COALESCE(ms.licenses_expiring_30days, 0) as licenses_expiring_30days,
        COALESCE(ms.new_licenses_this_month, 0) as new_licenses_this_month
    FROM generate_series(1,12) m(month)
    LEFT JOIN monthly_stats ms ON ms.license_month = m.month
    ORDER BY m.month;
END;
$$ LANGUAGE plpgsql;
