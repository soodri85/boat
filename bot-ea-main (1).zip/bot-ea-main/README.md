# bot-ea
bot-ea

bot-ea Simplifies Tax and accountings solutons for every business. Primarily focused northen america at this point of time. 
backend: SpringBoot
Fromtend: React
Contaier: Docker
